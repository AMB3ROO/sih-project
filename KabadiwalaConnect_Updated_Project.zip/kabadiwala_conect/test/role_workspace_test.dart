import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
import 'package:kabadiwala_conect/screens/role_workspaces.dart';
import 'package:kabadiwala_conect/services/app_state.dart';

Widget _app(UserRole role) => ChangeNotifierProvider(
  create: (_) => AppState(),
  child: MaterialApp(home: RoleWorkspaceScreen(role: role)),
);

void main() {
  testWidgets('kabadiwala can add a lot and get an estimate', (tester) async {
    await tester.pumpWidget(_app(UserRole.kabadiwalaTrader));
    await tester.tap(find.byType(FloatingActionButton));
    await tester.pumpAndSettle();

    await tester.enterText(find.byType(TextField).first, '5');
    await tester.pumpAndSettle();
    expect(find.textContaining('₹230'), findsOneWidget);

    await tester.tap(find.text('Save lot'));
    await tester.pumpAndSettle();
    expect(find.text('Saved offline'), findsOneWidget);
  });

  testWidgets('recycler can schedule and confirm a handover', (tester) async {
    await tester.pumpWidget(_app(UserRole.industrialRecycler));
    await tester.tap(find.text('Schedule pickup').first);
    await tester.pumpAndSettle();
    await tester.tap(find.text('Schedule pickup').last);
    await tester.pumpAndSettle();
    expect(find.text('Confirm receipt'), findsOneWidget);

    await tester.tap(find.text('Confirm receipt').first);
    await tester.pumpAndSettle();
    await tester.tap(find.text('Confirm receipt').last);
    await tester.pumpAndSettle();
    await tester.tap(find.text('Trace'));
    await tester.pumpAndSettle();
    expect(find.text('Verified'), findsOneWidget);
  });

  testWidgets('admin can verify a recycler and resolve a dispute', (
    tester,
  ) async {
    await tester.pumpWidget(_app(UserRole.platformAdmin));
    await tester.tap(find.text('Facilities'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('GreenLoop Recycling'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Mark verified'));
    await tester.pumpAndSettle();
    expect(find.text('Verified'), findsNWidgets(2));

    await tester.tap(find.text('Disputes'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Weight mismatch · KC-1011'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Resolve case'));
    await tester.pumpAndSettle();
    expect(find.text('Weight mismatch · KC-1011'), findsNothing);
  });
}
