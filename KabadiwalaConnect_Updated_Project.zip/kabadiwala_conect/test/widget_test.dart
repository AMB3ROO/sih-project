import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
import 'package:kabadiwala_conect/main.dart';
import 'package:kabadiwala_conect/services/app_state.dart';

void main() {
  testWidgets('App smoke test', (WidgetTester tester) async {
    await tester.pumpWidget(
      ChangeNotifierProvider(
        create: (_) => AppState(),
        child: const KabadiwalaConnectApp(),
      ),
    );

    expect(find.text('Kabadiwala\nConnect'), findsOneWidget);
  });
}
