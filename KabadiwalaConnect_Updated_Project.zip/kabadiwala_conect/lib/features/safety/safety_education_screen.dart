import 'package:flutter/material.dart';
import '../../models/safety_guide_model.dart';

class SafetyEducationScreen extends StatefulWidget {
  const SafetyEducationScreen({super.key});

  @override
  State<SafetyEducationScreen> createState() => _SafetyEducationScreenState();
}

class _SafetyEducationScreenState extends State<SafetyEducationScreen> {
  String _selectedLang = 'en'; // 'en', 'hi', 'mr'

  @override
  Widget build(BuildContext context) {
    final guides = SafetyGuideModel.defaultSafetyGuides;

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        title: const Text('Safe Scrap Handling', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: Color(0xFF0F172A))),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12.0),
            child: SegmentedButton<String>(
              segments: const [
                ButtonSegment(value: 'en', label: Text('ENG', style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold))),
                ButtonSegment(value: 'hi', label: Text('हिंदी', style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold))),
                ButtonSegment(value: 'mr', label: Text('मराठी', style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold))),
              ],
              selected: {_selectedLang},
              onSelectionChanged: (set) {
                setState(() {
                  _selectedLang = set.first;
                });
              },
            ),
          ),
        ],
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: guides.length,
        itemBuilder: (context, index) {
          final guide = guides[index];

          final title = _selectedLang == 'hi' ? guide.titleHi : (_selectedLang == 'mr' ? guide.titleMr : guide.titleEn);
          final desc = _selectedLang == 'hi' ? guide.descriptionHi : (_selectedLang == 'mr' ? guide.descriptionMr : guide.descriptionEn);
          final rules = _selectedLang == 'hi' ? guide.safetyRulesHi : (_selectedLang == 'mr' ? guide.safetyRulesMr : guide.safetyRulesEn);

          return Card(
            margin: const EdgeInsets.only(bottom: 16),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
            color: Colors.white,
            elevation: 1.5,
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: guide.badgeColor.withValues(alpha: 0.12),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Icon(guide.icon, color: guide.badgeColor, size: 28),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Color(0xFF0F172A))),
                            const SizedBox(height: 4),
                            Text(desc, style: const TextStyle(fontSize: 12, color: Color(0xFF64748B), height: 1.3)),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const Divider(height: 20),
                  const Text('Safety Rules & Standards:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Color(0xFF334155))),
                  const SizedBox(height: 8),
                  ...rules.map((rule) {
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 6.0),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Icon(Icons.check_circle_rounded, color: Color(0xFF155EEF), size: 16),
                          const SizedBox(width: 8),
                          Expanded(child: Text(rule, style: const TextStyle(fontSize: 12, color: Color(0xFF475569)))),
                        ],
                      ),
                    );
                  }),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        side: const BorderSide(color: Color(0xFF155EEF)),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      ),
                      onPressed: () {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('Playing Audio Guidance: $title')),
                        );
                      },
                      icon: const Icon(Icons.volume_up_rounded, color: Color(0xFF155EEF), size: 18),
                      label: Text(_selectedLang == 'hi' ? 'ऑडियो गाइड सुनें' : (_selectedLang == 'mr' ? 'ऑडिओ मार्गदर्शक ऐका' : 'Listen Audio Guide'), style: const TextStyle(color: Color(0xFF155EEF), fontWeight: FontWeight.bold, fontSize: 12)),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
