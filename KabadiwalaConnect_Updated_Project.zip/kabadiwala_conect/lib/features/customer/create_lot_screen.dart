import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../entity/scrap_category.dart';
import '../../models/scrap_lot_model.dart';
import '../../services/app_state.dart';
import '../../services/firestore_service.dart';
import '../../services/offline_sync_service.dart';
import '../../services/cloudinary_service.dart';
import '../../widget/app_svg_icons.dart';
import '../../widget/responsive.dart';
import '../../ai/ai_service.dart';
import '../../screens/bottom_nav_bar.dart';

class CreateLotScreen extends StatefulWidget {
  const CreateLotScreen({super.key});

  @override
  State<CreateLotScreen> createState() => _CreateLotScreenState();
}

class _CreateLotScreenState extends State<CreateLotScreen> {
  final _formKey = GlobalKey<FormState>();
  ScrapCategory _selectedCategory = ScrapCategory.allCategories.first;
  XFile? _selectedImage;
  final ImagePicker _picker = ImagePicker();

  double _estimatedWeightKg = 15.0;
  bool _isAnalyzingAI = false;
  AIScannerResult? _aiResult;

  final TextEditingController _notesController = TextEditingController(text: 'Segregated & packed in corrugated boxes.');
  final TextEditingController _addressController = TextEditingController(text: 'House 402, Block C, Sector 62, Noida, UP');
  final TextEditingController _phoneController = TextEditingController(text: '+91 98765 43210');

  @override
  void dispose() {
    _notesController.dispose();
    _addressController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final img = await _picker.pickImage(source: source, imageQuality: 80);
      if (img != null) {
        setState(() {
          _selectedImage = img;
          _isAnalyzingAI = true;
          _aiResult = null;
        });

        // Run AI Computer Vision estimation
        final result = await AIService.analyzeAndSegregateScrapImage(_selectedCategory.type.toString().split('.').last);
        if (mounted) {
          setState(() {
            _isAnalyzingAI = false;
            _aiResult = result;
          });
        }
      }
    } catch (_) {
      setState(() {
        _isAnalyzingAI = false;
      });
    }
  }

  void _submitScrapLot(AppState appState) {
    final currentUid = FirebaseAuth.instance.currentUser?.uid ?? 'cust_101';
    final address = _addressController.text.trim().isNotEmpty
        ? _addressController.text.trim()
        : 'House 402, Block C, Sector 62, Noida, UP';

    final lotId = 'LOT-${DateTime.now().millisecondsSinceEpoch.toString().substring(7)}';

    final newLot = ScrapLotModel(
      lotId: lotId,
      customerId: currentUid,
      categoryType: _selectedCategory.type,
      subCategoryName: _selectedCategory.name,
      description: _notesController.text.trim().isNotEmpty ? _notesController.text.trim() : 'Household scrap lot',
      imageUrls: _selectedImage != null ? [_selectedImage!.path] : ['https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?w=500'],
      estimatedWeightKg: _estimatedWeightKg,
      estimatedRatePerKg: _selectedCategory.ratePerKg,
      estimatedTotalValue: _selectedCategory.ratePerKg * _estimatedWeightKg,
      locationAddress: address,
      status: ScrapLotStatus.submitted,
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );

    // 1. Add to Live Public Feed in AppState immediately so home page updates instantly
    appState.addListingFromModel(newLot);

    // 2. Redirect to Home Page SIMULTANEOUSLY
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => const BottomNavBar(initialIndex: 0)),
      (route) => false,
    );

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Scrap Lot $lotId Published! Uploading to server in background...'),
        backgroundColor: const Color(0xFF155EEF),
        duration: const Duration(seconds: 3),
      ),
    );

    // 3. Perform Cloudinary image upload and Firestore database write concurrently in background
    Future.microtask(() async {
      try {
        String finalImageUrl = newLot.imageUrls.first;
        if (_selectedImage != null) {
          final uploadedUrl = await CloudinaryService.uploadImage(_selectedImage!.path);
          if (uploadedUrl != null && uploadedUrl.isNotEmpty) {
            finalImageUrl = uploadedUrl;
          }
        }

        final firestoreService = FirestoreService();
        await firestoreService.createScrapLot(newLot);

        final syncService = OfflineSyncService();
        syncService.queueScrapLotCreation(newLot);

        debugPrint('Background synchronization complete for lot $lotId with image $finalImageUrl');
      } catch (e) {
        debugPrint('Background sync exception: $e');
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);
    final estimatedTotalPayout = _selectedCategory.ratePerKg * _estimatedWeightKg;
    final estimatedCo2Saved = _estimatedWeightKg * _selectedCategory.co2Factor;

    return Scaffold(
      backgroundColor: const Color(0xFFF7FAFF),
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        title: const Text('Sell Scrap • Create Lot', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: Color(0xFF0B1F3A))),
      ),
      body: SafeArea(
        child: Align(
          alignment: Alignment.topCenter,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 700),
            child: SingleChildScrollView(
              padding: EdgeInsets.all(Responsive.width(context, 4)),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Step 1: Select Scrap Category
                    Text('1. Select Material Category:', style: TextStyle(fontSize: Responsive.sp(context, 14), fontWeight: FontWeight.bold, color: const Color(0xFF0B1F3A))),
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: const Color(0xFFE2E8F0)),
                      ),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<ScrapCategory>(
                          value: _selectedCategory,
                          isExpanded: true,
                          icon: const Icon(Icons.keyboard_arrow_down_rounded, color: Color(0xFF155EEF)),
                          onChanged: (cat) {
                            if (cat != null) {
                              setState(() {
                                _selectedCategory = cat;
                              });
                            }
                          },
                          items: ScrapCategory.allCategories.map((cat) {
                            return DropdownMenuItem(
                              value: cat,
                              child: Row(
                                children: [
                                  CircleAvatar(
                                    radius: 14,
                                    backgroundColor: cat.color.withValues(alpha: 0.15),
                                    child: Icon(cat.icon, size: 16, color: cat.color),
                                  ),
                                  const SizedBox(width: 10),
                                  Text(cat.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                                  const Spacer(),
                                  Text('₹${cat.ratePerKg.toStringAsFixed(0)}/kg', style: const TextStyle(color: Color(0xFF155EEF), fontWeight: FontWeight.w900, fontSize: 13)),
                                ],
                              ),
                            );
                          }).toList(),
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),

                    // Step 2: Capture / Upload Photo
                    Text('2. Capture or Upload Scrap Photo:', style: TextStyle(fontSize: Responsive.sp(context, 14), fontWeight: FontWeight.bold, color: const Color(0xFF0B1F3A))),
                    const SizedBox(height: 8),
                    Container(
                      height: 180,
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(color: const Color(0xFFE2E8F0)),
                      ),
                      child: _selectedImage != null
                          ? ClipRRect(
                              borderRadius: BorderRadius.circular(18),
                              child: Stack(
                                children: [
                                  kIsWeb
                                      ? Image.network(_selectedImage!.path, width: double.infinity, height: double.infinity, fit: BoxFit.cover)
                                      : Image.file(File(_selectedImage!.path), width: double.infinity, height: double.infinity, fit: BoxFit.cover),
                                  Positioned(
                                    top: 10,
                                    right: 10,
                                    child: CircleAvatar(
                                      backgroundColor: Colors.black54,
                                      child: IconButton(
                                        icon: const Icon(Icons.refresh_rounded, color: Colors.white, size: 20),
                                        onPressed: () => _pickImage(ImageSource.camera),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            )
                          : Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const AppSvgIconWidget(svgData: AppSvgIcons.cameraIcon, size: 40, color: Color(0xFF155EEF)),
                                const SizedBox(height: 10),
                                const Text('Take photo for AI material purity estimation', style: TextStyle(color: Color(0xFF64748B), fontSize: 12)),
                                const SizedBox(height: 14),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    ElevatedButton.icon(
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: const Color(0xFF155EEF),
                                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                                      ),
                                      onPressed: () => _pickImage(ImageSource.camera),
                                      icon: const Icon(Icons.camera_alt_rounded, size: 16, color: Colors.white),
                                      label: const Text('Camera', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12)),
                                    ),
                                    const SizedBox(width: 10),
                                    OutlinedButton.icon(
                                      style: OutlinedButton.styleFrom(
                                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                                        side: const BorderSide(color: Color(0xFF155EEF)),
                                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                                      ),
                                      onPressed: () => _pickImage(ImageSource.gallery),
                                      icon: const Icon(Icons.photo_library_rounded, size: 16, color: Color(0xFF155EEF)),
                                      label: const Text('Gallery', style: TextStyle(color: Color(0xFF155EEF), fontWeight: FontWeight.bold, fontSize: 12)),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                    ),

                    if (_isAnalyzingAI) ...[
                      const SizedBox(height: 12),
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(color: const Color(0xFFEFF6FF), borderRadius: BorderRadius.circular(12)),
                        child: Row(
                          children: const [
                            CircularProgressIndicator(color: Color(0xFF155EEF), strokeWidth: 2),
                            SizedBox(width: 12),
                            Text('AI Computer Vision analyzing material purity...', style: TextStyle(color: Color(0xFF1D4ED8), fontWeight: FontWeight.bold, fontSize: 12)),
                          ],
                        ),
                      ),
                    ],

                    if (_aiResult != null && !_isAnalyzingAI) ...[
                      const SizedBox(height: 12),
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: const Color(0xFFEFF6FF),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: const Color(0xFFD9E7FF)),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.auto_awesome_rounded, color: Color(0xFF155EEF), size: 22),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                'AI Detected: ${_aiResult!.title} • ${(_aiResult!.overallPurityScore * 100).toStringAsFixed(0)}% Purity Confidence',
                                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: Color(0xFF1D4ED8)),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                    const SizedBox(height: 20),

                    // Step 3: Estimated Weight Slider
                    Text('3. Approximate Weight (kg):', style: TextStyle(fontSize: Responsive.sp(context, 14), fontWeight: FontWeight.bold, color: const Color(0xFF0B1F3A))),
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(color: const Color(0xFFE2E8F0)),
                      ),
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('Approximate Quantity:', style: TextStyle(color: Color(0xFF64748B), fontSize: 13)),
                              Text('${_estimatedWeightKg.toStringAsFixed(0)} kg', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18, color: Color(0xFF155EEF))),
                            ],
                          ),
                          Slider(
                            value: _estimatedWeightKg,
                            min: 2,
                            max: 150,
                            divisions: 74,
                            activeColor: const Color(0xFF155EEF),
                            onChanged: (val) {
                              setState(() {
                                _estimatedWeightKg = val;
                              });
                            },
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text('Est. Payout: ₹${estimatedTotalPayout.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: Color(0xFF155EEF))),
                              Text('CO₂ Offset: ${estimatedCo2Saved.toStringAsFixed(1)}kg', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Color(0xFF3B82F6))),
                            ],
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),

                    // Step 4: Address & Phone Details
                    Text('4. Pickup Location & Phone:', style: TextStyle(fontSize: Responsive.sp(context, 14), fontWeight: FontWeight.bold, color: const Color(0xFF0B1F3A))),
                    const SizedBox(height: 8),
                    TextFormField(
                      controller: _addressController,
                      decoration: InputDecoration(
                        labelText: 'Pickup Address',
                        prefixIcon: const Icon(Icons.location_on_outlined, color: Color(0xFF155EEF)),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
                        filled: true,
                        fillColor: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: _phoneController,
                      keyboardType: TextInputType.phone,
                      decoration: InputDecoration(
                        labelText: 'Contact Phone for Pickup',
                        prefixIcon: const Icon(Icons.phone_outlined, color: Color(0xFF155EEF)),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
                        filled: true,
                        fillColor: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 24),

                    // Submit Button
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF155EEF), // Deep Blue
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          elevation: 2,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                        ),
                        onPressed: () => _submitScrapLot(appState),
                        icon: const Icon(Icons.send_rounded, color: Colors.white),
                        label: Text(
                          'Publish Scrap Lot & Request Pickup',
                          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: Responsive.sp(context, 14)),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
