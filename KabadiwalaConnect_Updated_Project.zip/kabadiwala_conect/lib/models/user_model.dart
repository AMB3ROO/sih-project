import 'package:flutter/material.dart';

enum UserRole {
  customer,
  kabadiwala,
  recycler,
  admin,
}

extension UserRoleExtension on UserRole {
  String get roleKey {
    switch (this) {
      case UserRole.customer:
        return 'customer';
      case UserRole.kabadiwala:
        return 'kabadiwala';
      case UserRole.recycler:
        return 'recycler';
      case UserRole.admin:
        return 'admin';
    }
  }

  String get displayName {
    switch (this) {
      case UserRole.customer:
        return 'Household Seller';
      case UserRole.kabadiwala:
        return 'Kabadiwala Trader';
      case UserRole.recycler:
        return 'Industrial Recycler';
      case UserRole.admin:
        return 'Platform Admin';
    }
  }

  IconData get icon {
    switch (this) {
      case UserRole.customer:
        return Icons.home_rounded;
      case UserRole.kabadiwala:
        return Icons.local_shipping_rounded;
      case UserRole.recycler:
        return Icons.factory_rounded;
      case UserRole.admin:
        return Icons.admin_panel_settings_rounded;
    }
  }

  static UserRole fromString(String key) {
    switch (key.toLowerCase()) {
      case 'kabadiwala':
      case 'trader':
        return UserRole.kabadiwala;
      case 'recycler':
      case 'factory':
        return UserRole.recycler;
      case 'admin':
        return UserRole.admin;
      case 'customer':
      default:
        return UserRole.customer;
    }
  }
}

class UserModel {
  final String uid;
  final String name;
  final String phone;
  final String email;
  final UserRole role;
  final String preferredLanguage; // 'en', 'hi', 'mr'
  final String? profileImageUrl;
  final String operatingArea;
  final String address;
  final double latitude;
  final double longitude;
  final bool isAuthorizedRecycler;
  final String? authorizationRegNumber;
  final List<String> acceptedMaterials;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isActive;

  UserModel({
    required this.uid,
    required this.name,
    required this.phone,
    this.email = '',
    required this.role,
    this.preferredLanguage = 'en',
    this.profileImageUrl,
    this.operatingArea = 'Sector 62, Noida, UP',
    this.address = 'House 402, Block C, Sector 62, Noida, UP - 201309',
    this.latitude = 28.6273,
    this.longitude = 77.3725,
    this.isAuthorizedRecycler = false,
    this.authorizationRegNumber,
    this.acceptedMaterials = const ['Paper', 'Plastic', 'Metal', 'E-Waste', 'Glass', 'Cardboard'],
    required this.createdAt,
    required this.updatedAt,
    this.isActive = true,
  });

  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'name': name,
      'phone': phone,
      'email': email,
      'role': role.roleKey,
      'preferredLanguage': preferredLanguage,
      'profileImageUrl': profileImageUrl,
      'operatingArea': operatingArea,
      'address': address,
      'latitude': latitude,
      'longitude': longitude,
      'isAuthorizedRecycler': isAuthorizedRecycler,
      'authorizationRegNumber': authorizationRegNumber,
      'acceptedMaterials': acceptedMaterials,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
      'isActive': isActive,
    };
  }

  factory UserModel.fromMap(Map<String, dynamic> map, String docId) {
    return UserModel(
      uid: docId,
      name: map['name'] ?? 'Rahul Sharma',
      phone: map['phone'] ?? '+91 98765 43210',
      email: map['email'] ?? '',
      role: UserRoleExtension.fromString(map['role'] ?? 'customer'),
      preferredLanguage: map['preferredLanguage'] ?? 'en',
      profileImageUrl: map['profileImageUrl'],
      operatingArea: map['operatingArea'] ?? 'Sector 62, Noida, UP',
      address: map['address'] ?? 'Sector 62, Noida, UP',
      latitude: (map['latitude'] as num?)?.toDouble() ?? 28.6273,
      longitude: (map['longitude'] as num?)?.toDouble() ?? 77.3725,
      isAuthorizedRecycler: map['isAuthorizedRecycler'] ?? false,
      authorizationRegNumber: map['authorizationRegNumber'],
      acceptedMaterials: List<String>.from(map['acceptedMaterials'] ?? ['Paper', 'Plastic', 'Metal', 'E-Waste', 'Glass', 'Cardboard']),
      createdAt: map['createdAt'] != null ? DateTime.parse(map['createdAt']) : DateTime.now(),
      updatedAt: map['updatedAt'] != null ? DateTime.parse(map['updatedAt']) : DateTime.now(),
      isActive: map['isActive'] ?? true,
    );
  }
}
