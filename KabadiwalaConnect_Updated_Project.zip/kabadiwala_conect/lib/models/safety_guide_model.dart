import 'package:flutter/material.dart';

class SafetyGuideModel {
  final String id;
  final String titleEn;
  final String titleHi;
  final String titleMr;
  final String descriptionEn;
  final String descriptionHi;
  final String descriptionMr;
  final String hazardCategory; // 'batteries', 'crt', 'cables', 'pcb', 'e_waste'
  final IconData icon;
  final Color badgeColor;
  final List<String> safetyRulesEn;
  final List<String> safetyRulesHi;
  final List<String> safetyRulesMr;

  SafetyGuideModel({
    required this.id,
    required this.titleEn,
    required this.titleHi,
    required this.titleMr,
    required this.descriptionEn,
    required this.descriptionHi,
    required this.descriptionMr,
    required this.hazardCategory,
    required this.icon,
    required this.badgeColor,
    required this.safetyRulesEn,
    required this.safetyRulesHi,
    required this.safetyRulesMr,
  });

  static List<SafetyGuideModel> get defaultSafetyGuides => [
    SafetyGuideModel(
      id: 'sg_battery',
      titleEn: 'Lithium & Lead Batteries',
      titleHi: 'बैटरियां और लीड सेल',
      titleMr: 'बॅटरी आणि लेड सेल्स',
      descriptionEn: 'Do not puncture, crush, or burn batteries to prevent fires.',
      descriptionHi: 'आग से बचने के लिए बैटरियों को पंचर न करें या न जलाएं।',
      descriptionMr: 'आगीचा धोका टाळण्यासाठी बॅटरी फोडू नका किंवा जाळू नका.',
      hazardCategory: 'batteries',
      icon: Icons.battery_alert_rounded,
      badgeColor: const Color(0xFFEF4444),
      safetyRulesEn: [
        'Store in cool, dry place away from heat.',
        'Keep battery terminals covered with tape.',
        'Never submerge in water or burn in open air.',
      ],
      safetyRulesHi: [
        'गर्मी से दूर ठंडी, सूखी जगह पर रखें।',
        'टर्मिनल्स को टेप से ढक कर रखें।',
        'कभी भी पानी में न डुबोएं या खुले में न जलाएं।',
      ],
      safetyRulesMr: [
        'थंड आणि कोरड्या जागी ठेवा.',
        'टर्मिनलवर टेप लावा.',
        'पाण्यात टाकू नका किंवा उघड्यावर जाळू नका.',
      ],
    ),
    SafetyGuideModel(
      id: 'sg_cable',
      titleEn: 'Copper Cable Burning Warning',
      titleHi: 'कॉपर केबल जलने की चेतावनी',
      titleMr: 'कॉपर केबल जाळण्याची चेतावणी',
      descriptionEn: 'Never burn plastic insulation off copper wires. Burning releases toxic dioxin gas.',
      descriptionHi: 'तारों से प्लास्टिक हटाने के लिए कभी न जलाएं। जहरीली गैस निकलती है।',
      descriptionMr: 'प्लास्टिक काढण्यासाठी वायर जाळू नका. विषारी वायू बाहेर पडतो.',
      hazardCategory: 'cables',
      icon: Icons.local_fire_department_rounded,
      badgeColor: const Color(0xFFF59E0B),
      safetyRulesEn: [
        'Use mechanical wire strippers only.',
        'Avoid inhaling fumes from heated PVC cables.',
        'Sell insulated wire directly at authorized rates.',
      ],
      safetyRulesHi: [
        'केवल केबल स्ट्रिपर टूल का उपयोग करें।',
        'जहरीले धुएं से बचें।',
        'इंसुलेटेड वायर को सीधे अधिकृत रेट पर बेचें।',
      ],
      safetyRulesMr: [
        'केवळ वायर स्ट्रिपर वापरा.',
        'विषारी धुरापासून लांब राहा.',
        'थेट अधिकृत दराने विक्री करा.',
      ],
    ),
    SafetyGuideModel(
      id: 'sg_ewaste',
      titleEn: 'E-Waste & Computer PCBs',
      titleHi: 'ई-कचरा और मदरबोर्ड',
      titleMr: 'ई-कचरा आणि मदरबोर्ड',
      descriptionEn: 'Avoid dismantling circuit boards manually without gloves and masks.',
      descriptionHi: 'बिना दस्ताने और मास्क के ई-कचरे को न तोड़ें।',
      descriptionMr: 'हातमोजे आणि मास्कशिवाय ई-कचरा तोडू नका.',
      hazardCategory: 'pcb',
      icon: Icons.developer_board_rounded,
      badgeColor: const Color(0xFF3B82F6),
      safetyRulesEn: [
        'Wear protective gloves when handling sharp PCB edges.',
        'Keep electronic scrap dry to avoid heavy metal leaching.',
        'Handover to authorized recyclers with EPA verification.',
      ],
      safetyRulesHi: [
        'तेज किनारों से बचने के लिए दस्ताने पहनें।',
        'ई-कचरे को सूखा रखें।',
        'केवल अधिकृत रिसाइक्लर्स को ही सौंपें।',
      ],
      safetyRulesMr: [
        'हातमोजे वापरा.',
        'ई-कचरा कोरडा ठेवा.',
        'अधिकृत रीसायकलर्सनाच द्या.',
      ],
    ),
  ];
}
