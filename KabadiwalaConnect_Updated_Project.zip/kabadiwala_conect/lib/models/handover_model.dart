class DigitalHandoverModel {
  final String handoverId;
  final String orderIdOrLotId;
  final String collectorUid;
  final String collectorName;
  final String recyclerUid;
  final String recyclerName;
  final String materialName;

  final double estimatedWeightKg;
  final double verifiedWeightKg;

  final double finalAmountPaid;
  final String paymentMethod; // 'cash', 'upi', 'bank_transfer'
  final String paymentReference;

  final String qrPayloadString;
  final String pickupLocation;

  final bool customerConfirmed;
  final bool collectorConfirmed;
  final bool recyclerConfirmed;

  final DateTime timestamp;

  DigitalHandoverModel({
    required this.handoverId,
    required this.orderIdOrLotId,
    required this.collectorUid,
    required this.collectorName,
    required this.recyclerUid,
    required this.recyclerName,
    required this.materialName,
    required this.estimatedWeightKg,
    required this.verifiedWeightKg,
    required this.finalAmountPaid,
    this.paymentMethod = 'upi',
    this.paymentReference = 'UPI/20260917/SUCCESS',
    required this.qrPayloadString,
    required this.pickupLocation,
    this.customerConfirmed = true,
    this.collectorConfirmed = true,
    this.recyclerConfirmed = true,
    required this.timestamp,
  });

  Map<String, dynamic> toMap() {
    return {
      'handoverId': handoverId,
      'orderIdOrLotId': orderIdOrLotId,
      'collectorUid': collectorUid,
      'collectorName': collectorName,
      'recyclerUid': recyclerUid,
      'recyclerName': recyclerName,
      'materialName': materialName,
      'estimatedWeightKg': estimatedWeightKg,
      'verifiedWeightKg': verifiedWeightKg,
      'finalAmountPaid': finalAmountPaid,
      'paymentMethod': paymentMethod,
      'paymentReference': paymentReference,
      'qrPayloadString': qrPayloadString,
      'pickupLocation': pickupLocation,
      'customerConfirmed': customerConfirmed,
      'collectorConfirmed': collectorConfirmed,
      'recyclerConfirmed': recyclerConfirmed,
      'timestamp': timestamp.toIso8601String(),
    };
  }

  factory DigitalHandoverModel.fromMap(Map<String, dynamic> map, String docId) {
    return DigitalHandoverModel(
      handoverId: docId,
      orderIdOrLotId: map['orderIdOrLotId'] ?? 'KC-10291',
      collectorUid: map['collectorUid'] ?? 'trader_101',
      collectorName: map['collectorName'] ?? 'Ramesh Scrap Depot',
      recyclerUid: map['recyclerUid'] ?? 'recycler_202',
      recyclerName: map['recyclerName'] ?? 'GreenTech Polymers Ltd.',
      materialName: map['materialName'] ?? 'PET Plastic & Copper Wire Batch',
      estimatedWeightKg: (map['estimatedWeightKg'] as num?)?.toDouble() ?? 20.0,
      verifiedWeightKg: (map['verifiedWeightKg'] as num?)?.toDouble() ?? 18.5,
      finalAmountPaid: (map['finalAmountPaid'] as num?)?.toDouble() ?? 1250.0,
      paymentMethod: map['paymentMethod'] ?? 'upi',
      paymentReference: map['paymentReference'] ?? 'UPI/20260917/SUCCESS',
      qrPayloadString: map['qrPayloadString'] ?? 'KABADIWALA-CONNECT:HO-10291',
      pickupLocation: map['pickupLocation'] ?? 'Sector 62, Noida, UP',
      customerConfirmed: map['customerConfirmed'] ?? true,
      collectorConfirmed: map['collectorConfirmed'] ?? true,
      recyclerConfirmed: map['recyclerConfirmed'] ?? true,
      timestamp: map['timestamp'] != null ? DateTime.parse(map['timestamp']) : DateTime.now(),
    );
  }
}
