import '../entity/scrap_category.dart';

class PriceModel {
  final String priceId;
  final ScrapCategoryType categoryType;
  final String subCategoryName;
  final String locationRegion;
  final double buyingRatePerKg;
  final double sellingRatePerKg;
  final double percentageTrendChange;
  final String trendDirection; // 'up', 'down', 'stable'
  final DateTime updatedAt;

  PriceModel({
    required this.priceId,
    required this.categoryType,
    required this.subCategoryName,
    this.locationRegion = 'Noida & NCR Region',
    required this.buyingRatePerKg,
    required this.sellingRatePerKg,
    this.percentageTrendChange = 2.4,
    this.trendDirection = 'up',
    required this.updatedAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'priceId': priceId,
      'categoryType': categoryType.toString().split('.').last,
      'subCategoryName': subCategoryName,
      'locationRegion': locationRegion,
      'buyingRatePerKg': buyingRatePerKg,
      'sellingRatePerKg': sellingRatePerKg,
      'percentageTrendChange': percentageTrendChange,
      'trendDirection': trendDirection,
      'updatedAt': updatedAt.toIso8601String(),
    };
  }

  factory PriceModel.fromMap(Map<String, dynamic> map, String docId) {
    return PriceModel(
      priceId: docId,
      categoryType: ScrapCategory.allCategories
          .firstWhere((c) => c.type.toString().split('.').last == map['categoryType'], orElse: () => ScrapCategory.allCategories.first)
          .type,
      subCategoryName: map['subCategoryName'] ?? 'Copper Heavy Wire',
      locationRegion: map['locationRegion'] ?? 'Noida & NCR Region',
      buyingRatePerKg: (map['buyingRatePerKg'] as num?)?.toDouble() ?? 580.0,
      sellingRatePerKg: (map['sellingRatePerKg'] as num?)?.toDouble() ?? 620.0,
      percentageTrendChange: (map['percentageTrendChange'] as num?)?.toDouble() ?? 2.4,
      trendDirection: map['trendDirection'] ?? 'up',
      updatedAt: map['updatedAt'] != null ? DateTime.parse(map['updatedAt']) : DateTime.now(),
    );
  }
}
