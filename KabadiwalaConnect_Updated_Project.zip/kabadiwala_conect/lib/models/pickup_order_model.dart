class PickupOrderModel {
  final String orderId;
  final String customerId;
  final List<String> scrapLotIds;

  final String customerName;
  final String customerPhone;
  final String pickupAddress;
  final double latitude;
  final double longitude;

  final DateTime scheduledDate;
  final String timeSlot;

  final String? assignedKabadiwalaId;
  final String? assignedKabadiwalaName;
  final String? assignedKabadiwalaPhone;

  final double totalEstimatedWeightKg;
  final double? totalVerifiedWeightKg;

  final double totalEstimatedAmount;
  final double? finalVerifiedAmount;

  final String orderStatus; // 'matching', 'assigned', 'on_the_way', 'arrived', 'completed', 'cancelled'
  final String paymentStatus; // 'pending', 'cash_paid', 'upi_paid', 'completed'
  final String paymentMethod; // 'cash', 'upi', 'bank_transfer'
  final DateTime createdAt;

  PickupOrderModel({
    required this.orderId,
    required this.customerId,
    required this.scrapLotIds,
    required this.customerName,
    required this.customerPhone,
    required this.pickupAddress,
    this.latitude = 28.6273,
    this.longitude = 77.3725,
    required this.scheduledDate,
    required this.timeSlot,
    this.assignedKabadiwalaId,
    this.assignedKabadiwalaName,
    this.assignedKabadiwalaPhone,
    required this.totalEstimatedWeightKg,
    this.totalVerifiedWeightKg,
    required this.totalEstimatedAmount,
    this.finalVerifiedAmount,
    this.orderStatus = 'matching',
    this.paymentStatus = 'pending',
    this.paymentMethod = 'upi',
    required this.createdAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'orderId': orderId,
      'customerId': customerId,
      'scrapLotIds': scrapLotIds,
      'customerName': customerName,
      'customerPhone': customerPhone,
      'pickupAddress': pickupAddress,
      'latitude': latitude,
      'longitude': longitude,
      'scheduledDate': scheduledDate.toIso8601String(),
      'timeSlot': timeSlot,
      'assignedKabadiwalaId': assignedKabadiwalaId,
      'assignedKabadiwalaName': assignedKabadiwalaName,
      'assignedKabadiwalaPhone': assignedKabadiwalaPhone,
      'totalEstimatedWeightKg': totalEstimatedWeightKg,
      'totalVerifiedWeightKg': totalVerifiedWeightKg,
      'totalEstimatedAmount': totalEstimatedAmount,
      'finalVerifiedAmount': finalVerifiedAmount,
      'orderStatus': orderStatus,
      'paymentStatus': paymentStatus,
      'paymentMethod': paymentMethod,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  factory PickupOrderModel.fromMap(Map<String, dynamic> map, String docId) {
    return PickupOrderModel(
      orderId: docId,
      customerId: map['customerId'] ?? 'cust_101',
      scrapLotIds: List<String>.from(map['scrapLotIds'] ?? []),
      customerName: map['customerName'] ?? 'Rahul Sharma',
      customerPhone: map['customerPhone'] ?? '+91 98765 43210',
      pickupAddress: map['pickupAddress'] ?? 'House 402, Sector 62, Noida, UP',
      latitude: (map['latitude'] as num?)?.toDouble() ?? 28.6273,
      longitude: (map['longitude'] as num?)?.toDouble() ?? 77.3725,
      scheduledDate: map['scheduledDate'] != null ? DateTime.parse(map['scheduledDate']) : DateTime.now().add(const Duration(days: 1)),
      timeSlot: map['timeSlot'] ?? '10:00 AM - 12:00 PM',
      assignedKabadiwalaId: map['assignedKabadiwalaId'],
      assignedKabadiwalaName: map['assignedKabadiwalaName'],
      assignedKabadiwalaPhone: map['assignedKabadiwalaPhone'],
      totalEstimatedWeightKg: (map['totalEstimatedWeightKg'] as num?)?.toDouble() ?? 25.0,
      totalVerifiedWeightKg: (map['totalVerifiedWeightKg'] as num?)?.toDouble(),
      totalEstimatedAmount: (map['totalEstimatedAmount'] as num?)?.toDouble() ?? 450.0,
      finalVerifiedAmount: (map['finalVerifiedAmount'] as num?)?.toDouble(),
      orderStatus: map['orderStatus'] ?? 'matching',
      paymentStatus: map['paymentStatus'] ?? 'pending',
      paymentMethod: map['paymentMethod'] ?? 'upi',
      createdAt: map['createdAt'] != null ? DateTime.parse(map['createdAt']) : DateTime.now(),
    );
  }
}
