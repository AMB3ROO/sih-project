import '../entity/scrap_category.dart';

enum ScrapLotStatus {
  draft,
  submitted,
  matching,
  offerReceived,
  accepted,
  pickupScheduled,
  collectorAssigned,
  pickedUp,
  weightVerified,
  paymentPending,
  paid,
  handoverCompleted,
  sentToRecycler,
  recycled,
  cancelled,
}

extension ScrapLotStatusExtension on ScrapLotStatus {
  String get displayName {
    switch (this) {
      case ScrapLotStatus.draft:
        return 'Draft Lot';
      case ScrapLotStatus.submitted:
        return 'Submitted';
      case ScrapLotStatus.matching:
        return 'Matching Recyclers';
      case ScrapLotStatus.offerReceived:
        return 'Offer Received';
      case ScrapLotStatus.accepted:
        return 'Accepted';
      case ScrapLotStatus.pickupScheduled:
        return 'Pickup Scheduled';
      case ScrapLotStatus.collectorAssigned:
        return 'Collector Assigned';
      case ScrapLotStatus.pickedUp:
        return 'Picked Up';
      case ScrapLotStatus.weightVerified:
        return 'Weight Verified';
      case ScrapLotStatus.paymentPending:
        return 'Payment Pending';
      case ScrapLotStatus.paid:
        return 'Paid';
      case ScrapLotStatus.handoverCompleted:
        return 'Handover Completed';
      case ScrapLotStatus.sentToRecycler:
        return 'Sent to Recycler';
      case ScrapLotStatus.recycled:
        return 'Recycled';
      case ScrapLotStatus.cancelled:
        return 'Cancelled';
    }
  }

  static ScrapLotStatus fromString(String statusStr) {
    return ScrapLotStatus.values.firstWhere(
      (e) => e.toString().split('.').last == statusStr,
      orElse: () => ScrapLotStatus.submitted,
    );
  }
}

class ScrapLotModel {
  final String lotId;
  final String customerId;
  final String? collectorId;
  final String? recyclerId;

  final ScrapCategoryType categoryType;
  final String subCategoryName;
  final String description;
  final List<String> imageUrls;

  final double estimatedWeightKg;
  final double? actualVerifiedWeightKg;

  final String conditionNote; // e.g. 'Clean & Segregated', 'Mixed'
  final double aiPurityConfidenceScore;

  final double estimatedRatePerKg;
  final double estimatedTotalValue;
  final double? finalQuotedValue;

  final String locationAddress;
  final double latitude;
  final double longitude;

  final ScrapLotStatus status;
  final DateTime createdAt;
  final DateTime updatedAt;

  ScrapLotModel({
    required this.lotId,
    required this.customerId,
    this.collectorId,
    this.recyclerId,
    required this.categoryType,
    required this.subCategoryName,
    required this.description,
    this.imageUrls = const [],
    required this.estimatedWeightKg,
    this.actualVerifiedWeightKg,
    this.conditionNote = 'Clean & Segregated',
    this.aiPurityConfidenceScore = 0.92,
    required this.estimatedRatePerKg,
    required this.estimatedTotalValue,
    this.finalQuotedValue,
    required this.locationAddress,
    this.latitude = 28.6273,
    this.longitude = 77.3725,
    this.status = ScrapLotStatus.submitted,
    required this.createdAt,
    required this.updatedAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'lotId': lotId,
      'customerId': customerId,
      'collectorId': collectorId,
      'recyclerId': recyclerId,
      'categoryType': categoryType.toString().split('.').last,
      'subCategoryName': subCategoryName,
      'description': description,
      'imageUrls': imageUrls,
      'estimatedWeightKg': estimatedWeightKg,
      'actualVerifiedWeightKg': actualVerifiedWeightKg,
      'conditionNote': conditionNote,
      'aiPurityConfidenceScore': aiPurityConfidenceScore,
      'estimatedRatePerKg': estimatedRatePerKg,
      'estimatedTotalValue': estimatedTotalValue,
      'finalQuotedValue': finalQuotedValue,
      'locationAddress': locationAddress,
      'latitude': latitude,
      'longitude': longitude,
      'status': status.toString().split('.').last,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
    };
  }

  factory ScrapLotModel.fromMap(Map<String, dynamic> map, String docId) {
    return ScrapLotModel(
      lotId: docId,
      customerId: map['customerId'] ?? 'cust_101',
      collectorId: map['collectorId'],
      recyclerId: map['recyclerId'],
      categoryType: ScrapCategory.allCategories
          .firstWhere((c) => c.type.toString().split('.').last == map['categoryType'], orElse: () => ScrapCategory.allCategories.first)
          .type,
      subCategoryName: map['subCategoryName'] ?? 'Corrugated Boxes',
      description: map['description'] ?? 'Segregated household scrap lot',
      imageUrls: List<String>.from(map['imageUrls'] ?? []),
      estimatedWeightKg: (map['estimatedWeightKg'] as num?)?.toDouble() ?? 10.0,
      actualVerifiedWeightKg: (map['actualVerifiedWeightKg'] as num?)?.toDouble(),
      conditionNote: map['conditionNote'] ?? 'Clean & Segregated',
      aiPurityConfidenceScore: (map['aiPurityConfidenceScore'] as num?)?.toDouble() ?? 0.92,
      estimatedRatePerKg: (map['estimatedRatePerKg'] as num?)?.toDouble() ?? 15.0,
      estimatedTotalValue: (map['estimatedTotalValue'] as num?)?.toDouble() ?? 150.0,
      finalQuotedValue: (map['finalQuotedValue'] as num?)?.toDouble(),
      locationAddress: map['locationAddress'] ?? 'Sector 62, Noida, UP',
      latitude: (map['latitude'] as num?)?.toDouble() ?? 28.6273,
      longitude: (map['longitude'] as num?)?.toDouble() ?? 77.3725,
      status: ScrapLotStatusExtension.fromString(map['status'] ?? 'submitted'),
      createdAt: map['createdAt'] != null ? DateTime.parse(map['createdAt']) : DateTime.now(),
      updatedAt: map['updatedAt'] != null ? DateTime.parse(map['updatedAt']) : DateTime.now(),
    );
  }
}
