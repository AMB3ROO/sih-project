class MarketplaceOfferModel {
  final String offerId;
  final String orderIdOrLotId;
  final String bidderUid;
  final String bidderName;
  final String bidderPhone;
  final String bidderRole; // 'kabadiwala' or 'recycler'
  final double offeredAmount;
  final String etaTimeSlot;
  final String note;
  final double bidderRating;
  final double distanceKm;
  final String status; // 'pending', 'accepted', 'countered', 'rejected'
  final DateTime createdAt;

  MarketplaceOfferModel({
    required this.offerId,
    required this.orderIdOrLotId,
    required this.bidderUid,
    required this.bidderName,
    required this.bidderPhone,
    required this.bidderRole,
    required this.offeredAmount,
    this.etaTimeSlot = 'Within 2 Hours',
    this.note = 'Instant door pickup & digital weighment',
    this.bidderRating = 4.8,
    this.distanceKm = 1.8,
    this.status = 'pending',
    required this.createdAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'offerId': offerId,
      'orderIdOrLotId': orderIdOrLotId,
      'bidderUid': bidderUid,
      'bidderName': bidderName,
      'bidderPhone': bidderPhone,
      'bidderRole': bidderRole,
      'offeredAmount': offeredAmount,
      'etaTimeSlot': etaTimeSlot,
      'note': note,
      'bidderRating': bidderRating,
      'distanceKm': distanceKm,
      'status': status,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  factory MarketplaceOfferModel.fromMap(Map<String, dynamic> map, String docId) {
    return MarketplaceOfferModel(
      offerId: docId,
      orderIdOrLotId: map['orderIdOrLotId'] ?? 'LOT-101',
      bidderUid: map['bidderUid'] ?? 'trader_101',
      bidderName: map['bidderName'] ?? 'Ramesh Scrap Depot',
      bidderPhone: map['bidderPhone'] ?? '+91 98112 33445',
      bidderRole: map['bidderRole'] ?? 'kabadiwala',
      offeredAmount: (map['offeredAmount'] as num?)?.toDouble() ?? 780.0,
      etaTimeSlot: map['etaTimeSlot'] ?? 'Within 2 Hours',
      note: map['note'] ?? 'Instant doorstep pickup with digital weighing',
      bidderRating: (map['bidderRating'] as num?)?.toDouble() ?? 4.8,
      distanceKm: (map['distanceKm'] as num?)?.toDouble() ?? 1.8,
      status: map['status'] ?? 'pending',
      createdAt: map['createdAt'] != null ? DateTime.parse(map['createdAt']) : DateTime.now(),
    );
  }
}
