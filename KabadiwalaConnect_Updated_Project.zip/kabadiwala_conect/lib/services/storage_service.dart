import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';

class StorageService {
  // Compress & Upload Image File to Storage
  Future<String?> uploadScrapImage({
    required String filePath,
    required String lotId,
  }) async {
    final reference = FirebaseStorage.instance.ref('scrapLots/$lotId.jpg');
    await reference.putFile(File(filePath));
    return reference.getDownloadURL();
  }

  Future<String?> uploadProfileImage({
    required String filePath,
    required String uid,
  }) async {
    final reference = FirebaseStorage.instance.ref('users/$uid/profile.jpg');
    await reference.putFile(File(filePath));
    return reference.getDownloadURL();
  }
}
