import 'package:flutter/material.dart';
import '../entity/scrap_category.dart';
import '../entity/scrap_product.dart';
import '../entity/cart_item.dart';
import '../entity/scrap_listing.dart';
import '../entity/offer.dart';
import '../entity/ledger_transaction.dart';
import '../models/scrap_lot_model.dart';

enum UserRole {
  householdSeller,
  kabadiwalaTrader,
  industrialRecycler,
  platformAdmin,
}

extension UserRoleExtension on UserRole {
  String get displayName {
    switch (this) {
      case UserRole.householdSeller:
        return 'Household Seller';
      case UserRole.kabadiwalaTrader:
        return 'Kabadiwala Trader';
      case UserRole.industrialRecycler:
        return 'Industrial Recycler';
      case UserRole.platformAdmin:
        return 'Platform Admin';
    }
  }

  IconData get icon {
    switch (this) {
      case UserRole.householdSeller:
        return Icons.home_rounded;
      case UserRole.kabadiwalaTrader:
        return Icons.local_shipping_rounded;
      case UserRole.industrialRecycler:
        return Icons.factory_rounded;
      case UserRole.platformAdmin:
        return Icons.admin_panel_settings_rounded;
    }
  }
}

class AppState extends ChangeNotifier {
  bool _isLoggedIn = false;
  bool get isLoggedIn => _isLoggedIn;

  void login({UserRole? role, String? name}) {
    _isLoggedIn = true;
    if (role != null) {
      _currentRole = role;
    }
    if (name != null && name.isNotEmpty) {
      _pickupName = name;
    }
    notifyListeners();
  }

  void logout() {
    _isLoggedIn = false;
    _currentRole = UserRole.householdSeller;
    _pickupName = 'Guest';
    _hasPromptedCameraOnHome = false;
    _isCameraPermissionGranted = false;
    notifyListeners();
  }

  // Language & Localization
  String _selectedLanguageCode = 'en'; // 'en', 'hi', 'mr'
  String get selectedLanguageCode => _selectedLanguageCode;

  void setLanguageCode(String code) {
    if (_selectedLanguageCode != code) {
      _selectedLanguageCode = code;
      notifyListeners();
    }
  }

  // Camera Permission Prompts & Granted Status
  bool _hasPromptedCameraOnHome = false;
  bool get hasPromptedCameraOnHome => _hasPromptedCameraOnHome;

  void setHasPromptedCameraOnHome(bool value) {
    _hasPromptedCameraOnHome = value;
    notifyListeners();
  }

  bool _isCameraPermissionGranted = false;
  bool get isCameraPermissionGranted => _isCameraPermissionGranted;

  void setCameraPermissionGranted(bool granted) {
    _isCameraPermissionGranted = granted;
    notifyListeners();
  }

  UserRole _currentRole = UserRole.householdSeller;
  UserRole get currentRole => _currentRole;

  void setUserRole(UserRole role) {
    _currentRole = role;
    notifyListeners();
  }

  // Filter & Search
  ScrapCategoryType? _selectedCategoryType;
  ScrapCategoryType? get selectedCategoryType => _selectedCategoryType;

  String _searchQuery = '';
  String get searchQuery => _searchQuery;

  void setCategoryFilter(ScrapCategoryType? type) {
    if (_selectedCategoryType == type) {
      _selectedCategoryType = null;
    } else {
      _selectedCategoryType = type;
    }
    notifyListeners();
  }

  void setSearchQuery(String query) {
    _searchQuery = query;
    notifyListeners();
  }

  // Recent & Similar Searches
  final List<String> _recentSearches = [];
  List<String> get recentSearches => List.unmodifiable(_recentSearches);

  final List<String> _similarSearches = [];
  List<String> get similarSearches => List.unmodifiable(_similarSearches);

  void addRecentSearch(String query) {
    final trimmed = query.trim();
    if (trimmed.isEmpty) return;
    _recentSearches.removeWhere(
      (item) => item.toLowerCase() == trimmed.toLowerCase(),
    );
    _recentSearches.insert(0, trimmed);
    if (_recentSearches.length > 8) {
      _recentSearches.removeLast();
    }
    notifyListeners();
  }

  void removeRecentSearch(String term) {
    _recentSearches.removeWhere((item) => item == term);
    notifyListeners();
  }

  void clearRecentSearches() {
    _recentSearches.clear();
    notifyListeners();
  }

  // Favorites
  final Set<String> _favoriteProductIds = {};
  Set<String> get favoriteProductIds => _favoriteProductIds;

  bool isFavorite(String productId) {
    return _favoriteProductIds.contains(productId);
  }

  void toggleFavorite(String productId) {
    if (_favoriteProductIds.contains(productId)) {
      _favoriteProductIds.remove(productId);
    } else {
      _favoriteProductIds.add(productId);
    }
    notifyListeners();
  }

  // Pickup Cart
  final List<PickupCartItem> _cartItems = [];

  List<PickupCartItem> get cartItems => _cartItems;

  void addToCart(ScrapProduct product, {double? customWeight}) {
    final existingIndex = _cartItems.indexWhere(
      (item) => item.product.id == product.id,
    );
    if (existingIndex >= 0) {
      _cartItems[existingIndex].weightKg += (customWeight ?? 5.0);
    } else {
      _cartItems.add(
        PickupCartItem(
          product: product,
          weightKg: customWeight ?? product.defaultWeightKg,
        ),
      );
    }
    notifyListeners();
  }

  void updateCartItemWeight(String productId, double weightKg) {
    final index = _cartItems.indexWhere((item) => item.product.id == productId);
    if (index >= 0) {
      if (weightKg <= 0) {
        _cartItems.removeAt(index);
      } else {
        _cartItems[index].weightKg = weightKg;
      }
      notifyListeners();
    }
  }

  void removeFromCart(String productId) {
    _cartItems.removeWhere((item) => item.product.id == productId);
    notifyListeners();
  }

  void clearCart() {
    _cartItems.clear();
    notifyListeners();
  }

  double get cartTotalEstimatedPayout =>
      _cartItems.fold(0.0, (sum, item) => sum + item.totalPayout);

  double get cartTotalWeightKg =>
      _cartItems.fold(0.0, (sum, item) => sum + item.weightKg);

  double get cartTotalCo2Saved =>
      _cartItems.fold(0.0, (sum, item) => sum + item.co2Saved);

  // Pickup Address & Schedule
  String _pickupAddress = '';
  String _pickupMobile = '';
  String _pickupName = '';
  DateTime _pickupDate = DateTime.now();
  String _pickupTimeSlot = '';

  String get pickupAddress => _pickupAddress;
  String get pickupMobile => _pickupMobile;
  String get pickupName => _pickupName;
  DateTime get pickupDate => _pickupDate;
  String get pickupTimeSlot => _pickupTimeSlot;

  void setPickupDetails({
    required String name,
    required String mobile,
    required String address,
    required DateTime date,
    required String timeSlot,
  }) {
    _pickupName = name;
    _pickupMobile = mobile;
    _pickupAddress = address;
    _pickupDate = date;
    _pickupTimeSlot = timeSlot;
    notifyListeners();
  }

  // Active Marketplace Listings
  final List<ScrapListing> _listings = [];
  List<ScrapListing> get listings => _listings;

  void addListing(ScrapListing listing) {
    _listings.insert(0, listing);
    notifyListeners();
  }

  void addListingFromModel(ScrapLotModel lotModel) {
    final listing = ScrapListing(
      id: lotModel.lotId,
      title:
          '${lotModel.subCategoryName} (${lotModel.estimatedWeightKg.toStringAsFixed(0)}kg)',
      items: [
        SegregatedItem(
          itemName: lotModel.subCategoryName,
          categoryType: lotModel.categoryType,
          confidenceScore: lotModel.aiPurityConfidenceScore,
          estimatedWeightKg: lotModel.estimatedWeightKg,
          ratePerKg: lotModel.estimatedRatePerKg,
          conditionNote: lotModel.conditionNote,
        ),
      ],
      location: lotModel.locationAddress,
      imageUrl: lotModel.imageUrls.isNotEmpty
          ? lotModel.imageUrls.first
          : 'https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?w=500',
      createdAt: lotModel.createdAt,
      sellerName: _pickupName,
      sellerPhone: _pickupMobile,
    );

    addListing(listing);
  }

  // Offers & Negotiation
  final List<Offer> _offers = [];
  List<Offer> get offers => _offers;

  void addOffer(Offer offer) {
    _offers.insert(0, offer);
    notifyListeners();
  }

  void acceptOffer(Offer offer) {
    offer.status = 'Accepted';
    final listing = _listings.firstWhere(
      (l) => l.id == offer.listingId,
      orElse: () => _listings.first,
    );
    listing.status = 'Accepted';
    listing.assignedBuyerName = offer.buyerName;
    listing.highestOfferAmount = offer.offeredAmount;
    notifyListeners();
  }

  // Chat
  final List<ChatMessage> _chatMessages = [];
  List<ChatMessage> get chatMessages => _chatMessages;

  void sendMessage(String text) {
    _chatMessages.add(
      ChatMessage(
        id: 'MSG-${DateTime.now().millisecondsSinceEpoch}',
        senderName: _pickupName,
        text: text,
        isMe: true,
        timestamp: DateTime.now(),
      ),
    );
    notifyListeners();
  }

  // Ledger & Financials
  double _walletBalance = 0.0;
  double get walletBalance => _walletBalance;

  final List<LedgerTransaction> _transactions = [];
  List<LedgerTransaction> get transactions => _transactions;

  void withdrawWallet(double amount, String upiId) {
    if (amount <= _walletBalance) {
      _walletBalance -= amount;
      _transactions.insert(
        0,
        LedgerTransaction(
          id: 'TXN-${DateTime.now().millisecondsSinceEpoch.toString().substring(7)}',
          title: 'UPI Transfer to $upiId',
          categoryName: 'Bank Withdrawal',
          amount: amount,
          isCredit: false,
          date: DateTime.now(),
          status: 'Transferred',
          referenceNumber:
              'UPI/${DateTime.now().millisecondsSinceEpoch}/SUCCESS',
        ),
      );
      notifyListeners();
    }
  }

  // Green Metrics
  double get totalCo2SavedKg => 0;
  double get totalTreesSaved => 0;
  double get totalWaterSavedLiters => 0;
}
