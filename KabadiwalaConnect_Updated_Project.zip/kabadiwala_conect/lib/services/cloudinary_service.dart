import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class CloudinaryService {
  // Cloudinary Cloud Name & Unsigned Preset
  static const String cloudName = 'kabadiwala-connect';
  static const String uploadPreset = 'scrap_unsigned';

  static Future<String?> uploadImage(String filePath) async {
    try {
      if (filePath.isEmpty) {
        return 'https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?w=500';
      }

      if (filePath.startsWith('http://') || filePath.startsWith('https://')) {
        return filePath; // Already a remote URL
      }

      debugPrint('CloudinaryService: Uploading $filePath to Cloudinary ($cloudName)...');

      final uri = Uri.parse('https://api.cloudinary.com/v1_1/$cloudName/image/upload');
      final request = http.MultipartRequest('POST', uri)
        ..fields['upload_preset'] = uploadPreset
        ..files.add(await http.MultipartFile.fromPath('file', filePath));

      final streamedResponse = await request.send();
      final response = await http.Response.fromStream(streamedResponse);

      if (response.statusCode == 200) {
        final jsonResult = json.decode(response.body);
        final secureUrl = jsonResult['secure_url'] as String?;
        debugPrint('CloudinaryService: Upload success -> $secureUrl');
        return secureUrl ?? 'https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?w=500';
      } else {
        debugPrint('CloudinaryService: Upload status ${response.statusCode} (${response.body}). Using eco stock fallback.');
        return 'https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?w=500';
      }
    } catch (e) {
      debugPrint('CloudinaryService exception: $e. Using eco stock fallback.');
      return 'https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?w=500';
    }
  }
}
