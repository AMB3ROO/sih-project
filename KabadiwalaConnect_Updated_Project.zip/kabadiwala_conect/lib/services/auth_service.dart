import 'package:flutter/foundation.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/user_model.dart';
import 'firestore_service.dart';

class AuthService extends ChangeNotifier {
  final FirestoreService _firestoreService = FirestoreService();
  final FirebaseAuth _auth = FirebaseAuth.instance;

  UserModel? _currentUser;
  bool _isLoading = false;
  String? _verificationId;
  String? _phoneNumber;
  ConfirmationResult? _webConfirmationResult;

  UserModel? get currentUser => _currentUser;
  bool get isLoading => _isLoading;
  bool get isAuthenticated => _currentUser != null;

  // Phone OTP Flow: Send Verification Code
  Future<bool> sendPhoneOtp({
    required String phoneNumber,
    required Function(String verificationId) onCodeSent,
    required Function(String errorMessage) onError,
  }) async {
    _isLoading = true;
    notifyListeners();

    try {
      final digitsOnly = phoneNumber.replaceAll(RegExp(r'\D'), '');
      final nationalNumber =
          digitsOnly.length == 12 && digitsOnly.startsWith('91')
          ? digitsOnly.substring(2)
          : digitsOnly;
      if (nationalNumber.length != 10) {
        throw const FormatException(
          'Enter a valid 10-digit Indian mobile number.',
        );
      }

      _phoneNumber = '+91$nationalNumber';
      if (kIsWeb) {
        // `verifyPhoneNumber` is for native platforms. Firebase Web uses a
        // ConfirmationResult and requires reCAPTCHA verification.
        _webConfirmationResult = await _auth.signInWithPhoneNumber(
          _phoneNumber!,
        );
        _verificationId = _webConfirmationResult!.verificationId;
        _isLoading = false;
        notifyListeners();
        onCodeSent(_verificationId!);
      } else {
        await _auth.verifyPhoneNumber(
          phoneNumber: _phoneNumber!,
          verificationCompleted: (credential) async {
            try {
              await _auth.signInWithCredential(credential);
            } catch (e) {
              debugPrint('Automatic phone verification failed: $e');
            }
          },
          verificationFailed: (exception) {
            _isLoading = false;
            notifyListeners();
            onError(_authErrorMessage(exception));
          },
          codeSent: (verificationId, _) {
            _verificationId = verificationId;
            _isLoading = false;
            notifyListeners();
            onCodeSent(verificationId);
          },
          codeAutoRetrievalTimeout: (verificationId) {
            _verificationId = verificationId;
          },
        );
      }

      return true;
    } catch (e) {
      _isLoading = false;
      notifyListeners();
      final details = e is FirebaseAuthException
          ? _authErrorMessage(e)
          : e.toString();
      onError('Failed to send OTP: $details');
      return false;
    }
  }

  // Phone OTP Flow: Verify 6-digit SMS Code
  Future<UserModel> verifyOtpAndSignIn({
    required String smsCode,
    required UserRole role,
    String? name,
    String? email,
    String? address,
  }) async {
    _isLoading = true;
    notifyListeners();

    try {
      if (_phoneNumber == null ||
          (kIsWeb ? _webConfirmationResult == null : _verificationId == null)) {
        throw StateError('Request a new verification code before continuing.');
      }

      final result = kIsWeb
          ? await _webConfirmationResult!.confirm(smsCode)
          : await _auth.signInWithCredential(
              PhoneAuthProvider.credential(
                verificationId: _verificationId!,
                smsCode: smsCode,
              ),
            );
      final firebaseUser = result.user;
      if (firebaseUser == null) {
        throw StateError('Firebase authentication returned no user.');
      }
      final existingUser = await _firestoreService.getUser(firebaseUser.uid);
      if (existingUser != null) {
        _currentUser = existingUser;
        _webConfirmationResult = null;
        _isLoading = false;
        notifyListeners();
        return existingUser;
      }
      final newUser = UserModel(
        uid: firebaseUser.uid,
        name: name?.trim() ?? '',
        phone: firebaseUser.phoneNumber ?? _phoneNumber!,
        email: email?.trim() ?? '',
        role: role,
        address: address ?? '',
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );

      await _firestoreService.saveUser(newUser);
      _currentUser = newUser;
      _webConfirmationResult = null;
      _verificationId = null;

      _isLoading = false;
      notifyListeners();

      return newUser;
    } catch (e) {
      debugPrint('Phone verification or profile save failed: $e');
      _isLoading = false;
      notifyListeners();
      rethrow;
    }
  }

  Future<UserModel> signInWithPhoneOtp({required String smsCode}) async {
    _isLoading = true;
    notifyListeners();
    try {
      if (_phoneNumber == null ||
          (kIsWeb ? _webConfirmationResult == null : _verificationId == null)) {
        throw StateError('Request a new verification code before continuing.');
      }

      final credential = kIsWeb
          ? await _webConfirmationResult!.confirm(smsCode)
          : await _auth.signInWithCredential(
              PhoneAuthProvider.credential(
                verificationId: _verificationId!,
                smsCode: smsCode,
              ),
            );
      final firebaseUser = credential.user;
      if (firebaseUser == null) {
        throw StateError('Firebase authentication returned no user.');
      }

      final user = await _firestoreService.getUser(firebaseUser.uid);
      if (user == null) {
        throw StateError(
          'No profile is linked to this phone number. Register first, then sign in with your phone code.',
        );
      }

      _currentUser = user;
      return user;
    } catch (error) {
      await _auth.signOut();
      _currentUser = null;
      if (error is FirebaseAuthException) {
        throw StateError(_authErrorMessage(error));
      }
      rethrow;
    } finally {
      _webConfirmationResult = null;
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<UserModel> signInWithEmail({
    required String email,
    required String password,
  }) async {
    _isLoading = true;
    notifyListeners();
    try {
      final credential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      final firebaseUser = credential.user;
      if (firebaseUser == null) {
        throw StateError('Authentication returned no user.');
      }
      final user = await _firestoreService.getUser(firebaseUser.uid);
      if (user == null) {
        throw StateError(
          'No Kabadiwala Connect profile exists for this account.',
        );
      }
      _currentUser = user;
      return user;
    } catch (_) {
      await _auth.signOut();
      _currentUser = null;
      rethrow;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> signOut() async {
    await _auth.signOut();
    _currentUser = null;
    _verificationId = null;
    _webConfirmationResult = null;
    _phoneNumber = null;
    notifyListeners();
  }

  String _authErrorMessage(FirebaseAuthException error) => switch (error.code) {
    'invalid-phone-number' =>
      'Check the phone number and include a valid 10-digit Indian number.',
    'operation-not-allowed' =>
      'Phone sign-in is disabled for this Firebase project. Enable the Phone provider in Firebase Authentication.',
    'unauthorized-domain' || 'app-not-authorized' =>
      'This web address is not authorized for Firebase Phone Auth. Add localhost to Authentication → Settings → Authorized domains.',
    'captcha-check-failed' =>
      'Browser verification failed. Reload the page and try sending the code again.',
    'too-many-requests' || 'quota-exceeded' =>
      'Firebase has temporarily limited SMS requests. Wait before requesting another code.',
    'invalid-verification-code' =>
      'That code is incorrect. Check the latest SMS code and try again.',
    'session-expired' ||
    'code-expired' => 'That verification code expired. Request a new one.',
    'network-request-failed' =>
      'Could not reach Firebase. Check your internet connection and retry.',
    _ => error.message ?? 'Firebase authentication failed (${error.code}).',
  };
}
