import 'dart:async';
import 'package:flutter/foundation.dart';
import '../models/scrap_lot_model.dart';
import '../models/pickup_order_model.dart';
import 'firestore_service.dart';

class OfflineSyncTask {
  final String taskId;
  final String taskType; // 'create_lot', 'create_order', 'record_handover'
  final Map<String, dynamic> payload;
  final DateTime createdAt;

  OfflineSyncTask({
    required this.taskId,
    required this.taskType,
    required this.payload,
    required this.createdAt,
  });
}

class OfflineSyncService extends ChangeNotifier {
  final FirestoreService _firestoreService = FirestoreService();
  final List<OfflineSyncTask> _pendingQueue = [];
  bool _isOnline = true;
  bool _isSyncing = false;

  List<OfflineSyncTask> get pendingQueue => List.unmodifiable(_pendingQueue);
  bool get isOnline => _isOnline;
  bool get isSyncing => _isSyncing;
  int get pendingTaskCount => _pendingQueue.length;

  void toggleConnectivity(bool online) {
    _isOnline = online;
    notifyListeners();
    if (_isOnline && _pendingQueue.isNotEmpty) {
      synchronizePendingQueue();
    }
  }

  void queueScrapLotCreation(ScrapLotModel lot) {
    if (_isOnline) {
      _firestoreService.createScrapLot(lot);
    } else {
      _pendingQueue.add(
        OfflineSyncTask(
          taskId: 'TASK-${DateTime.now().millisecondsSinceEpoch}',
          taskType: 'create_lot',
          payload: lot.toMap(),
          createdAt: DateTime.now(),
        ),
      );
      notifyListeners();
      debugPrint('OfflineSyncService: Lot ${lot.lotId} queued offline.');
    }
  }

  void queuePickupOrderCreation(PickupOrderModel order) {
    if (_isOnline) {
      _firestoreService.createPickupOrder(order);
    } else {
      _pendingQueue.add(
        OfflineSyncTask(
          taskId: 'TASK-${DateTime.now().millisecondsSinceEpoch}',
          taskType: 'create_order',
          payload: order.toMap(),
          createdAt: DateTime.now(),
        ),
      );
      notifyListeners();
      debugPrint('OfflineSyncService: Order ${order.orderId} queued offline.');
    }
  }

  Future<void> synchronizePendingQueue() async {
    if (!_isOnline || _isSyncing || _pendingQueue.isEmpty) return;

    _isSyncing = true;
    notifyListeners();

    debugPrint('OfflineSyncService: Starting synchronization of ${_pendingQueue.length} offline tasks...');

    final List<OfflineSyncTask> tasksToProcess = List.from(_pendingQueue);
    for (final task in tasksToProcess) {
      try {
        if (task.taskType == 'create_lot') {
          final lot = ScrapLotModel.fromMap(task.payload, task.payload['lotId'] ?? 'LOT-OFFLINE');
          await _firestoreService.createScrapLot(lot);
        } else if (task.taskType == 'create_order') {
          final order = PickupOrderModel.fromMap(task.payload, task.payload['orderId'] ?? 'ORD-OFFLINE');
          await _firestoreService.createPickupOrder(order);
        }
        _pendingQueue.removeWhere((t) => t.taskId == task.taskId);
      } catch (e) {
        debugPrint('OfflineSyncService: Failed to sync task ${task.taskId}: $e');
      }
    }

    _isSyncing = false;
    notifyListeners();
    debugPrint('OfflineSyncService: Queue sync complete. Remaining: ${_pendingQueue.length}');
  }
}
