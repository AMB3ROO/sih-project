import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/handover_model.dart';
import '../models/offer_model.dart';
import '../models/pickup_order_model.dart';
import '../models/price_model.dart';
import '../models/scrap_lot_model.dart';
import '../models/user_model.dart';

class FirestoreService {
  FirestoreService({FirebaseFirestore? firestore})
      : _firestore = firestore ?? FirebaseFirestore.instance;

  final FirebaseFirestore _firestore;

  final List<PriceModel> _prices = const [];
  List<PriceModel> get cachedPrices => List.unmodifiable(_prices);

  Future<UserModel?> getUser(String uid) async {
    final snapshot = await _firestore.collection('users').doc(uid).get();
    if (!snapshot.exists || snapshot.data() == null) return null;
    return UserModel.fromMap(_normaliseDates(snapshot.data()!), snapshot.id);
  }

  Future<void> saveUser(UserModel user) {
    return _firestore.collection('users').doc(user.uid).set(user.toMap());
  }

  Future<List<ScrapLotModel>> getScrapLots({
    String? customerId,
    String? status,
  }) async {
    Query<Map<String, dynamic>> query = _firestore.collection('scrapLots');
    if (customerId != null) {
      query = query.where('customerId', isEqualTo: customerId);
    }
    if (status != null) {
      query = query.where('status', isEqualTo: status);
    }
    final snapshot = await query.get();
    return snapshot.docs
        .map((doc) => ScrapLotModel.fromMap(_normaliseDates(doc.data()), doc.id))
        .toList();
  }

  Future<void> createScrapLot(ScrapLotModel lot) {
    return _firestore.collection('scrapLots').doc(lot.lotId).set(lot.toMap());
  }

  Future<List<PickupOrderModel>> getPickupOrders({
    String? customerId,
    String? assignedCollectorId,
  }) async {
    Query<Map<String, dynamic>> query =
        _firestore.collection('pickupOrders');
    if (customerId != null) {
      query = query.where('customerId', isEqualTo: customerId);
    }
    if (assignedCollectorId != null) {
      query = query.where(
        'assignedKabadiwalaId',
        isEqualTo: assignedCollectorId,
      );
    }
    final snapshot = await query.get();
    return snapshot.docs
        .map((doc) => PickupOrderModel.fromMap(
              _normaliseDates(doc.data()),
              doc.id,
            ))
        .toList();
  }

  Future<void> createPickupOrder(PickupOrderModel order) {
    return _firestore
        .collection('pickupOrders')
        .doc(order.orderId)
        .set(order.toMap());
  }

  Future<List<MarketplaceOfferModel>> getOffers(String orderIdOrLotId) async {
    final snapshot = await _firestore
        .collection('offers')
        .where('orderIdOrLotId', isEqualTo: orderIdOrLotId)
        .get();
    return snapshot.docs
        .map((doc) => MarketplaceOfferModel.fromMap(
              _normaliseDates(doc.data()),
              doc.id,
            ))
        .toList();
  }

  Future<void> placeOffer(MarketplaceOfferModel offer) {
    return _firestore.collection('offers').doc(offer.offerId).set(offer.toMap());
  }

  Future<List<DigitalHandoverModel>> getDigitalHandovers() async {
    final snapshot = await _firestore.collection('handoverRecords').get();
    return snapshot.docs
        .map((doc) => DigitalHandoverModel.fromMap(
              _normaliseDates(doc.data()),
              doc.id,
            ))
        .toList();
  }

  Future<void> recordDigitalHandover(DigitalHandoverModel handover) {
    return _firestore
        .collection('handoverRecords')
        .doc(handover.handoverId)
        .set(handover.toMap());
  }

  Map<String, dynamic> _normaliseDates(Map<String, dynamic> data) {
    return data.map((key, value) {
      if (value is Timestamp) {
        return MapEntry(key, value.toDate().toIso8601String());
      }
      return MapEntry(key, value);
    });
  }
}
