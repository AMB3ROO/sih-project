import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/app_state.dart';
import 'app_svg_icons.dart';

class SearchBoxWidget extends StatefulWidget {
  final String hintText;

  const SearchBoxWidget({
    super.key,
    this.hintText = 'Search newspapers, copper, plastic bottles...',
  });

  @override
  State<SearchBoxWidget> createState() => _SearchBoxWidgetState();
}

class _SearchBoxWidgetState extends State<SearchBoxWidget> {
  final TextEditingController _controller = TextEditingController();
  final FocusNode _focusNode = FocusNode();
  bool _isFocused = false;

  @override
  void initState() {
    super.initState();
    _focusNode.addListener(() {
      if (mounted) {
        setState(() {
          _isFocused = _focusNode.hasFocus;
        });
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  void _selectSearchTerm(AppState appState, String term) {
    _controller.text = term;
    _controller.selection = TextSelection.fromPosition(TextPosition(offset: term.length));
    appState.setSearchQuery(term);
    appState.addRecentSearch(term);
    Future.microtask(() {
      if (mounted) {
        _focusNode.unfocus();
      }
    });
  }

  void _fillSearchField(String term) {
    _controller.text = term;
    _controller.selection = TextSelection.fromPosition(TextPosition(offset: term.length));
  }

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);
    final rawQuery = _controller.text;
    final currentQuery = rawQuery.trim().toLowerCase();

    final filteredRecent = appState.recentSearches.where((r) {
      if (currentQuery.isEmpty) return true;
      return r.toLowerCase().contains(currentQuery);
    }).toList();

    final filteredSimilar = appState.similarSearches.where((s) {
      if (currentQuery.isEmpty) return true;
      return s.toLowerCase().contains(currentQuery) &&
          !filteredRecent.any((r) => r.toLowerCase() == s.toLowerCase());
    }).toList();

    // Option dropdown list is shown while search field is focused
    final showDropdown = _isFocused;

    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Search Bar Container
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: BoxDecoration(
            color: _isFocused ? Colors.white : const Color(0xFFF7FAFF),
            borderRadius: showDropdown && (filteredRecent.isNotEmpty || filteredSimilar.isNotEmpty)
                ? const BorderRadius.vertical(top: Radius.circular(18), bottom: Radius.circular(4))
                : BorderRadius.circular(18),
            border: Border.all(
              color: _isFocused ? const Color(0xFF155EEF) : const Color(0xFFE2E8F0),
              width: _isFocused ? 1.8 : 1.0,
            ),
            boxShadow: [
              BoxShadow(
                color: _isFocused ? const Color(0x22155EEF) : const Color(0x0A000000),
                blurRadius: _isFocused ? 12 : 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: TextField(
            controller: _controller,
            focusNode: _focusNode,
            onChanged: (value) => appState.setSearchQuery(value),
            onSubmitted: (value) {
              if (value.trim().isNotEmpty) {
                appState.addRecentSearch(value);
              }
              _focusNode.unfocus();
            },
            style: const TextStyle(fontSize: 14, color: Color(0xFF0F172A), fontWeight: FontWeight.w500),
            decoration: InputDecoration(
              hintText: widget.hintText,
              hintStyle: const TextStyle(color: Color(0xFF94A3B8), fontSize: 13),
              prefixIcon: const Padding(
                padding: EdgeInsets.all(12.0),
                child: AppSvgIconWidget(svgData: AppSvgIcons.searchIcon, size: 20, color: Color(0xFF155EEF)),
              ),
              suffixIcon: _controller.text.isNotEmpty
                  ? IconButton(
                      icon: const Icon(Icons.clear_rounded, color: Colors.grey, size: 20),
                      onPressed: () {
                        _controller.clear();
                        appState.setSearchQuery('');
                        _focusNode.unfocus();
                      },
                    )
                  : IconButton(
                      icon: const Icon(Icons.tune_rounded, color: Color(0xFF64748B), size: 20),
                      onPressed: () {
                        _showFilterBottomSheet(context);
                      },
                    ),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(vertical: 14),
            ),
          ),
        ),

        // Auto-Complete Option List Dropdown (Only visible during active focus)
        if (showDropdown && (filteredRecent.isNotEmpty || filteredSimilar.isNotEmpty))
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 16),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.vertical(bottom: Radius.circular(20)),
              boxShadow: [
                BoxShadow(
                  color: Color(0x1F000000),
                  blurRadius: 16,
                  offset: Offset(0, 8),
                ),
              ],
            ),
            child: Material(
              color: Colors.transparent,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Divider(height: 1, thickness: 1, color: Color(0xFFF1F5F9)),

                  // List of Recent Searches (Google History Purple Style with SVG Icon)
                  ...filteredRecent.map((term) {
                    return Listener(
                      behavior: HitTestBehavior.opaque,
                      onPointerDown: (_) => _selectSearchTerm(appState, term),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        child: Row(
                          children: [
                            const AppSvgIconWidget(
                              svgData: AppSvgIcons.historyClockIcon,
                              size: 18,
                              color: Color(0xFF6B21A8), // Google history purple
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Text(
                                term,
                                style: const TextStyle(
                                  fontSize: 14,
                                  color: Color(0xFF6B21A8), // Google history purple text
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                            Listener(
                              behavior: HitTestBehavior.opaque,
                              onPointerDown: (_) => _fillSearchField(term),
                              child: const Padding(
                                padding: EdgeInsets.all(6.0),
                                child: Icon(Icons.north_west_rounded, size: 16, color: Color(0xFF9CA3AF)),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Listener(
                              behavior: HitTestBehavior.opaque,
                              onPointerDown: (_) => appState.removeRecentSearch(term),
                              child: const Padding(
                                padding: EdgeInsets.all(6.0),
                                child: Icon(Icons.close_rounded, size: 16, color: Color(0xFF9CA3AF)),
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  }),

                  if (filteredRecent.isNotEmpty && filteredSimilar.isNotEmpty)
                    const Padding(
                      padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 4.0),
                      child: Divider(height: 1, thickness: 0.8, color: Color(0xFFF1F5F9)),
                    ),

                  // List of Similar / Suggested Searches (Google Auto-Complete Style with SVG Icon)
                  ...filteredSimilar.map((similarTerm) {
                    return Listener(
                      behavior: HitTestBehavior.opaque,
                      onPointerDown: (_) => _selectSearchTerm(appState, similarTerm),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        child: Row(
                          children: [
                            const AppSvgIconWidget(
                              svgData: AppSvgIcons.searchIcon,
                              size: 18,
                              color: Color(0xFF9CA3AF),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: _buildHighlightedText(similarTerm, currentQuery),
                            ),
                            Listener(
                              behavior: HitTestBehavior.opaque,
                              onPointerDown: (_) => _fillSearchField(similarTerm),
                              child: const Padding(
                                padding: EdgeInsets.all(6.0),
                                child: Icon(Icons.north_west_rounded, size: 16, color: Color(0xFF9CA3AF)),
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  }),

                  // Google Style Footer: Clear History & Close
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    decoration: const BoxDecoration(
                      color: Color(0xFFF7FAFF),
                      borderRadius: BorderRadius.vertical(bottom: Radius.circular(20)),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        if (appState.recentSearches.isNotEmpty)
                          Listener(
                            behavior: HitTestBehavior.opaque,
                            onPointerDown: (_) => appState.clearRecentSearches(),
                            child: const Padding(
                              padding: EdgeInsets.symmetric(vertical: 4.0),
                              child: Text(
                                'Clear search history',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Color(0xFFEF4444),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          )
                        else
                          const SizedBox.shrink(),
                        Listener(
                          behavior: HitTestBehavior.opaque,
                          onPointerDown: (_) => _focusNode.unfocus(),
                          child: const Padding(
                            padding: EdgeInsets.symmetric(vertical: 4.0),
                            child: Text(
                              'Close Menu',
                              style: TextStyle(
                                fontSize: 12,
                                color: Color(0xFF64748B),
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildHighlightedText(String text, String query) {
    if (query.isEmpty) {
      return Text(
        text,
        style: const TextStyle(fontSize: 14, color: Color(0xFF1E293B), fontWeight: FontWeight.normal),
      );
    }

    final lowerText = text.toLowerCase();
    final lowerQuery = query.toLowerCase();
    final matchIndex = lowerText.indexOf(lowerQuery);

    if (matchIndex < 0) {
      return Text(
        text,
        style: const TextStyle(fontSize: 14, color: Color(0xFF1E293B), fontWeight: FontWeight.normal),
      );
    }

    final prefix = text.substring(0, matchIndex);
    final match = text.substring(matchIndex, matchIndex + query.length);
    final suffix = text.substring(matchIndex + query.length);

    return RichText(
      text: TextSpan(
        style: const TextStyle(fontSize: 14, color: Color(0xFF1E293B)),
        children: [
          TextSpan(text: prefix, style: const TextStyle(fontWeight: FontWeight.normal)),
          TextSpan(text: match, style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF155EEF))),
          TextSpan(text: suffix, style: const TextStyle(fontWeight: FontWeight.normal)),
        ],
      ),
    );
  }

  void _showFilterBottomSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) {
        return Container(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Filter Scrap Market',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              const Text('Sort By Rates', style: TextStyle(fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                children: [
                  ChoiceChip(label: const Text('Highest Payout/kg'), selected: true, onSelected: (_) {}),
                  ChoiceChip(label: const Text('Nearest Distance'), selected: false, onSelected: (_) {}),
                  ChoiceChip(label: const Text('Top Rating'), selected: false, onSelected: (_) {}),
                ],
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF155EEF),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Apply Filter', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
