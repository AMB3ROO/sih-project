import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../data/scrap_repository.dart';
import '../services/app_state.dart';
import '../screens/product_screen.dart';
import 'responsive.dart';

class PopularListWidget extends StatelessWidget {
  const PopularListWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);
    final popularProducts = ScrapRepository.getPopularProducts();
    final screenWidth = MediaQuery.of(context).size.width;

    // Screen ratio based card dimensions
    final cardWidth = Responsive.width(context, screenWidth < 600 ? 44 : (screenWidth < 900 ? 30 : 22));
    final listHeight = Responsive.height(context, 30);
    final imageHeight = listHeight * 0.52;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.symmetric(
            horizontal: Responsive.width(context, 4),
            vertical: Responsive.height(context, 1),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFEF3C7),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(Icons.local_fire_department_rounded, color: const Color(0xFFD97706), size: Responsive.sp(context, 18)),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    'Trending High Payouts',
                    style: TextStyle(
                      fontSize: Responsive.sp(context, 16),
                      fontWeight: FontWeight.bold,
                      color: const Color(0xFF0F172A),
                    ),
                  ),
                ],
              ),
              TextButton(
                onPressed: () {},
                child: Text('See All', style: TextStyle(color: const Color(0xFF155EEF), fontWeight: FontWeight.bold, fontSize: Responsive.sp(context, 13))),
              ),
            ],
          ),
        ),
        SizedBox(
          height: listHeight,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: EdgeInsets.symmetric(horizontal: Responsive.width(context, 3)),
            itemCount: popularProducts.length,
            itemBuilder: (context, index) {
              final product = popularProducts[index];
              final isFav = appState.isFavorite(product.id);

              return Container(
                width: cardWidth,
                margin: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
                child: Card(
                  elevation: 2,
                  shadowColor: const Color(0x1F000000),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  clipBehavior: Clip.antiAlias,
                  color: Colors.white,
                  child: InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => ProductScreen(product: product)),
                      );
                    },
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Stack(
                          children: [
                            Image.network(
                              product.imageUrl,
                              height: imageHeight,
                              width: double.infinity,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => Container(
                                height: imageHeight,
                                color: const Color(0xFFE2E8F0),
                                child: Icon(product.category.icon, size: Responsive.sp(context, 40), color: product.category.color),
                              ),
                            ),
                            Positioned(
                              top: 6,
                              right: 6,
                              child: InkWell(
                                onTap: () => appState.toggleFavorite(product.id),
                                borderRadius: BorderRadius.circular(16),
                                child: CircleAvatar(
                                  radius: Responsive.sp(context, 14),
                                  backgroundColor: Colors.white.withValues(alpha: 0.9),
                                  child: Icon(
                                    isFav ? Icons.favorite_rounded : Icons.favorite_outline_rounded,
                                    color: isFav ? Colors.red : Colors.grey,
                                    size: Responsive.sp(context, 16),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              bottom: 6,
                              left: 6,
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(
                                  color: Colors.black.withValues(alpha: 0.7),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Text(
                                  '₹${product.pricePerKg.toStringAsFixed(0)}/kg',
                                  style: TextStyle(color: Colors.white, fontSize: Responsive.sp(context, 11), fontWeight: FontWeight.bold),
                                ),
                              ),
                            ),
                          ],
                        ),
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  product.title,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: Responsive.sp(context, 13), height: 1.2),
                                ),
                                Row(
                                  children: [
                                    Icon(Icons.star_rounded, color: Colors.amber, size: Responsive.sp(context, 14)),
                                    const SizedBox(width: 2),
                                    Text(
                                      '${product.rating}',
                                      style: TextStyle(fontSize: Responsive.sp(context, 11), fontWeight: FontWeight.w600),
                                    ),
                                    const Spacer(),
                                    Text(
                                      '~${product.defaultWeightKg.toStringAsFixed(0)}kg',
                                      style: TextStyle(fontSize: Responsive.sp(context, 11), color: Colors.grey),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}
