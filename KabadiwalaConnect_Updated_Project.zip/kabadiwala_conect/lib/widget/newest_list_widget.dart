import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/app_state.dart';
import '../screens/negotiation_chat_screen.dart';
import 'responsive.dart';

class NewestListWidget extends StatelessWidget {
  const NewestListWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);
    final listings = appState.listings;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.symmetric(
            horizontal: Responsive.width(context, 4),
            vertical: Responsive.height(context, 1),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: const Color(0xFFD9E7FF),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(Icons.storefront_rounded, color: const Color(0xFF0B1F3A), size: Responsive.sp(context, 18)),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    'Live Marketplace Batches',
                    style: TextStyle(
                      fontSize: Responsive.sp(context, 16),
                      fontWeight: FontWeight.bold,
                      color: const Color(0xFF0F172A),
                    ),
                  ),
                ],
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0xFFEFF6FF),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFFBFDBFE)),
                ),
                child: Text(
                  '${listings.length} Active',
                  style: TextStyle(color: const Color(0xFF1D4ED8), fontSize: Responsive.sp(context, 11), fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
        ),
        ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          padding: EdgeInsets.symmetric(horizontal: Responsive.width(context, 4), vertical: 4),
          itemCount: listings.length,
          itemBuilder: (context, index) {
            final listing = listings[index];

            return Card(
              margin: const EdgeInsets.only(bottom: 12),
              elevation: 1.5,
              shadowColor: const Color(0x14000000),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              color: Colors.white,
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(12),
                          child: Image.network(
                            listing.imageUrl,
                            width: Responsive.width(context, 18),
                            height: Responsive.width(context, 18),
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => Container(
                              width: 75,
                              height: 75,
                              color: const Color(0xFFE2E8F0),
                              child: Icon(Icons.recycling_rounded, color: const Color(0xFF155EEF), size: Responsive.sp(context, 36)),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                listing.title,
                                style: TextStyle(fontWeight: FontWeight.bold, fontSize: Responsive.sp(context, 14)),
                              ),
                              const SizedBox(height: 4),
                              Row(
                                children: [
                                  Icon(Icons.location_on_outlined, size: Responsive.sp(context, 14), color: Colors.grey),
                                  const SizedBox(width: 2),
                                  Expanded(
                                    child: Text(
                                      listing.location,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(fontSize: Responsive.sp(context, 12), color: const Color(0xFF64748B)),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 6),
                              Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                    decoration: BoxDecoration(
                                      color: const Color(0xFFF1F5F9),
                                      borderRadius: BorderRadius.circular(6),
                                    ),
                                    child: Text(
                                      '${listing.totalWeightKg.toStringAsFixed(0)} kg Total',
                                      style: TextStyle(fontSize: Responsive.sp(context, 11), fontWeight: FontWeight.bold, color: const Color(0xFF334155)),
                                    ),
                                  ),
                                  const SizedBox(width: 6),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                    decoration: BoxDecoration(
                                      color: const Color(0xFFEFF6FF),
                                      borderRadius: BorderRadius.circular(6),
                                    ),
                                    child: Text(
                                      'Est. ₹${listing.totalEstimatedValue.toStringAsFixed(0)}',
                                      style: TextStyle(fontSize: Responsive.sp(context, 11), fontWeight: FontWeight.bold, color: const Color(0xFF1D4ED8)),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const Divider(height: 20, thickness: 0.8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Icon(Icons.person_outline_rounded, size: Responsive.sp(context, 14), color: Colors.grey),
                            const SizedBox(width: 4),
                            Text(
                              listing.sellerName,
                              style: TextStyle(fontSize: Responsive.sp(context, 12), fontWeight: FontWeight.w600, color: const Color(0xFF475569)),
                            ),
                          ],
                        ),
                        ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF155EEF),
                            foregroundColor: Colors.white,
                            elevation: 0,
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                          ),
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (_) => NegotiationChatScreen(listing: listing)),
                            );
                          },
                          icon: Icon(Icons.chat_bubble_outline_rounded, size: Responsive.sp(context, 14)),
                          label: Text('Negotiate', style: TextStyle(fontSize: Responsive.sp(context, 12), fontWeight: FontWeight.bold)),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ],
    );
  }
}
