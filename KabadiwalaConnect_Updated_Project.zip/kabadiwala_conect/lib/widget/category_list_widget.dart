import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../entity/scrap_category.dart';
import '../services/app_state.dart';
import 'app_svg_icons.dart';
import 'responsive.dart';

class CategoryListWidget extends StatelessWidget {
  const CategoryListWidget({super.key});

  String _getCategorySvg(ScrapCategoryType type) {
    switch (type) {
      case ScrapCategoryType.paper:
        return AppSvgIcons.paperIcon;
      case ScrapCategoryType.plastic:
        return AppSvgIcons.plasticIcon;
      case ScrapCategoryType.metal:
        return AppSvgIcons.metalIcon;
      case ScrapCategoryType.eWaste:
        return AppSvgIcons.eWasteIcon;
      case ScrapCategoryType.glass:
        return AppSvgIcons.glassIcon;
      case ScrapCategoryType.cardboard:
        return AppSvgIcons.cardboardIcon;
      case ScrapCategoryType.mixed:
        return AppSvgIcons.mixedScrapIcon;
    }
  }

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);
    final categories = ScrapCategory.allCategories;

    return SizedBox(
      height: Responsive.height(context, 6.0).clamp(44.0, 60.0),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: EdgeInsets.symmetric(horizontal: Responsive.width(context, 4)),
        itemCount: categories.length + 1,
        itemBuilder: (context, index) {
          if (index == 0) {
            final isAllSelected = appState.selectedCategoryType == null;
            return Padding(
              padding: const EdgeInsets.only(right: 8.0),
              child: ChoiceChip(
                avatar: AppSvgIconWidget(
                  svgData: AppSvgIcons.recyclingLogo,
                  size: 16,
                  color: isAllSelected ? Colors.white : const Color(0xFF155EEF),
                ),
                label: const Text('All Scrap'),
                selected: isAllSelected,
                onSelected: (_) => appState.setCategoryFilter(null),
                selectedColor: const Color(0xFF155EEF),
                labelStyle: TextStyle(
                  color: isAllSelected ? Colors.white : const Color(0xFF334155),
                  fontWeight: FontWeight.bold,
                  fontSize: Responsive.sp(context, 13),
                ),
                backgroundColor: const Color(0xFFF7FAFF),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                showCheckmark: false,
                side: BorderSide.none,
              ),
            );
          }

          final cat = categories[index - 1];
          final isSelected = appState.selectedCategoryType == cat.type;

          return Padding(
            padding: const EdgeInsets.only(right: 8.0),
            child: ChoiceChip(
              avatar: AppSvgIconWidget(
                svgData: _getCategorySvg(cat.type),
                size: 16,
                color: isSelected ? Colors.white : const Color(0xFF155EEF),
              ),
              label: Text(cat.name),
              selected: isSelected,
              onSelected: (_) => appState.setCategoryFilter(cat.type),
              selectedColor: const Color(0xFF155EEF),
              labelStyle: TextStyle(
                color: isSelected ? Colors.white : const Color(0xFF334155),
                fontWeight: FontWeight.w600,
                fontSize: Responsive.sp(context, 13),
              ),
              backgroundColor: const Color(0xFFF7FAFF),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
              showCheckmark: false,
              side: BorderSide.none,
            ),
          );
        },
      ),
    );
  }
}
