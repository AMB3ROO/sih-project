import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/app_state.dart';

class AppBarWidget extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final bool showLocation;

  const AppBarWidget({
    super.key,
    this.title = 'Kabadiwala Connect',
    this.showLocation = true,
  });

  @override
  Size get preferredSize => const Size.fromHeight(64.0);

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);
    final role = appState.currentRole;

    return AppBar(
      elevation: 0,
      backgroundColor: Colors.white,
      surfaceTintColor: Colors.transparent,
      titleSpacing: 0,
      leading: Builder(
        builder: (context) => IconButton(
          icon: const Icon(Icons.menu_rounded, color: Color(0xFF1E293B), size: 26),
          onPressed: () => Scaffold.of(context).openDrawer(),
          tooltip: 'Open Menu',
        ),
      ),
      title: showLocation
          ? Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.location_on_rounded, color: Color(0xFF155EEF), size: 16),
                    const SizedBox(width: 4),
                    Text(
                      'Sector 62, Noida',
                      style: Theme.of(context).textTheme.titleSmall?.copyWith(
                            fontWeight: FontWeight.bold,
                            color: const Color(0xFF0F172A),
                          ),
                    ),
                    const Icon(Icons.keyboard_arrow_down_rounded, color: Colors.grey, size: 18),
                  ],
                ),
                Text(
                  '${role.displayName} Mode',
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                        color: const Color(0xFF0B1F3A),
                        fontWeight: FontWeight.w600,
                      ),
                ),
              ],
            )
          : Text(
              title,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                color: Color(0xFF0F172A),
                fontSize: 18,
              ),
            ),
      actions: [
        Stack(
          alignment: Alignment.center,
          children: [
            IconButton(
              icon: const Icon(Icons.notifications_none_rounded, color: Color(0xFF1E293B), size: 24),
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Recycler bid updated for Newspaper Batch #101'),
                    duration: Duration(seconds: 2),
                    backgroundColor: Color(0xFF155EEF),
                  ),
                );
              },
            ),
            Positioned(
              top: 12,
              right: 12,
              child: Container(
                width: 9,
                height: 9,
                decoration: const BoxDecoration(
                  color: Color(0xFFEF4444),
                  shape: BoxShape.circle,
                ),
              ),
            ),
          ],
        ),
        Padding(
          padding: const EdgeInsets.only(right: 12.0),
          child: InkWell(
            onTap: () => Scaffold.of(context).openDrawer(),
            borderRadius: BorderRadius.circular(20),
            child: CircleAvatar(
              radius: 18,
              backgroundColor: const Color(0xFFD9E7FF),
              child: Icon(role.icon, color: const Color(0xFF0B1F3A), size: 20),
            ),
          ),
        ),
      ],
    );
  }
}
