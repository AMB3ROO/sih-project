import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/app_state.dart';
import '../screens/ai_scanner_screen.dart';
import '../screens/price_board_screen.dart';
import '../screens/digital_handover_screen.dart';
import '../screens/earnings_ledger_screen.dart';
import '../screens/start_screen.dart';
import '../features/customer/create_lot_screen.dart';
import '../features/kabadiwala/kabadiwala_feed_screen.dart';
import '../features/safety/safety_education_screen.dart';

class MyDrawerWidget extends StatelessWidget {
  const MyDrawerWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);
    final currentRole = appState.currentRole;

    return Drawer(
      child: Column(
        children: [
          UserAccountsDrawerHeader(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF0B1F3A), Color(0xFF155EEF)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            currentAccountPicture: CircleAvatar(
              backgroundColor: Colors.white,
              child: Icon(currentRole.icon, color: const Color(0xFF0B1F3A), size: 36),
            ),
            accountName: Text(
              currentRole == UserRole.householdSeller
                  ? 'Rahul Sharma'
                  : (currentRole == UserRole.kabadiwalaTrader ? 'Ramesh Scrap Depot' : 'GreenTech Polymers Ltd.'),
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            accountEmail: Text(
              '${currentRole.displayName} • Sector 62 Noida',
              style: const TextStyle(color: Color(0xFFD9E7FF), fontSize: 12),
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            color: const Color(0xFFEFF6FF),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Active Role:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                DropdownButton<UserRole>(
                  value: currentRole,
                  underline: const SizedBox.shrink(),
                  icon: const Icon(Icons.arrow_drop_down_rounded, color: Color(0xFF0B1F3A)),
                  style: const TextStyle(color: Color(0xFF1D4ED8), fontWeight: FontWeight.bold, fontSize: 13),
                  onChanged: (newRole) {
                    if (newRole != null) {
                      appState.setUserRole(newRole);
                    }
                  },
                  items: UserRole.values
                      .where((role) => role != UserRole.platformAdmin)
                      .map((role) {
                    return DropdownMenuItem(
                      value: role,
                      child: Row(
                        children: [
                          Icon(role.icon, size: 16, color: const Color(0xFF0B1F3A)),
                          const SizedBox(width: 8),
                          Text(role.displayName),
                        ],
                      ),
                    );
                  }).toList(),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                ListTile(
                  leading: const Icon(Icons.add_shopping_cart_rounded, color: Color(0xFF155EEF)),
                  title: const Text('Sell Scrap • Create Digital Lot'),
                  subtitle: const Text('Multi-material lot & AI estimation'),
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const CreateLotScreen()),
                    );
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.radar_rounded, color: Color(0xFF3B82F6)),
                  title: const Text('Kabadiwala Pickup Feed'),
                  subtitle: const Text('Live nearby requests & bidding'),
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const KabadiwalaFeedScreen()),
                    );
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.qr_code_scanner_rounded, color: Color(0xFF155EEF)),
                  title: const Text('AI Scrap Vision Scanner'),
                  subtitle: const Text('Auto-detect materials & weights'),
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const AIScannerScreen()),
                    );
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.insights_rounded, color: Color(0xFF3B82F6)),
                  title: const Text('Price Board & Market Bids'),
                  subtitle: const Text('Live rates & buyer offers'),
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const PriceBoardScreen()),
                    );
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.qr_code_2_rounded, color: Color(0xFFA855F7)),
                  title: const Text('Digital Handover QR'),
                  subtitle: const Text('Weighment verification & payout'),
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const DigitalHandoverScreen()),
                    );
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.security_rounded, color: Color(0xFFEF4444)),
                  title: const Text('Safe Scrap Education & Audio'),
                  subtitle: const Text('Batteries, cables & e-waste safety'),
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const SafetyEducationScreen()),
                    );
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.account_balance_wallet_rounded, color: Color(0xFFF59E0B)),
                  title: const Text('Earnings & Green Certificate'),
                  subtitle: const Text('Wallet ₹2,450 • CO₂ 482 kg'),
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const EarningsLedgerScreen()),
                    );
                  },
                ),
                const Divider(),
                ListTile(
                  leading: const Icon(Icons.logout_rounded, color: Colors.redAccent),
                  title: const Text('Logout Account', style: TextStyle(color: Colors.redAccent, fontWeight: FontWeight.bold)),
                  subtitle: const Text('Sign out and return to landing page'),
                  onTap: () {
                    Navigator.pop(context);
                    appState.logout();
                    Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(builder: (_) => const StartScreen()),
                      (route) => false,
                    );
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Logged out successfully.')),
                    );
                  },
                ),
              ],
            ),
          ),
          const Divider(height: 1),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Icon(Icons.eco_rounded, color: Color(0xFF155EEF), size: 18),
                SizedBox(width: 6),
                Text(
                  'Kabadiwala Connect v1.0',
                  style: TextStyle(color: Color(0xFF94A3B8), fontSize: 12, fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
