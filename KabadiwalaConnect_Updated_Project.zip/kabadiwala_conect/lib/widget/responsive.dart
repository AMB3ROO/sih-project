import 'package:flutter/material.dart';

class Responsive {
  static double width(BuildContext context, double percentage) {
    return MediaQuery.of(context).size.width * (percentage / 100.0);
  }

  static double height(BuildContext context, double percentage) {
    return MediaQuery.of(context).size.height * (percentage / 100.0);
  }

  static double scale(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    if (w < 380) return 0.9;
    if (w < 600) return 1.0;
    if (w < 900) return 1.3;
    if (w < 1200) return 1.5;
    return 1.8;
  }

  static double sp(BuildContext context, double fontSize) {
    return fontSize * scale(context);
  }
}
