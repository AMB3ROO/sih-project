import 'package:flutter/material.dart';

class ComboButtonWidget extends StatelessWidget {
  final String primaryText;
  final VoidCallback onPrimaryPressed;
  final IconData? primaryIcon;

  final String secondaryText;
  final VoidCallback onSecondaryPressed;
  final IconData? secondaryIcon;

  const ComboButtonWidget({
    super.key,
    required this.primaryText,
    required this.onPrimaryPressed,
    this.primaryIcon = Icons.arrow_forward_rounded,
    required this.secondaryText,
    required this.onSecondaryPressed,
    this.secondaryIcon = Icons.qr_code_scanner_rounded,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: const BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Color(0x14000000),
            blurRadius: 12,
            offset: Offset(0, -4),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: Row(
          children: [
            Expanded(
              flex: 1,
              child: OutlinedButton.icon(
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  side: const BorderSide(color: Color(0xFF155EEF), width: 1.5),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                onPressed: onSecondaryPressed,
                icon: secondaryIcon != null ? Icon(secondaryIcon, color: const Color(0xFF155EEF), size: 18) : const SizedBox.shrink(),
                label: Text(
                  secondaryText,
                  style: const TextStyle(
                    color: Color(0xFF155EEF),
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              flex: 2,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF155EEF),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  elevation: 0,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                onPressed: onPrimaryPressed,
                icon: primaryIcon != null ? Icon(primaryIcon, color: Colors.white, size: 18) : const SizedBox.shrink(),
                label: Text(
                  primaryText,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
