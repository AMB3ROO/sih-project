import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }

    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        return macos;
      case TargetPlatform.windows:
        return windows;
      case TargetPlatform.linux:
      default:
        return android;
    }
  }

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyAN5UoKhqPM600Z1Fypqpp84cGquw1w7V8',
    appId: '1:436393200608:android:2a39cb7a99778ec1ccf985',
    messagingSenderId: '436393200608',
    projectId: 'kabadiwalaconnectdb',
    storageBucket: 'kabadiwalaconnectdb.firebasestorage.app',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyAN5UoKhqPM600Z1Fypqpp84cGquw1w7V8',
    appId: '1:436393200608:ios:2a39cb7a99778ec1ccf985',
    messagingSenderId: '436393200608',
    projectId: 'kabadiwalaconnectdb',
    storageBucket: 'kabadiwalaconnectdb.firebasestorage.app',
    iosBundleId: 'com.kabadiwala.connect',
  );

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyAN5UoKhqPM600Z1Fypqpp84cGquw1w7V8',
    appId: '1:436393200608:web:2a39cb7a99778ec1ccf985',
    messagingSenderId: '436393200608',
    projectId: 'kabadiwalaconnectdb',
    authDomain: 'kabadiwalaconnectdb.firebaseapp.com',
    storageBucket: 'kabadiwalaconnectdb.firebasestorage.app',
  );

  static const FirebaseOptions macos = ios;

  static const FirebaseOptions windows = FirebaseOptions(
    apiKey: 'AIzaSyAN5UoKhqPM600Z1Fypqpp84cGquw1w7V8',
    appId: '1:436393200608:web:2a39cb7a99778ec1ccf985',
    messagingSenderId: '436393200608',
    projectId: 'kabadiwalaconnectdb',
    authDomain: 'kabadiwalaconnectdb.firebaseapp.com',
    storageBucket: 'kabadiwalaconnectdb.firebasestorage.app',
  );
}
