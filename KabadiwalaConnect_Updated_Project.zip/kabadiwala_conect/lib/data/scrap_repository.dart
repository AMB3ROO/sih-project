import '../entity/scrap_category.dart';
import '../entity/scrap_product.dart';
import '../entity/scrap_listing.dart';
import '../entity/offer.dart';
import '../entity/ledger_transaction.dart';
class ScrapRepository {
  static List<ScrapProduct> getProducts({ScrapCategoryType? categoryType, String? searchQuery}) {
    List<ScrapProduct> products = [];

    if (categoryType != null) {
      products = products.where((p) => p.categoryType == categoryType).toList();
    }

    if (searchQuery != null && searchQuery.trim().isNotEmpty) {
      final query = searchQuery.toLowerCase().trim();
      products = products.where((p) {
        return p.title.toLowerCase().contains(query) ||
            p.description.toLowerCase().contains(query) ||
            p.category.name.toLowerCase().contains(query);
      }).toList();
    }

    return products;
  }

  static List<ScrapProduct> getPopularProducts() {
    return [];
  }

  static List<ScrapProduct> getNewestProducts() {
    return [];
  }

  static List<ScrapListing> getListings({String? searchQuery}) {
    List<ScrapListing> listings = [];

    if (searchQuery != null && searchQuery.trim().isNotEmpty) {
      final query = searchQuery.toLowerCase().trim();
      listings = listings.where((l) {
        final matchesTitle = l.title.toLowerCase().contains(query);
        final matchesLocation = l.location.toLowerCase().contains(query);
        final matchesSeller = l.sellerName.toLowerCase().contains(query);
        final matchesItems = l.items.any((item) =>
            item.itemName.toLowerCase().contains(query) ||
            item.category.name.toLowerCase().contains(query));
        return matchesTitle || matchesLocation || matchesSeller || matchesItems;
      }).toList();
    }

    return listings;
  }

  static List<Offer> getOffersForListing(String listingId) {
    return [];
  }

  static List<ChatMessage> getChatMessages() {
    return [];
  }

  static List<LedgerTransaction> getTransactions() {
    return [];
  }
}
