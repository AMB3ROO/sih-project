import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:camera/camera.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import '../ai/ai_service.dart';
import '../entity/scrap_listing.dart';
import '../services/app_state.dart';
import 'bottom_nav_bar.dart';

class AIScannerScreen extends StatefulWidget {
  final VoidCallback? onBackToHome;
  final bool isVisible;

  const AIScannerScreen({
    super.key,
    this.onBackToHome,
    this.isVisible = true,
  });

  @override
  State<AIScannerScreen> createState() => _AIScannerScreenState();
}

class _AIScannerScreenState extends State<AIScannerScreen> {
  String _selectedPreset = 'paper_cardboard';
  bool _isScanning = false;
  AIScannerResult? _scannerResult;
  bool _hasCameraPermission = false;
  bool _hasStoragePermission = false;

  CameraController? _cameraController;
  List<CameraDescription>? _cameras;
  XFile? _capturedImage;
  final ImagePicker _picker = ImagePicker();

  static const List<Map<String, String>> _presets = [
    {'id': 'paper_cardboard', 'name': 'Paper & Boxes', 'icon': 'menu_book_rounded'},
    {'id': 'plastic_bottles', 'name': 'PET Bottles', 'icon': 'local_drink_rounded'},
    {'id': 'metal_copper', 'name': 'Copper & Metal', 'icon': 'build_rounded'},
    {'id': 'e_waste', 'name': 'E-Waste PCB', 'icon': 'devices_rounded'},
  ];

  @override
  void initState() {
    super.initState();
    if (widget.isVisible) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _checkAndInitCameraPermission();
      });
    }
  }

  @override
  void didUpdateWidget(AIScannerScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isVisible != oldWidget.isVisible) {
      if (widget.isVisible) {
        _checkAndInitCameraPermission();
      } else {
        _disposeCamera();
      }
    }
  }

  @override
  void dispose() {
    _disposeCamera();
    super.dispose();
  }

  void _disposeCamera() {
    _cameraController?.dispose();
    _cameraController = null;
    if (mounted) {
      setState(() {});
    }
  }

  Future<void> _checkAndInitCameraPermission() async {
    final appState = Provider.of<AppState>(context, listen: false);

    // Verify real OS permission status
    final cameraStatus = await Permission.camera.status;
    final storageStatus = await Permission.storage.status;
    final photosStatus = await Permission.photos.status;

    final isCamGranted = cameraStatus.isGranted;
    final isStorageGranted = storageStatus.isGranted || photosStatus.isGranted || storageStatus.isLimited || photosStatus.isLimited;

    if (appState.isCameraPermissionGranted || (isCamGranted && isStorageGranted)) {
      if (mounted) {
        setState(() {
          _hasCameraPermission = true;
          _hasStoragePermission = true;
        });
        appState.setCameraPermissionGranted(true);
        _initDeviceCamera();
      }
    } else {
      if (mounted) {
        _requestPermissionsDialog(context, 'screen_open');
      }
    }
  }

  Future<void> _initDeviceCamera() async {
    if (!widget.isVisible) return;

    try {
      _cameras = await availableCameras();
      if (_cameras != null && _cameras!.isNotEmpty) {
        final backCamera = _cameras!.firstWhere(
          (cam) => cam.lensDirection == CameraLensDirection.back,
          orElse: () => _cameras!.first,
        );

        final controller = CameraController(
          backCamera,
          ResolutionPreset.high,
          enableAudio: false,
        );

        _cameraController = controller;
        await controller.initialize();

        if (mounted && widget.isVisible) {
          setState(() {
            _hasCameraPermission = true;
            _hasStoragePermission = true;
          });
        } else {
          controller.dispose();
          _cameraController = null;
        }
      }
    } catch (e) {
      debugPrint('Camera init exception: $e');
    }
  }

  void _navigateToHome(BuildContext context, {bool showDeniedPopup = false}) {
    if (widget.onBackToHome != null) {
      widget.onBackToHome!();
    } else {
      final appState = Provider.of<AppState>(context, listen: false);
      if (!appState.isLoggedIn) {
        appState.login();
      }
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (_) => BottomNavBar(initialIndex: 0, showDeniedPopup: showDeniedPopup)),
        (route) => false,
      );
    }
  }

  void _requestPermissionsDialog(BuildContext context, String source) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: Row(
            children: const [
              Icon(Icons.qr_code_scanner_rounded, color: Color(0xFF155EEF), size: 26),
              SizedBox(width: 8),
              Expanded(
                child: Text(
                  'Camera & Storage Access Required',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Kabadiwala Connect AI Vision needs permission to access your live device camera feed and photo gallery storage to capture scrap photos, analyze material purity, and generate instant price quotes.',
                style: TextStyle(fontSize: 13, color: Color(0xFF475569), height: 1.4),
              ),
              const SizedBox(height: 14),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: const Color(0xFFF1F5F9),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Icon(
                          _hasCameraPermission ? Icons.check_circle_rounded : Icons.camera_alt_outlined,
                          color: _hasCameraPermission ? const Color(0xFF155EEF) : Colors.grey,
                          size: 18,
                        ),
                        const SizedBox(width: 8),
                        Text('Camera Access: ${_hasCameraPermission ? "Granted" : "Pending"}', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        Icon(
                          _hasStoragePermission ? Icons.check_circle_rounded : Icons.photo_library_outlined,
                          color: _hasStoragePermission ? const Color(0xFF155EEF) : Colors.grey,
                          size: 18,
                        ),
                        const SizedBox(width: 8),
                        Text('Gallery Storage: ${_hasStoragePermission ? "Granted" : "Pending"}', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                final appState = Provider.of<AppState>(context, listen: false);
                appState.setCameraPermissionGranted(false);
                Navigator.pop(dialogContext);

                if (mounted) {
                  _navigateToHome(context, showDeniedPopup: true);
                }
              },
              child: const Text('Cancel', style: TextStyle(color: Colors.redAccent, fontWeight: FontWeight.bold)),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF155EEF)),
              onPressed: () async {
                final messenger = ScaffoldMessenger.of(context);
                final appState = Provider.of<AppState>(context, listen: false);
                Navigator.pop(dialogContext);

                try {
                  final statuses = await [
                    Permission.camera,
                    Permission.storage,
                    Permission.photos,
                  ].request();

                  final camGranted = statuses[Permission.camera]?.isGranted ?? false;
                  final storageGranted = (statuses[Permission.storage]?.isGranted ?? false) ||
                      (statuses[Permission.photos]?.isGranted ?? false) ||
                      (statuses[Permission.photos]?.isLimited ?? false);

                  if (mounted) {
                    setState(() {
                      _hasCameraPermission = camGranted;
                      _hasStoragePermission = storageGranted;
                    });
                    appState.setCameraPermissionGranted(camGranted);

                    messenger.showSnackBar(
                      const SnackBar(
                        content: Text('Live Device Camera Feed Activated!'),
                        backgroundColor: Color(0xFF155EEF),
                      ),
                    );
                    await _initDeviceCamera();
                  }
                } catch (_) {
                  if (mounted) {
                    setState(() {
                      _hasCameraPermission = true;
                      _hasStoragePermission = true;
                    });
                    appState.setCameraPermissionGranted(true);
                    await _initDeviceCamera();
                  }
                }
              },
              child: const Text('Allow Camera & Storage', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            ),
          ],
        );
      },
    );
  }

  Future<void> _captureDeviceCameraPhoto() async {
    try {
      if (_cameraController != null && _cameraController!.value.isInitialized) {
        final file = await _cameraController!.takePicture();
        setState(() {
          _capturedImage = file;
        });
        _startScan(_selectedPreset);
      } else {
        final image = await _picker.pickImage(source: ImageSource.camera);
        if (image != null) {
          setState(() {
            _capturedImage = image;
          });
          _startScan(_selectedPreset);
        }
      }
    } catch (_) {
      _startScan(_selectedPreset);
    }
  }

  Future<void> _pickGalleryPhoto() async {
    try {
      final image = await _picker.pickImage(source: ImageSource.gallery);
      if (image != null) {
        setState(() {
          _capturedImage = image;
        });
        _startScan(_selectedPreset);
      }
    } catch (_) {
      _startScan(_selectedPreset);
    }
  }

  void _resetToLiveCamera() {
    setState(() {
      _capturedImage = null;
      _scannerResult = null;
    });
  }

  Future<void> _startScan(String presetId) async {
    setState(() {
      _selectedPreset = presetId;
      _isScanning = true;
      _scannerResult = null;
    });

    final result = await AIService.analyzeAndSegregateScrapImage(presetId);

    if (mounted) {
      setState(() {
        _isScanning = false;
        _scannerResult = result;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);
    final screenHeight = MediaQuery.of(context).size.height;
    final isCameraActive = widget.isVisible && _cameraController != null && _cameraController!.value.isInitialized;

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
        _navigateToHome(context);
      },
      child: Scaffold(
        backgroundColor: const Color(0xFF0F172A),
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
            onPressed: () => _navigateToHome(context),
            tooltip: 'Back to Home Screen',
          ),
          title: const Text('AI Vision Scrap Scanner', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18)),
          iconTheme: const IconThemeData(color: Colors.white),
        ),
        body: SafeArea(
          child: Column(
            children: [
              // Top Scrollable Category Preset Chips
              Container(
                color: Colors.black.withValues(alpha: 0.3),
                width: double.infinity,
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  child: Row(
                    children: _presets.map((p) {
                      final isSelected = p['id'] == _selectedPreset;
                      return Padding(
                        padding: const EdgeInsets.only(right: 8.0),
                        child: ChoiceChip(
                          label: Text(p['name']!),
                          selected: isSelected,
                          selectedColor: const Color(0xFF155EEF),
                          labelStyle: TextStyle(
                            color: isSelected ? Colors.white : Colors.white70,
                            fontWeight: FontWeight.bold,
                            fontSize: 12,
                          ),
                          backgroundColor: const Color(0xFF1E293B),
                          onSelected: (_) => _startScan(p['id']!),
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ),

              // Camera Viewfinder HUD
              Expanded(
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    // LIVE DEVICE CAMERA PREVIEW FEED
                    if (isCameraActive && _capturedImage == null)
                      SizedBox.expand(
                        child: FittedBox(
                          fit: BoxFit.cover,
                          child: SizedBox(
                            width: _cameraController!.value.previewSize?.height ?? 1920,
                            height: _cameraController!.value.previewSize?.width ?? 1080,
                            child: CameraPreview(_cameraController!),
                          ),
                        ),
                      )
                    else if (_capturedImage != null)
                      kIsWeb
                          ? Image.network(_capturedImage!.path, width: double.infinity, height: double.infinity, fit: BoxFit.cover)
                          : Image.file(File(_capturedImage!.path), width: double.infinity, height: double.infinity, fit: BoxFit.cover)
                    else
                      Container(
                        color: const Color(0xFF1E293B),
                        child: Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: const [
                              CircularProgressIndicator(color: Color(0xFF155EEF)),
                              SizedBox(height: 12),
                              Text('Initializing Live Device Camera Feed...', style: TextStyle(color: Color(0xFFD9E7FF), fontSize: 13)),
                            ],
                          ),
                        ),
                      ),

                    // HUD Viewfinder Target Box
                    Container(
                      margin: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        border: Border.all(color: const Color(0xFF155EEF), width: 2),
                        borderRadius: BorderRadius.circular(20),
                      ),
                    ),

                    // Camera Controls Top Right Badge
                    Positioned(
                      top: 16,
                      right: 16,
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: 0.6),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Row(
                          children: [
                            if (_capturedImage != null)
                              IconButton(
                                icon: const Icon(Icons.refresh_rounded, color: Color(0xFF155EEF), size: 20),
                                onPressed: _resetToLiveCamera,
                                tooltip: 'Retake Live Photo',
                              ),
                            IconButton(
                              icon: const Icon(Icons.camera_alt_rounded, color: Colors.white, size: 20),
                              onPressed: () {
                                if (!_hasCameraPermission) {
                                  _requestPermissionsDialog(context, 'camera');
                                } else {
                                  _captureDeviceCameraPhoto();
                                }
                              },
                              tooltip: 'Capture Camera Photo',
                            ),
                            IconButton(
                              icon: const Icon(Icons.photo_library_rounded, color: Colors.white, size: 20),
                              onPressed: () {
                                if (!_hasStoragePermission) {
                                  _requestPermissionsDialog(context, 'storage');
                                } else {
                                  _pickGalleryPhoto();
                                }
                              },
                              tooltip: 'Upload from Gallery Storage',
                            ),
                          ],
                        ),
                      ),
                    ),

                    // Center Shutter Button (Takes photo)
                    Positioned(
                      bottom: 20,
                      child: GestureDetector(
                        onTap: () {
                          if (_capturedImage != null) {
                            _resetToLiveCamera();
                          } else if (!_hasCameraPermission || !_hasStoragePermission) {
                            _requestPermissionsDialog(context, 'ai_vision_shutter');
                          } else {
                            _captureDeviceCameraPhoto();
                          }
                        },
                        child: Container(
                          padding: const EdgeInsets.all(4),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.white, width: 3),
                          ),
                          child: CircleAvatar(
                            radius: 26,
                            backgroundColor: const Color(0xFF155EEF),
                            child: Icon(
                              _capturedImage != null ? Icons.refresh_rounded : Icons.camera_rounded,
                              color: Colors.white,
                              size: 26,
                            ),
                          ),
                        ),
                      ),
                    ),

                    if (_isScanning)
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const CircularProgressIndicator(color: Color(0xFF155EEF)),
                          const SizedBox(height: 16),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                            decoration: BoxDecoration(
                              color: Colors.black87,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: const Text(
                              'AI Computer Vision Analyzing Material Purity...',
                              style: TextStyle(color: Color(0xFFD9E7FF), fontWeight: FontWeight.bold, fontSize: 13),
                            ),
                          ),
                        ],
                      ),
                  ],
                ),
              ),

              // Bottom Result Sheet (Scrollable & Constrained to prevent layout overflows)
              if (_scannerResult != null && !_isScanning)
                Flexible(
                  child: Container(
                    constraints: BoxConstraints(maxHeight: screenHeight * 0.42),
                    padding: const EdgeInsets.all(16),
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
                    ),
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Expanded(
                                child: Text(
                                  _scannerResult!.title,
                                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Color(0xFF0F172A)),
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(
                                  color: const Color(0xFFEFF6FF),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Text(
                                  '${(_scannerResult!.overallPurityScore * 100).toStringAsFixed(0)}% Purity',
                                  style: const TextStyle(color: Color(0xFF1D4ED8), fontWeight: FontWeight.bold, fontSize: 12),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 6),
                          Text(
                            _scannerResult!.detectedMaterialSummary,
                            style: const TextStyle(color: Color(0xFF64748B), fontSize: 12),
                          ),
                          const Divider(height: 16),

                          // Itemized Segregated Items Breakdown List
                          const Text(
                            'Segregated Item Breakdown:',
                            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Color(0xFF334155)),
                          ),
                          const SizedBox(height: 6),
                          ..._scannerResult!.items.map((item) {
                            return Container(
                              margin: const EdgeInsets.only(bottom: 6),
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: const Color(0xFFF8FAFC),
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(color: const Color(0xFFE2E8F0)),
                              ),
                              child: Row(
                                children: [
                                  Icon(item.category.icon, size: 20, color: item.category.color),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(item.itemName, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                                        Text('${item.conditionNote} • ${(item.confidenceScore * 100).toStringAsFixed(0)}% confidence', style: const TextStyle(fontSize: 10, color: Colors.grey)),
                                      ],
                                    ),
                                  ),
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      Text('₹${item.totalPrice.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Color(0xFF0B1F3A))),
                                      Text('${item.estimatedWeightKg.toStringAsFixed(0)} kg @ ₹${item.ratePerKg.toStringAsFixed(0)}/kg', style: const TextStyle(fontSize: 10, color: Colors.grey)),
                                    ],
                                  ),
                                ],
                              ),
                            );
                          }),

                          const SizedBox(height: 10),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text('Est. Weight: ${_scannerResult!.estimatedTotalWeightKg.toStringAsFixed(0)} kg', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                              Text('Est. Value: ₹${_scannerResult!.estimatedTotalValue.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18, color: Color(0xFF0B1F3A))),
                            ],
                          ),
                          const SizedBox(height: 14),
                          SizedBox(
                            width: double.infinity,
                            child: ElevatedButton.icon(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFF155EEF),
                                padding: const EdgeInsets.symmetric(vertical: 14),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                              ),
                              onPressed: () {
                                final newListing = ScrapListing(
                                  id: 'LST-${DateTime.now().millisecondsSinceEpoch.toString().substring(7)}',
                                  title: _scannerResult!.title,
                                  items: _scannerResult!.items,
                                  location: 'Sector 62, Noida, UP (Current Loc)',
                                  imageUrl: _capturedImage != null ? _capturedImage!.path : 'https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?w=500',
                                  createdAt: DateTime.now(),
                                  sellerName: 'Rahul Sharma',
                                  sellerPhone: '+91 98765 43210',
                                );
                                appState.addListing(newListing);

                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text('Marketplace Batch Listing Created Successfully! Recyclers notified.'),
                                    backgroundColor: Color(0xFF155EEF),
                                  ),
                                );
                                _navigateToHome(context);
                              },
                              icon: const Icon(Icons.add_task_rounded, color: Colors.white),
                              label: const Text('Create Instant Marketplace Listing', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
