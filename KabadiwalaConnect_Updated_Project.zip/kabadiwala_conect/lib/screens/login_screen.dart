import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/app_state.dart';
import '../services/auth_service.dart';
import '../models/user_model.dart' as firebase_models;
import '../widget/responsive.dart';
import 'role_home_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  bool _isRegisterMode = false; // Toggle between Sign In & Registration

  // OTP Verification State
  bool _otpSent = false;
  DateTime? _otpExpiryTime;

  // 2-Minute Cooldown Timer State
  Timer? _resendTimer;
  int _resendCooldownSeconds = 0;

  final AuthService _authService = AuthService();
  UserRole _selectedRole = UserRole.householdSeller;
  bool _useEmailPasswordSignIn = false;
  bool _obscurePassword = true;

  // Controllers initialized empty for Sign Up mode
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _addressController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _otpController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _selectedRole = Provider.of<AppState>(context, listen: false).currentRole;
  }

  @override
  void dispose() {
    _resendTimer?.cancel();
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _addressController.dispose();
    _passwordController.dispose();
    _otpController.dispose();
    super.dispose();
  }

  void _clearSignUpFields() {
    _nameController.clear();
    _emailController.clear();
    _phoneController.clear();
    _addressController.clear();
    _passwordController.clear();
    _otpController.clear();
    _resendTimer?.cancel();
    setState(() {
      _otpSent = false;
      _otpExpiryTime = null;
      _resendCooldownSeconds = 0;
    });
  }

  void _startResendTimer() {
    _resendTimer?.cancel();
    setState(() {
      _resendCooldownSeconds = 120; // 2 minutes cooldown
    });
    _resendTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      if (_resendCooldownSeconds <= 1) {
        timer.cancel();
        setState(() {
          _resendCooldownSeconds = 0;
        });
      } else {
        setState(() {
          _resendCooldownSeconds--;
        });
      }
    });
  }

  Future<void> _generateAndSendOtp() async {
    if (_resendCooldownSeconds > 0) return; // Block tapping during cooldown

    final phone = _phoneController.text.trim();
    final phoneDigits = phone.replaceAll(RegExp(r'\D'), '');
    final validIndianNumber =
        phoneDigits.length == 10 ||
        (phoneDigits.length == 12 && phoneDigits.startsWith('91'));
    if (!validIndianNumber) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please enter a valid 10-digit mobile number first.'),
        ),
      );
      return;
    }

    setState(() => _otpSent = false);
    await _authService.sendPhoneOtp(
      phoneNumber: phone,
      onCodeSent: (_) {
        if (!mounted) return;
        setState(() {
          _otpExpiryTime = DateTime.now().add(const Duration(minutes: 10));
          _otpSent = true;
          _otpController.clear();
        });
        _startResendTimer();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Verification code sent.')),
        );
      },
      onError: (message) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(message), backgroundColor: Colors.redAccent),
        );
      },
    );
  }

  Future<void> _submitAuth(AppState appState) async {
    final messenger = ScaffoldMessenger.of(context);
    final navigator = Navigator.of(context);

    // Sign in with the same phone OTP provider used during registration.
    if (!_isRegisterMode) {
      if (_useEmailPasswordSignIn) {
        if (!_formKey.currentState!.validate()) return;
        try {
          final user = await _authService.signInWithEmail(
            email: _emailController.text.trim(),
            password: _passwordController.text,
          );
          final appRole = _toAppRole(user.role);
          if (appRole != _selectedRole) {
            await _authService.signOut();
            messenger.showSnackBar(
              SnackBar(
                content: Text(
                  'This account is registered as ${appRole.displayName}. Select that profile to continue.',
                ),
                backgroundColor: Colors.redAccent,
              ),
            );
            return;
          }
          appState.login(role: appRole, name: user.name);
          navigator.pushAndRemoveUntil(
            MaterialPageRoute(builder: (_) => const RoleHomeScreen()),
            (route) => false,
          );
        } catch (error) {
          messenger.showSnackBar(
            SnackBar(
              content: Text('Sign in failed: $error'),
              backgroundColor: Colors.redAccent,
            ),
          );
        }
        return;
      }

      if (!_otpSent) {
        await _generateAndSendOtp();
        return;
      }

      final enteredOtp = _otpController.text.trim();
      if (enteredOtp.length != 6) {
        messenger.showSnackBar(
          const SnackBar(content: Text('Enter the 6-digit code from the SMS.')),
        );
        return;
      }
      if (_otpExpiryTime != null && DateTime.now().isAfter(_otpExpiryTime!)) {
        messenger.showSnackBar(
          const SnackBar(
            content: Text('That code expired. Request a new sign-in code.'),
          ),
        );
        return;
      }
      if (!_formKey.currentState!.validate()) return;

      try {
        final user = await _authService.signInWithPhoneOtp(smsCode: enteredOtp);
        final appRole = _toAppRole(user.role);
        if (appRole != _selectedRole) {
          await _authService.signOut();
          messenger.showSnackBar(
            SnackBar(
              content: Text(
                'This phone is registered as ${appRole.displayName}. Select that profile to continue.',
              ),
              backgroundColor: Colors.redAccent,
            ),
          );
          return;
        }
        appState.login(role: appRole, name: user.name);
        navigator.pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const RoleHomeScreen()),
          (route) => false,
        );
      } catch (error) {
        messenger.showSnackBar(
          SnackBar(
            content: Text('Sign in failed: $error'),
            backgroundColor: Colors.redAccent,
          ),
        );
      }
      return;
    }

    // REGISTRATION MODE: Step 1 - Send OTP if not sent yet
    if (!_otpSent) {
      _generateAndSendOtp();
      return;
    }

    // Step 2: Validate 6-Digit OTP Code Expiry & Value
    final enteredOtp = _otpController.text.trim();
    if (enteredOtp.length != 6) {
      messenger.showSnackBar(
        const SnackBar(
          content: Text('Enter the 6-digit code from the SMS.'),
          backgroundColor: Colors.redAccent,
        ),
      );
      return;
    }

    if (_otpExpiryTime != null && DateTime.now().isAfter(_otpExpiryTime!)) {
      messenger.showSnackBar(
        const SnackBar(
          content: Text(
            'OTP code expired (10 minutes limit). Tap "Resend OTP" to get a new code.',
          ),
        ),
      );
      return;
    }

    if (!_formKey.currentState!.validate()) return;

    final name = _nameController.text.trim();
    final address = _addressController.text.trim();

    final role = switch (_selectedRole) {
      UserRole.householdSeller => firebase_models.UserRole.customer,
      UserRole.kabadiwalaTrader => firebase_models.UserRole.kabadiwala,
      UserRole.industrialRecycler => firebase_models.UserRole.recycler,
      UserRole.platformAdmin => firebase_models.UserRole.admin,
    };

    try {
      final user = await _authService.verifyOtpAndSignIn(
        smsCode: enteredOtp,
        role: role,
        name: name,
        email: _emailController.text.trim(),
        address: address,
      );
      final appRole = _toAppRole(user.role);
      if (appRole != _selectedRole) {
        await _authService.signOut();
        messenger.showSnackBar(
          SnackBar(
            content: Text(
              'This phone is already registered as ${appRole.displayName}. Select that profile to continue.',
            ),
            backgroundColor: Colors.redAccent,
          ),
        );
        return;
      }
      appState.login(role: appRole, name: user.name);
      if (mounted) {
        messenger.showSnackBar(
          SnackBar(
            content: Text(
              'Welcome ${user.name}! Phone verified & registration complete.',
            ),
            backgroundColor: const Color(0xFF155EEF),
            duration: const Duration(seconds: 2),
          ),
        );
        navigator.pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const RoleHomeScreen()),
          (route) => false,
        );
      }
    } catch (error) {
      if (mounted) {
        messenger.showSnackBar(
          SnackBar(
            content: Text('Registration failed: $error'),
            backgroundColor: Colors.redAccent,
          ),
        );
      }
    }
  }

  UserRole _toAppRole(firebase_models.UserRole role) => switch (role) {
    firebase_models.UserRole.customer => UserRole.householdSeller,
    firebase_models.UserRole.kabadiwala => UserRole.kabadiwalaTrader,
    firebase_models.UserRole.recycler => UserRole.industrialRecycler,
    firebase_models.UserRole.admin => UserRole.platformAdmin,
  };

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);

    return Scaffold(
      backgroundColor: const Color(
        0xFF0B1F3A,
      ), // 02 Deep Blue + Sky (Deep Navy)
      body: SafeArea(
        child: Align(
          alignment: Alignment.center,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 580),
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: EdgeInsets.all(Responsive.width(context, 5)),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Header Logo & Branding
                    Center(
                      child: Column(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: Colors.white.withValues(alpha: 0.15),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(
                              Icons.recycling_rounded,
                              color: Colors.white,
                              size: 48,
                            ),
                          ),
                          const SizedBox(height: 12),
                          Text(
                            'Kabadiwala Connect',
                            style: TextStyle(
                              fontSize: Responsive.sp(context, 24),
                              fontWeight: FontWeight.w900,
                              color: Colors.white,
                              letterSpacing: -0.5,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            _isRegisterMode
                                ? 'First-Time User Registration & OTP Verification'
                                : 'Welcome back! Verify your registered phone number to sign in.',
                            style: TextStyle(
                              fontSize: Responsive.sp(context, 13),
                              color: const Color(0xFFD9E7FF), // Sky blue accent
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),

                    // Login vs Register Segmented Mode Switcher
                    Container(
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: GestureDetector(
                              onTap: () {
                                setState(() {
                                  _isRegisterMode = false;
                                });
                              },
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                  vertical: 10,
                                ),
                                decoration: BoxDecoration(
                                  color: !_isRegisterMode
                                      ? const Color(0xFF155EEF)
                                      : Colors.transparent,
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Text(
                                  'Sign In',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: Responsive.sp(context, 13),
                                    color: !_isRegisterMode
                                        ? Colors.white
                                        : const Color(0xFFD9E7FF),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Expanded(
                            child: GestureDetector(
                              onTap: () {
                                setState(() {
                                  _isRegisterMode = true;
                                  _clearSignUpFields(); // Clear all textfields for Sign Up
                                });
                              },
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                  vertical: 10,
                                ),
                                decoration: BoxDecoration(
                                  color: _isRegisterMode
                                      ? const Color(0xFF155EEF)
                                      : Colors.transparent,
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Text(
                                  'New User Register',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: Responsive.sp(context, 13),
                                    color: _isRegisterMode
                                        ? Colors.white
                                        : const Color(0xFFD9E7FF),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),

                    // Role Option Cards Box ("What are you?")
                    Text(
                      _isRegisterMode
                          ? 'What are you? Select your profile:'
                          : 'Select your registered profile:',
                      style: TextStyle(
                        fontSize: Responsive.sp(context, 13),
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 8),
                    _buildRoleOptionTile(
                      role: UserRole.householdSeller,
                      title: 'Household Person',
                      subtitle:
                          'I want to sell household scrap & book doorstep pickup',
                      icon: Icons.home_rounded,
                      color: const Color(0xFF155EEF),
                    ),
                    const SizedBox(height: 8),
                    _buildRoleOptionTile(
                      role: UserRole.kabadiwalaTrader,
                      title: 'Scrap Trader / Kabadiwala',
                      subtitle:
                          'I collect scrap, scan with AI & trade with bulk recyclers',
                      icon: Icons.local_shipping_rounded,
                      color: const Color(0xFF3B82F6),
                    ),
                    const SizedBox(height: 8),
                    _buildRoleOptionTile(
                      role: UserRole.industrialRecycler,
                      title: 'Industrial Recycler',
                      subtitle:
                          'I buy bulk segregated scrap for factory processing',
                      icon: Icons.factory_rounded,
                      color: const Color(0xFFA855F7),
                    ),
                    const SizedBox(height: 20),

                    // Registration Specific Fields
                    if (_isRegisterMode) ...[
                      Text(
                        'Full Name / Business Title',
                        style: TextStyle(
                          fontSize: Responsive.sp(context, 12),
                          fontWeight: FontWeight.bold,
                          color: const Color(0xFFD9E7FF),
                        ),
                      ),
                      const SizedBox(height: 6),
                      TextFormField(
                        controller: _nameController,
                        style: const TextStyle(
                          color: Color(0xFF0F172A),
                          fontWeight: FontWeight.w600,
                          fontSize: 14,
                        ),
                        decoration: InputDecoration(
                          hintText: 'e.g. Rahul Sharma or Ramesh Scrap Depot',
                          hintStyle: const TextStyle(
                            color: Color(0xFF94A3B8),
                            fontSize: 13,
                          ),
                          prefixIcon: const Icon(
                            Icons.badge_outlined,
                            color: Color(0xFF155EEF),
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: BorderSide.none,
                          ),
                          filled: true,
                          fillColor: Colors.white,
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 14,
                          ),
                        ),
                        validator: (val) => (val == null || val.isEmpty)
                            ? 'Please enter your name'
                            : null,
                      ),
                      const SizedBox(height: 14),

                      Text(
                        'Email Address',
                        style: TextStyle(
                          fontSize: Responsive.sp(context, 12),
                          fontWeight: FontWeight.bold,
                          color: const Color(0xFFD9E7FF),
                        ),
                      ),
                      const SizedBox(height: 6),
                      TextFormField(
                        controller: _emailController,
                        keyboardType: TextInputType.emailAddress,
                        style: const TextStyle(
                          color: Color(0xFF0F172A),
                          fontWeight: FontWeight.w600,
                          fontSize: 14,
                        ),
                        decoration: InputDecoration(
                          hintText: 'e.g. rahul.sharma@example.com',
                          hintStyle: const TextStyle(
                            color: Color(0xFF94A3B8),
                            fontSize: 13,
                          ),
                          prefixIcon: const Icon(
                            Icons.email_outlined,
                            color: Color(0xFF155EEF),
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: BorderSide.none,
                          ),
                          filled: true,
                          fillColor: Colors.white,
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 14,
                          ),
                        ),
                        validator: (val) => (val == null || !val.contains('@'))
                            ? 'Please enter a valid email'
                            : null,
                      ),
                      const SizedBox(height: 14),

                      Text(
                        'Mobile Number for Phone Verification',
                        style: TextStyle(
                          fontSize: Responsive.sp(context, 12),
                          fontWeight: FontWeight.bold,
                          color: const Color(0xFFD9E7FF),
                        ),
                      ),
                      const SizedBox(height: 6),
                      Row(
                        children: [
                          Expanded(
                            child: TextFormField(
                              controller: _phoneController,
                              keyboardType: TextInputType.phone,
                              style: const TextStyle(
                                color: Color(0xFF0F172A),
                                fontWeight: FontWeight.w600,
                                fontSize: 14,
                              ),
                              decoration: InputDecoration(
                                hintText: '10-digit mobile number',
                                hintStyle: const TextStyle(
                                  color: Color(0xFF94A3B8),
                                  fontSize: 13,
                                ),
                                prefixIcon: const Padding(
                                  padding: EdgeInsets.all(12.0),
                                  child: Text(
                                    '+91 ',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: Color(0xFF155EEF),
                                      fontSize: 14,
                                    ),
                                  ),
                                ),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(14),
                                  borderSide: BorderSide.none,
                                ),
                                filled: true,
                                fillColor: Colors.white,
                                contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 16,
                                  vertical: 14,
                                ),
                              ),
                              validator: (val) => (val == null || val.isEmpty)
                                  ? 'Please enter mobile number'
                                  : null,
                            ),
                          ),
                          const SizedBox(width: 8),
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: _resendCooldownSeconds > 0
                                  ? Colors.grey
                                  : const Color(0xFF155EEF),
                              padding: const EdgeInsets.symmetric(
                                horizontal: 12,
                                vertical: 14,
                              ),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                            onPressed: _resendCooldownSeconds > 0
                                ? null
                                : _generateAndSendOtp,
                            child: Text(
                              _resendCooldownSeconds > 0
                                  ? 'Resend in ${_resendCooldownSeconds ~/ 60}:${(_resendCooldownSeconds % 60).toString().padLeft(2, '0')}'
                                  : (_otpSent ? 'Resend OTP' : 'Send OTP'),
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 12,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),

                      // Standalone TextFormField for 6-Digit SMS Verification OTP
                      if (_otpSent) ...[
                        Text(
                          'Enter 6-Digit SMS Verification OTP',
                          style: TextStyle(
                            fontSize: Responsive.sp(context, 12),
                            fontWeight: FontWeight.bold,
                            color: const Color(0xFFD9E7FF),
                          ),
                        ),
                        const SizedBox(height: 6),
                        TextFormField(
                          controller: _otpController,
                          keyboardType: TextInputType.number,
                          style: const TextStyle(
                            color: Color(0xFF0F172A),
                            fontWeight: FontWeight.w900,
                            fontSize: 16,
                            letterSpacing: 4,
                          ),
                          decoration: InputDecoration(
                            hintText: 'Enter 6-digit OTP code',
                            hintStyle: const TextStyle(
                              color: Color(0xFF94A3B8),
                              fontSize: 13,
                              letterSpacing: 1,
                            ),
                            prefixIcon: const Icon(
                              Icons.mark_email_read_rounded,
                              color: Color(0xFF155EEF),
                            ),
                            suffixIcon: Container(
                              margin: const EdgeInsets.all(8),
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 4,
                              ),
                              decoration: BoxDecoration(
                                color: const Color(0xFFEFF6FF),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: const Text(
                                'Valid 10 Mins',
                                style: TextStyle(
                                  color: Color(0xFF1D4ED8),
                                  fontWeight: FontWeight.bold,
                                  fontSize: 10,
                                ),
                              ),
                            ),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(14),
                              borderSide: BorderSide.none,
                            ),
                            filled: true,
                            fillColor: Colors.white,
                            contentPadding: const EdgeInsets.symmetric(
                              horizontal: 16,
                              vertical: 14,
                            ),
                          ),
                          validator: (val) {
                            if (val == null || val.isEmpty) {
                              return 'Please enter 6-digit OTP';
                            }
                            if (val.trim().length != 6) {
                              return 'Enter the 6-digit SMS code';
                            }
                            return null;
                          },
                        ),
                        const SizedBox(height: 14),
                      ],

                      Text(
                        'City / Area Location',
                        style: TextStyle(
                          fontSize: Responsive.sp(context, 12),
                          fontWeight: FontWeight.bold,
                          color: const Color(0xFFD9E7FF),
                        ),
                      ),
                      const SizedBox(height: 6),
                      TextFormField(
                        controller: _addressController,
                        style: const TextStyle(
                          color: Color(0xFF0F172A),
                          fontWeight: FontWeight.w600,
                          fontSize: 14,
                        ),
                        decoration: InputDecoration(
                          hintText: 'e.g. Sector 62, Noida, UP',
                          hintStyle: const TextStyle(
                            color: Color(0xFF94A3B8),
                            fontSize: 13,
                          ),
                          prefixIcon: const Icon(
                            Icons.location_on_outlined,
                            color: Color(0xFF155EEF),
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: BorderSide.none,
                          ),
                          filled: true,
                          fillColor: Colors.white,
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 14,
                          ),
                        ),
                        validator: (val) => (val == null || val.isEmpty)
                            ? 'Please enter location'
                            : null,
                      ),
                      const SizedBox(height: 14),

                      const Padding(
                        padding: EdgeInsets.only(top: 12),
                        child: Text(
                          'Your verified phone number will be your sign-in method. No password is needed.',
                          style: TextStyle(
                            color: Color(0xFFD9E7FF),
                            fontSize: 12,
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),
                    ] else ...[
                      if (_useEmailPasswordSignIn) ...[
                        Text(
                          'Email Address',
                          style: TextStyle(
                            fontSize: Responsive.sp(context, 12),
                            fontWeight: FontWeight.bold,
                            color: const Color(0xFFD9E7FF),
                          ),
                        ),
                        const SizedBox(height: 6),
                        TextFormField(
                          controller: _emailController,
                          keyboardType: TextInputType.emailAddress,
                          style: const TextStyle(
                            color: Color(0xFF0F172A),
                            fontWeight: FontWeight.w600,
                            fontSize: 14,
                          ),
                          decoration: InputDecoration(
                            hintText: 'Enter your registered email',
                            prefixIcon: const Icon(Icons.email_outlined),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(14),
                              borderSide: BorderSide.none,
                            ),
                            filled: true,
                            fillColor: Colors.white,
                          ),
                          validator: (val) => val == null || !val.contains('@')
                              ? 'Enter a valid email address'
                              : null,
                        ),
                        const SizedBox(height: 14),
                        Text(
                          'Account Password',
                          style: TextStyle(
                            fontSize: Responsive.sp(context, 12),
                            fontWeight: FontWeight.bold,
                            color: const Color(0xFFD9E7FF),
                          ),
                        ),
                        const SizedBox(height: 6),
                        TextFormField(
                          controller: _passwordController,
                          obscureText: _obscurePassword,
                          style: const TextStyle(
                            color: Color(0xFF0F172A),
                            fontWeight: FontWeight.w600,
                            fontSize: 14,
                          ),
                          decoration: InputDecoration(
                            hintText: 'Enter your account password',
                            prefixIcon: const Icon(Icons.lock_outline_rounded),
                            suffixIcon: IconButton(
                              icon: Icon(
                                _obscurePassword
                                    ? Icons.visibility_off_rounded
                                    : Icons.visibility_rounded,
                                color: Colors.grey,
                              ),
                              onPressed: () => setState(
                                () => _obscurePassword = !_obscurePassword,
                              ),
                            ),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(14),
                              borderSide: BorderSide.none,
                            ),
                            filled: true,
                            fillColor: Colors.white,
                          ),
                          validator: (val) => val == null || val.isEmpty
                              ? 'Enter your account password'
                              : null,
                        ),
                      ] else ...[
                        // Sign in with the phone verified at registration.
                        Text(
                          'Mobile Number',
                          style: TextStyle(
                            fontSize: Responsive.sp(context, 12),
                            fontWeight: FontWeight.bold,
                            color: const Color(0xFFD9E7FF),
                          ),
                        ),
                        const SizedBox(height: 6),
                        Row(
                          children: [
                            Expanded(
                              child: TextFormField(
                                controller: _phoneController,
                                keyboardType: TextInputType.phone,
                                style: const TextStyle(
                                  color: Color(0xFF0F172A),
                                  fontWeight: FontWeight.w600,
                                  fontSize: 14,
                                ),
                                decoration: InputDecoration(
                                  hintText: '10-digit registered number',
                                  hintStyle: const TextStyle(
                                    color: Color(0xFF94A3B8),
                                    fontSize: 13,
                                  ),
                                  prefixIcon: const Padding(
                                    padding: EdgeInsets.all(12),
                                    child: Text(
                                      '+91',
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: Color(0xFF155EEF),
                                        fontSize: 14,
                                      ),
                                    ),
                                  ),
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(14),
                                    borderSide: BorderSide.none,
                                  ),
                                  filled: true,
                                  fillColor: Colors.white,
                                  contentPadding: const EdgeInsets.symmetric(
                                    horizontal: 16,
                                    vertical: 14,
                                  ),
                                ),
                                validator: (val) =>
                                    val == null ||
                                        val
                                                .replaceAll(RegExp(r'\D'), '')
                                                .length <
                                            10
                                    ? 'Enter your registered 10-digit number'
                                    : null,
                              ),
                            ),
                            const SizedBox(width: 8),
                            ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: _resendCooldownSeconds > 0
                                    ? Colors.grey
                                    : const Color(0xFF155EEF),
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 12,
                                  vertical: 14,
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                              ),
                              onPressed: _resendCooldownSeconds > 0
                                  ? null
                                  : _generateAndSendOtp,
                              child: Text(
                                _resendCooldownSeconds > 0
                                    ? 'Resend in ${_resendCooldownSeconds ~/ 60}:${(_resendCooldownSeconds % 60).toString().padLeft(2, '0')}'
                                    : (_otpSent ? 'Resend code' : 'Send code'),
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                          ],
                        ),
                        if (_otpSent) ...[
                          const SizedBox(height: 14),
                          Text(
                            'SMS Verification Code',
                            style: TextStyle(
                              fontSize: Responsive.sp(context, 12),
                              fontWeight: FontWeight.bold,
                              color: const Color(0xFFD9E7FF),
                            ),
                          ),
                          const SizedBox(height: 6),
                          TextFormField(
                            controller: _otpController,
                            keyboardType: TextInputType.number,
                            style: const TextStyle(
                              color: Color(0xFF0F172A),
                              fontWeight: FontWeight.w900,
                              fontSize: 16,
                              letterSpacing: 4,
                            ),
                            decoration: InputDecoration(
                              hintText: 'Enter the 6-digit code',
                              hintStyle: const TextStyle(
                                color: Color(0xFF94A3B8),
                                fontSize: 13,
                                letterSpacing: 1,
                              ),
                              prefixIcon: const Icon(
                                Icons.mark_email_read_rounded,
                                color: Color(0xFF155EEF),
                              ),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(14),
                                borderSide: BorderSide.none,
                              ),
                              filled: true,
                              fillColor: Colors.white,
                              contentPadding: const EdgeInsets.symmetric(
                                horizontal: 16,
                                vertical: 14,
                              ),
                            ),
                          ),
                        ],
                        const SizedBox(height: 10),
                        Text(
                          'We’ll verify your account role after the phone code is confirmed.',
                          style: TextStyle(
                            color: const Color(0xFFD9E7FF),
                            fontSize: Responsive.sp(context, 11),
                          ),
                        ),
                      ],
                      Center(
                        child: TextButton(
                          onPressed: () {
                            setState(() {
                              _useEmailPasswordSignIn =
                                  !_useEmailPasswordSignIn;
                              _otpSent = false;
                              _otpController.clear();
                              _resendTimer?.cancel();
                              _resendCooldownSeconds = 0;
                            });
                          },
                          child: Text(
                            _useEmailPasswordSignIn
                                ? 'Use phone verification code'
                                : 'Use email & password instead',
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),
                    ],

                    // Primary Action Button
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF155EEF), // Deep Blue
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          elevation: 4,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                        ),
                        onPressed: () => _submitAuth(appState),
                        child: Text(
                          _isRegisterMode
                              ? 'Create Account'
                              : (_useEmailPasswordSignIn
                                    ? 'Sign In as ${_selectedRole.displayName}'
                                    : (_otpSent
                                          ? 'Verify & Sign In as ${_selectedRole.displayName}'
                                          : 'Send Sign-In Code')),
                          style: TextStyle(
                            fontSize: Responsive.sp(context, 15),
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                    if (!_isRegisterMode) ...[
                      const SizedBox(height: 8),
                      Center(
                        child: TextButton.icon(
                          onPressed: () {
                            final demoName = switch (_selectedRole) {
                              UserRole.householdSeller =>
                                'Demo household seller',
                              UserRole.kabadiwalaTrader => 'Demo kabadiwala',
                              UserRole.industrialRecycler => 'Demo recycler',
                              UserRole.platformAdmin => 'Demo operator',
                            };
                            appState.login(role: _selectedRole, name: demoName);
                            Navigator.of(context).pushAndRemoveUntil(
                              MaterialPageRoute(
                                builder: (_) => const RoleHomeScreen(),
                              ),
                              (route) => false,
                            );
                          },
                          icon: const Icon(Icons.visibility_outlined),
                          label: Text(
                            'Preview ${_selectedRole.displayName} demo',
                          ),
                        ),
                      ),
                      const Center(
                        child: Text(
                          'Sample data only · demo actions stay on this device',
                          style: TextStyle(
                            color: Color(0xFFD9E7FF),
                            fontSize: 11,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Center(
                        child: TextButton.icon(
                          onPressed: () {
                            appState.login(
                              role: UserRole.platformAdmin,
                              name: 'Demo operator',
                            );
                            Navigator.of(context).pushAndRemoveUntil(
                              MaterialPageRoute(
                                builder: (_) => const RoleHomeScreen(),
                              ),
                              (route) => false,
                            );
                          },
                          icon: const Icon(Icons.admin_panel_settings_outlined),
                          label: const Text('Open admin demo panel'),
                        ),
                      ),
                      const Center(
                        child: Text(
                          'Local demo only · no administrator access is granted',
                          style: TextStyle(
                            color: Color(0xFFD9E7FF),
                            fontSize: 11,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ],
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildRoleOptionTile({
    required UserRole role,
    required String title,
    required String subtitle,
    required IconData icon,
    required Color color,
  }) {
    final isSelected = _selectedRole == role;

    return InkWell(
      onTap: () {
        setState(() {
          _selectedRole = role;
        });
      },
      borderRadius: BorderRadius.circular(16),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: isSelected
              ? Colors.white
              : Colors.white.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected ? color : Colors.white.withValues(alpha: 0.2),
            width: isSelected ? 2 : 1,
          ),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: isSelected
                    ? color.withValues(alpha: 0.15)
                    : Colors.white.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                icon,
                color: isSelected ? color : Colors.white,
                size: 22,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: Responsive.sp(context, 13),
                      color: isSelected
                          ? const Color(0xFF0F172A)
                          : Colors.white,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: TextStyle(
                      fontSize: Responsive.sp(context, 11),
                      color: isSelected
                          ? const Color(0xFF64748B)
                          : const Color(0xFFD9E7FF),
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              isSelected ? Icons.check_circle_rounded : Icons.circle_outlined,
              color: isSelected ? color : Colors.white38,
              size: 22,
            ),
          ],
        ),
      ),
    );
  }
}
