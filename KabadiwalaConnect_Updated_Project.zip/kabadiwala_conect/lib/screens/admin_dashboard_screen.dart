import 'package:flutter/material.dart';

class AdminDashboardScreen extends StatelessWidget {
  const AdminDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F6FA),
      appBar: AppBar(
        backgroundColor: const Color(0xFF211A3A),
        foregroundColor: Colors.white,
        title: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Admin console', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          Text('Marketplace oversight', style: TextStyle(fontSize: 12, color: Colors.white70)),
        ]),
        actions: [IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none_rounded), tooltip: 'Notifications')],
      ),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF43326F), Color(0xFF211A3A)]), borderRadius: BorderRadius.circular(22)),
          child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('PLATFORM OVERVIEW', style: TextStyle(color: Colors.white70, fontSize: 11, letterSpacing: 1.1, fontWeight: FontWeight.bold)),
            SizedBox(height: 16),
            Row(children: [Expanded(child: _Metric(value: '1,284', label: 'Active users')), Expanded(child: _Metric(value: '37', label: 'Open disputes')), Expanded(child: _Metric(value: '12', label: 'Reviews due'))]),
          ]),
        ),
        const SizedBox(height: 22),
        const Text('Review queue', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF211A3A))),
        const SizedBox(height: 10),
        const _ReviewCard(icon: Icons.factory_outlined, title: 'Recycler accreditations', detail: '4 facilities waiting for verification', action: 'Review facilities', color: Color(0xFF7C3AED)),
        const _ReviewCard(icon: Icons.gavel_outlined, title: 'Marketplace disputes', detail: '37 cases need resolution', action: 'Open disputes', color: Color(0xFFDC6803)),
        const _ReviewCard(icon: Icons.price_change_outlined, title: 'Category rates', detail: '6 material categories have stale rates', action: 'Manage price board', color: Color(0xFF2563EB)),
        const SizedBox(height: 18),
        const Text('Platform health', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF211A3A))),
        const SizedBox(height: 10),
        const _HealthRow(label: 'Pending pickups', value: '86', icon: Icons.local_shipping_outlined),
        const _HealthRow(label: 'Handover confirmations today', value: '213', icon: Icons.fact_check_outlined),
        const _HealthRow(label: 'Accounts requiring attention', value: '9', icon: Icons.person_search_outlined),
        const SizedBox(height: 16),
        Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: const Color(0xFFFFF1F0), borderRadius: BorderRadius.circular(12)), child: const Text('Restricted workspace preview. Admin access must be granted through a trusted server-side process; never select an admin role during public sign-up.', style: TextStyle(fontSize: 11, color: Color(0xFF912018)))),
      ]),
    );
  }
}

class _Metric extends StatelessWidget {
  const _Metric({required this.value, required this.label});
  final String value;
  final String label;
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(value, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800)), const SizedBox(height: 3), Text(label, style: const TextStyle(color: Colors.white70, fontSize: 10))]);
}

class _ReviewCard extends StatelessWidget {
  const _ReviewCard({required this.icon, required this.title, required this.detail, required this.action, required this.color});
  final IconData icon;
  final String title;
  final String detail;
  final String action;
  final Color color;
  @override
  Widget build(BuildContext context) => Card(color: Colors.white, elevation: 0, margin: const EdgeInsets.only(bottom: 9), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)), child: Padding(padding: const EdgeInsets.all(15), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [CircleAvatar(backgroundColor: color.withValues(alpha: .1), child: Icon(icon, color: color)), const SizedBox(width: 11), Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)))]), const SizedBox(height: 8), Text(detail, style: const TextStyle(color: Colors.black54, fontSize: 12)), Align(alignment: Alignment.centerRight, child: TextButton(onPressed: () {}, child: Text(action)))])));
}

class _HealthRow extends StatelessWidget {
  const _HealthRow({required this.label, required this.value, required this.icon});
  final String label;
  final String value;
  final IconData icon;
  @override
  Widget build(BuildContext context) => Container(margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14)), child: Row(children: [Icon(icon, size: 19, color: const Color(0xFF514477)), const SizedBox(width: 10), Expanded(child: Text(label, style: const TextStyle(fontSize: 13))), Text(value, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold))]));
}
