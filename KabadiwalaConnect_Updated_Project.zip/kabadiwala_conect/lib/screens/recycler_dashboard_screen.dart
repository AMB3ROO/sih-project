import 'package:flutter/material.dart';

const _recyclerGreen = Color(0xFF15803D);

class RecyclerDashboardScreen extends StatelessWidget {
  const RecyclerDashboardScreen({super.key});

  static const _navy = Color(0xFF12302B);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F8F4),
      appBar: AppBar(
        backgroundColor: _navy,
        foregroundColor: Colors.white,
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Recycler workspace', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Text('Facility intake & material sourcing', style: TextStyle(fontSize: 12, color: Colors.white70)),
          ],
        ),
        actions: [IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none_rounded), tooltip: 'Notifications')],
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(color: _navy, borderRadius: BorderRadius.circular(22)),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('TODAY AT YOUR FACILITY', style: TextStyle(color: Colors.white70, fontSize: 11, letterSpacing: 1.1, fontWeight: FontWeight.bold)),
                SizedBox(height: 14),
                Row(children: [
                  Expanded(child: _SummaryValue(value: '08', label: 'Batches to review')),
                  Expanded(child: _SummaryValue(value: '1.24 t', label: 'Expected today')),
                  Expanded(child: _SummaryValue(value: '₹42.8k', label: 'Pending settlement')),
                ]),
              ],
            ),
          ),
          const SizedBox(height: 22),
          const _SectionTitle(title: 'Operations', subtitle: 'Manage incoming material and compliance'),
          const SizedBox(height: 10),
          const Row(children: [
            Expanded(child: _ActionCard(icon: Icons.inventory_2_outlined, title: 'Incoming batches', detail: 'Review offers and scheduled arrivals', color: _recyclerGreen)),
            SizedBox(width: 10),
            Expanded(child: _ActionCard(icon: Icons.fact_check_outlined, title: 'Verify intake', detail: 'Confirm weight and material grade', color: Color(0xFF2563EB))),
          ]),
          const SizedBox(height: 10),
          const Row(children: [
            Expanded(child: _ActionCard(icon: Icons.price_change_outlined, title: 'Material rates', detail: 'Set current buying prices', color: Color(0xFFB45309))),
            SizedBox(width: 10),
            Expanded(child: _ActionCard(icon: Icons.verified_user_outlined, title: 'Facility status', detail: 'Accreditation and accepted materials', color: Color(0xFF7C3AED))),
          ]),
          const SizedBox(height: 22),
          const _SectionTitle(title: 'Latest handovers', subtitle: 'Recent deliveries recorded for your facility'),
          const SizedBox(height: 10),
          const _HandoverRow(name: 'Mixed PET bottles', partner: 'Ramesh Scrap Depot · 10:42 AM', weight: '186 kg', status: 'Awaiting weigh-in'),
          const _HandoverRow(name: 'Sorted cardboard', partner: 'City Collection · Yesterday', weight: '420 kg', status: 'Verified'),
          const SizedBox(height: 16),
          const _DemoNotice(),
        ],
      ),
    );
  }
}

class _SummaryValue extends StatelessWidget {
  const _SummaryValue({required this.value, required this.label});
  final String value;
  final String label;
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(value, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800)),
        const SizedBox(height: 3),
        Text(label, style: const TextStyle(color: Colors.white70, fontSize: 10)),
      ]);
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle({required this.title, required this.subtitle});
  final String title;
  final String subtitle;
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF172B24))),
        const SizedBox(height: 3),
        Text(subtitle, style: const TextStyle(fontSize: 12, color: Color(0xFF64756C))),
      ]);
}

class _ActionCard extends StatelessWidget {
  const _ActionCard({required this.icon, required this.title, required this.detail, required this.color});
  final IconData icon;
  final String title;
  final String detail;
  final Color color;
  @override
  Widget build(BuildContext context) => Container(
        constraints: const BoxConstraints(minHeight: 126),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFE3ECE5))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(icon, color: color),
          const SizedBox(height: 10),
          Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          Text(detail, style: const TextStyle(fontSize: 11, color: Color(0xFF64756C))),
        ]),
      );
}

class _HandoverRow extends StatelessWidget {
  const _HandoverRow({required this.name, required this.partner, required this.weight, required this.status});
  final String name;
  final String partner;
  final String weight;
  final String status;
  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
        child: Row(children: [
          const CircleAvatar(backgroundColor: Color(0xFFE4F3E8), child: Icon(Icons.recycling_rounded, color: _recyclerGreen)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(name, style: const TextStyle(fontWeight: FontWeight.bold)), Text(partner, style: const TextStyle(fontSize: 11, color: Colors.black54))])),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [Text(weight, style: const TextStyle(fontWeight: FontWeight.bold)), Text(status, style: const TextStyle(fontSize: 10, color: _recyclerGreen))]),
        ]),
      );
}

class _DemoNotice extends StatelessWidget {
  const _DemoNotice();
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: const Color(0xFFFFF7E6), borderRadius: BorderRadius.circular(12)),
        child: const Text('Preview data is shown here. Connect approved recycler accounts and facility records before using intake or settlement actions.', style: TextStyle(fontSize: 11, color: Color(0xFF805400))),
      );
}
