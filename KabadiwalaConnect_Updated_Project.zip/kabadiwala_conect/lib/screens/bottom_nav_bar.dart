import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/app_state.dart';
import '../widget/app_svg_icons.dart';
import 'home_screen.dart';
import 'category_screen.dart';
import 'ai_scanner_screen.dart';
import 'cart_screen.dart';
import 'favourites_screen.dart';

class BottomNavBar extends StatefulWidget {
  final int initialIndex;
  final bool showDeniedPopup;

  const BottomNavBar({
    super.key,
    this.initialIndex = 0,
    this.showDeniedPopup = false,
  });

  @override
  State<BottomNavBar> createState() => _BottomNavBarState();
}

class _BottomNavBarState extends State<BottomNavBar> {
  late int _selectedIndex;

  @override
  void initState() {
    super.initState();
    _selectedIndex = widget.initialIndex;
  }

  void _selectTab(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);
    final cartCount = appState.cartItems.length;

    final screens = [
      HomeScreen(showDeniedPopup: widget.showDeniedPopup),
      CategoryScreen(onBackToHome: () => _selectTab(0)),
      AIScannerScreen(
        isVisible: _selectedIndex == 2,
        onBackToHome: () => _selectTab(0),
      ),
      CartScreen(onExploreMarket: () => _selectTab(0)),
      const FavouritesScreen(),
    ];

    return Scaffold(
      body: IndexedStack(
        index: _selectedIndex,
        children: screens,
      ),
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Color(0x14000000),
              blurRadius: 10,
              offset: Offset(0, -2),
            ),
          ],
        ),
        child: SafeArea(
          child: NavigationBar(
            selectedIndex: _selectedIndex,
            onDestinationSelected: (index) => _selectTab(index),
            backgroundColor: Colors.white,
            indicatorColor: const Color(0xFFD9E7FF), // Light Sky Blue
            destinations: [
              NavigationDestination(
                icon: const AppSvgIconWidget(svgData: AppSvgIcons.navHome, size: 22, color: Color(0xFF64748B)),
                selectedIcon: const AppSvgIconWidget(svgData: AppSvgIcons.navHome, size: 22, color: Color(0xFF155EEF)),
                label: 'Home',
              ),
              NavigationDestination(
                icon: const AppSvgIconWidget(svgData: AppSvgIcons.navRates, size: 22, color: Color(0xFF64748B)),
                selectedIcon: const AppSvgIconWidget(svgData: AppSvgIcons.navRates, size: 22, color: Color(0xFF155EEF)),
                label: 'Rates',
              ),
              NavigationDestination(
                icon: const AppSvgIconWidget(svgData: AppSvgIcons.navAiVision, size: 26, color: Color(0xFF155EEF)),
                selectedIcon: const AppSvgIconWidget(svgData: AppSvgIcons.navAiVision, size: 26, color: Color(0xFF0B1F3A)),
                label: 'AI Vision',
              ),
              NavigationDestination(
                icon: Badge(
                  label: Text('$cartCount'),
                  isLabelVisible: cartCount > 0,
                  backgroundColor: const Color(0xFF155EEF),
                  child: const AppSvgIconWidget(svgData: AppSvgIcons.navPickupBag, size: 22, color: Color(0xFF64748B)),
                ),
                selectedIcon: Badge(
                  label: Text('$cartCount'),
                  isLabelVisible: cartCount > 0,
                  backgroundColor: const Color(0xFF155EEF),
                  child: const AppSvgIconWidget(svgData: AppSvgIcons.navPickupBag, size: 22, color: Color(0xFF155EEF)),
                ),
                label: 'Pickup',
              ),
              NavigationDestination(
                icon: const AppSvgIconWidget(svgData: AppSvgIcons.navSavedHeart, size: 22, color: Color(0xFF64748B)),
                selectedIcon: const AppSvgIconWidget(svgData: AppSvgIcons.navSavedHeart, size: 22, color: Color(0xFF155EEF)),
                label: 'Saved',
              ),
            ],
          ),
        ),
      ),
    );
  }
}
