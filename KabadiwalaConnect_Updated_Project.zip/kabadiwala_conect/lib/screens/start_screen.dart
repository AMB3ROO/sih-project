import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/app_state.dart';
import 'login_screen.dart';
import 'role_home_screen.dart';

class StartScreen extends StatelessWidget {
  const StartScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);

    return Scaffold(
      backgroundColor: const Color(
        0xFF0B1F3A,
      ), // 02 Deep Blue + Sky (Deep Navy)
      body: SafeArea(
        child: Align(
          alignment: Alignment.center,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 600),
            child: LayoutBuilder(
              builder: (context, constraints) {
                return SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 24.0,
                    vertical: 12.0,
                  ),
                  child: ConstrainedBox(
                    constraints: BoxConstraints(
                      minHeight: constraints.maxHeight - 24.0,
                    ),
                    child: IntrinsicHeight(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(height: 12),
                          Container(
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: Colors.white.withValues(alpha: 0.15),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(
                              Icons.recycling_rounded,
                              color: Colors.white,
                              size: 48,
                            ),
                          ),
                          const SizedBox(height: 16),
                          const Text(
                            'Kabadiwala\nConnect',
                            style: TextStyle(
                              fontSize: 32,
                              fontWeight: FontWeight.w900,
                              color: Colors.white,
                              height: 1.1,
                              letterSpacing: -0.5,
                            ),
                          ),
                          const SizedBox(height: 8),
                          const Text(
                            'AI-Powered Circular Scrap Ecosystem for Households, Traders & Industrial Recyclers.',
                            style: TextStyle(
                              fontSize: 13,
                              color: Color(0xFFD9E7FF), // Sky blue accent
                              height: 1.4,
                            ),
                          ),
                          const SizedBox(height: 20),
                          Align(
                            alignment: Alignment.centerRight,
                            child: TextButton.icon(
                              onPressed: () =>
                                  _showAdminPreview(context, appState),
                              icon: const Icon(
                                Icons.admin_panel_settings_outlined,
                                size: 16,
                              ),
                              label: const Text('Admin preview · demo only'),
                              style: TextButton.styleFrom(
                                foregroundColor: const Color(0xFFD9E7FF),
                                textStyle: const TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                          ),
                          const Text(
                            'Select Your Profile Mode:',
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                          const SizedBox(height: 8),
                          _buildRoleCard(
                            context: context,
                            role: UserRole.householdSeller,
                            title: 'Household Seller',
                            subtitle:
                                'Schedule doorstep pickup & get instant UPI payout',
                            icon: Icons.home_rounded,
                            color: const Color(0xFF155EEF),
                            isSelected:
                                appState.currentRole ==
                                UserRole.householdSeller,
                            onTap: () =>
                                appState.setUserRole(UserRole.householdSeller),
                          ),
                          const SizedBox(height: 8),
                          _buildRoleCard(
                            context: context,
                            role: UserRole.kabadiwalaTrader,
                            title: 'Kabadiwala Trader',
                            subtitle:
                                'Scan bulk scrap with AI & list for recycler bids',
                            icon: Icons.local_shipping_rounded,
                            color: const Color(0xFF3B82F6),
                            isSelected:
                                appState.currentRole ==
                                UserRole.kabadiwalaTrader,
                            onTap: () =>
                                appState.setUserRole(UserRole.kabadiwalaTrader),
                          ),
                          const SizedBox(height: 8),
                          _buildRoleCard(
                            context: context,
                            role: UserRole.industrialRecycler,
                            title: 'Industrial Recycler',
                            subtitle:
                                'Source segregated materials & issue digital handovers',
                            icon: Icons.factory_rounded,
                            color: const Color(0xFFA855F7),
                            isSelected:
                                appState.currentRole ==
                                UserRole.industrialRecycler,
                            onTap: () => appState.setUserRole(
                              UserRole.industrialRecycler,
                            ),
                          ),
                          const Spacer(),
                          const SizedBox(height: 16),
                          SizedBox(
                            width: double.infinity,
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(
                                  0xFF155EEF,
                                ), // Deep Blue primary
                                foregroundColor: Colors.white,
                                padding: const EdgeInsets.symmetric(
                                  vertical: 14,
                                ),
                                elevation: 4,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(16),
                                ),
                              ),
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => const LoginScreen(),
                                  ),
                                );
                              },
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: const [
                                  Text(
                                    'Get Started Now',
                                    style: TextStyle(
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  SizedBox(width: 8),
                                  Icon(Icons.arrow_forward_rounded, size: 18),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(height: 6),
                          Center(
                            child: TextButton(
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => const LoginScreen(),
                                  ),
                                );
                              },
                              child: const Text(
                                'Already registered? Login to your account >',
                                style: TextStyle(
                                  color: Color(0xFFD9E7FF),
                                  fontWeight: FontWeight.bold,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ),
      ),
    );
  }

  void _showAdminPreview(BuildContext context, AppState appState) {
    showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Admin preview'),
        content: const Text(
          'This opens a local demo console with sample data. It does not grant or verify real administrator access.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              Navigator.pop(dialogContext);
              appState.login(
                role: UserRole.platformAdmin,
                name: 'Platform operator',
              );
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (_) => const RoleHomeScreen()),
                (route) => false,
              );
            },
            child: const Text('Open preview'),
          ),
        ],
      ),
    );
  }

  Widget _buildRoleCard({
    required BuildContext context,
    required UserRole role,
    required String title,
    required String subtitle,
    required IconData icon,
    required Color color,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: isSelected
              ? Colors.white
              : Colors.white.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected ? color : Colors.white.withValues(alpha: 0.2),
            width: isSelected ? 2 : 1,
          ),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: isSelected
                    ? color.withValues(alpha: 0.15)
                    : Colors.white.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                icon,
                color: isSelected ? color : Colors.white,
                size: 24,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                      color: isSelected
                          ? const Color(0xFF0F172A)
                          : Colors.white,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: TextStyle(
                      fontSize: 11,
                      color: isSelected
                          ? const Color(0xFF64748B)
                          : const Color(0xFFD9E7FF),
                    ),
                  ),
                ],
              ),
            ),
            if (isSelected)
              Icon(Icons.check_circle_rounded, color: color, size: 22)
            else
              const Icon(
                Icons.circle_outlined,
                color: Colors.white38,
                size: 22,
              ),
          ],
        ),
      ),
    );
  }
}
