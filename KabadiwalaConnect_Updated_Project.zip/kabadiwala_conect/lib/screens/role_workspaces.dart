import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/app_state.dart';
import '../services/auth_service.dart';
import 'start_screen.dart';

const _ink = Color(0xFF193A31);
const _paper = Color(0xFFF4F0E6);
const _lime = Color(0xFFD8F06A);
const _clay = Color(0xFFC95738);
const _sage = Color(0xFFDDE5D7);
const _muted = Color(0xFF718079);

class RoleWorkspaceScreen extends StatefulWidget {
  const RoleWorkspaceScreen({super.key, required this.role});
  final UserRole role;

  @override
  State<RoleWorkspaceScreen> createState() => _RoleWorkspaceScreenState();
}

class _RoleWorkspaceScreenState extends State<RoleWorkspaceScreen> {
  int _tab = 0;
  String _filter = 'All';
  final List<_Lot> _lots = [
    _Lot(
      'KC-1048',
      'Mixed e-waste',
      'E-waste',
      18.5,
      46,
      'Indiranagar · 1.2 km',
      'New request',
    ),
    _Lot(
      'KC-1042',
      'Copper wire bundle',
      'Metal',
      12,
      610,
      'Domlur · 2.4 km',
      'Offer received',
    ),
    _Lot(
      'KC-1036',
      'Small appliances',
      'E-waste',
      8,
      72,
      'Ulsoor · 3.1 km',
      'Pickup booked',
    ),
  ];
  final Map<String, String> _facilityStatus = {
    'GreenLoop Recycling': 'Needs review',
    'EcoCircuit Works': 'Needs review',
    'Namma Materials Hub': 'Verified',
  };
  final Map<String, String> _disputeStatus = {
    'Weight mismatch · KC-1011': 'Open',
    'Late pickup · KC-0994': 'Open',
  };
  final Map<String, int> _rates = {
    'E-waste': 46,
    'Copper': 610,
    'Aluminium': 128,
    'Cardboard': 14,
  };

  bool get _isKabadiwala => widget.role == UserRole.kabadiwalaTrader;
  bool get _isRecycler => widget.role == UserRole.industrialRecycler;
  bool get _isAdmin => widget.role == UserRole.platformAdmin;

  String get _title => _isKabadiwala
      ? 'Your rounds'
      : _isRecycler
      ? 'Material desk'
      : 'Network pulse';
  List<String> get _tabs => _isKabadiwala
      ? const ['Today', 'My lots', 'Earnings', 'Safety']
      : _isRecycler
      ? const ['Intake', 'Rates', 'Trace', 'Facility']
      : const ['Overview', 'Facilities', 'Disputes', 'Price board'];

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final name = state.pickupName.isEmpty
        ? (_isKabadiwala
              ? 'Ramesh'
              : _isRecycler
              ? 'GreenLoop'
              : 'Operations')
        : state.pickupName;
    return Scaffold(
      backgroundColor: _paper,
      appBar: AppBar(
        backgroundColor: _paper,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        toolbarHeight: 72,
        titleSpacing: 20,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              _title,
              style: const TextStyle(
                color: _ink,
                fontWeight: FontWeight.w800,
                fontSize: 21,
                letterSpacing: -0.5,
              ),
            ),
            const SizedBox(height: 2),
            Row(
              children: [
                const Icon(Icons.circle, color: Color(0xFF519A68), size: 8),
                const SizedBox(width: 6),
                Text(
                  '$name  ·  Demo workspace',
                  style: const TextStyle(
                    color: _muted,
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Profile and sign out',
            onPressed: _showProfile,
            icon: const Icon(
              Icons.account_circle_outlined,
              color: _ink,
              size: 26,
            ),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: SafeArea(
        top: false,
        child: AnimatedSwitcher(
          duration: const Duration(milliseconds: 180),
          child: _page(key: ValueKey(_tab)),
        ),
      ),
      floatingActionButton: _isKabadiwala && _tab < 2
          ? FloatingActionButton.extended(
              onPressed: _addLot,
              backgroundColor: _lime,
              foregroundColor: _ink,
              icon: const Icon(Icons.add_a_photo_outlined),
              label: const Text(
                'Add a lot',
                style: TextStyle(fontWeight: FontWeight.w800),
              ),
            )
          : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        backgroundColor: const Color(0xFFFFFEFA),
        indicatorColor: _sage,
        height: 72,
        destinations: [
          for (var i = 0; i < _tabs.length; i++)
            NavigationDestination(
              icon: Icon(_iconFor(i)),
              selectedIcon: Icon(_iconFor(i), color: _ink),
              label: _tabs[i],
            ),
        ],
      ),
    );
  }

  IconData _iconFor(int i) {
    if (_isKabadiwala) {
      return [
        Icons.today_outlined,
        Icons.inventory_2_outlined,
        Icons.account_balance_wallet_outlined,
        Icons.health_and_safety_outlined,
      ][i];
    }
    if (_isRecycler) {
      return [
        Icons.move_to_inbox_outlined,
        Icons.price_change_outlined,
        Icons.qr_code_2,
        Icons.factory_outlined,
      ][i];
    }
    return [
      Icons.grid_view_rounded,
      Icons.verified_user_outlined,
      Icons.report_problem_outlined,
      Icons.query_stats_outlined,
    ][i];
  }

  Widget _page({required Key key}) {
    if (_isKabadiwala) return _kabadiwalaPage(key);
    if (_isRecycler) return _recyclerPage(key);
    return _adminPage(key);
  }

  Widget _kabadiwalaPage(Key key) {
    switch (_tab) {
      case 0:
        return ListView(
          key: key,
          padding: const EdgeInsets.fromLTRB(18, 8, 18, 100),
          children: [
            _hero(
              '₹ 2,840',
              'earned this week',
              Icons.south_west_rounded,
              '+12% from last week',
              _ink,
              _lime,
            ),
            const SizedBox(height: 18),
            Row(
              children: [
                Expanded(
                  child: _quickStat(
                    'ACTIVE LOTS',
                    '${_lots.length}',
                    Icons.inventory_2_outlined,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _quickStat(
                    'OFFERS WAITING',
                    '${_lots.where((l) => l.status == 'Offer received').length + 2}',
                    Icons.mark_chat_unread_outlined,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            _sectionTitle(
              'Nearby offers',
              'Best matched for your rounds',
              trailing: TextButton(
                onPressed: () => setState(() => _tab = 1),
                child: const Text('All lots'),
              ),
            ),
            const SizedBox(height: 8),
            _offerCard(
              'Copper wire bundle',
              'EcoCircuit Works · verified',
              '12 kg',
              '₹ 7,320',
              '2.4 km',
              onTap: () => _showLotDetail(_lots[1]),
              action: 'Review offer',
            ),
            _offerCard(
              'Mixed e-waste',
              'GreenLoop Recycling · verified',
              '18.5 kg',
              '₹ 851 est.',
              '1.2 km',
              onTap: () => _showLotDetail(_lots[0]),
              action: 'View request',
            ),
            const SizedBox(height: 14),
            _offlineStrip(),
          ],
        );
      case 1:
        return ListView(
          key: key,
          padding: const EdgeInsets.fromLTRB(18, 8, 18, 100),
          children: [
            _pageIntro(
              'Lots in motion',
              'Track every bundle from estimate to handover.',
            ),
            Wrap(
              spacing: 8,
              children: ['All', 'E-waste', 'Metal', 'Plastic']
                  .map(
                    (f) => ChoiceChip(
                      label: Text(f),
                      selected: _filter == f,
                      onSelected: (_) => setState(() => _filter = f),
                      selectedColor: _lime,
                      side: BorderSide.none,
                    ),
                  )
                  .toList(),
            ),
            const SizedBox(height: 12),
            ..._lots
                .where((l) => _filter == 'All' || l.category == _filter)
                .map((lot) => _lotTile(lot, onTap: () => _showLotDetail(lot))),
            if (_lots.isEmpty)
              _emptyState(
                'No lots yet',
                'Start with a photo and an approximate weight.',
              ),
          ],
        );
      case 2:
        return ListView(
          key: key,
          padding: const EdgeInsets.all(18),
          children: [
            _hero(
              '₹ 8,460',
              'total earned · September',
              Icons.account_balance_wallet_outlined,
              'Cash-first · no payout setup needed',
              _ink,
              _lime,
            ),
            const SizedBox(height: 22),
            _sectionTitle('Recent handovers', 'Your earnings ledger'),
            const SizedBox(height: 8),
            _ledgerRow(
              'Copper wire · 12 kg',
              'Today · Cash paid',
              '+ ₹ 7,320',
              true,
            ),
            _ledgerRow(
              'Small appliances · 8 kg',
              '22 Sep · UPI pending',
              '+ ₹ 576',
              false,
            ),
            _ledgerRow(
              'Cardboard · 40 kg',
              '19 Sep · Cash paid',
              '+ ₹ 560',
              true,
            ),
            const SizedBox(height: 18),
            _softNotice(
              'Offline-ready',
              'Your last synced prices and ledger stay available without a connection.',
            ),
          ],
        );
      default:
        return ListView(
          key: key,
          padding: const EdgeInsets.all(18),
          children: [
            _pageIntro(
              'Handle it safely',
              'Small steps protect you and your neighbourhood.',
            ),
            _safetyTile(
              Icons.local_fire_department_outlined,
              'Never burn cables',
              'Burning wire releases toxic smoke. Keep it whole and dry.',
              _clay,
            ),
            _safetyTile(
              Icons.battery_alert_outlined,
              'Keep batteries separate',
              'Do not crush or puncture cells. Cover exposed terminals.',
              const Color(0xFFB57B16),
            ),
            _safetyTile(
              Icons.science_outlined,
              'No acid on circuit boards',
              'Use an authorized facility for safe material recovery.',
              _ink,
            ),
            _safetyTile(
              Icons.hearing_outlined,
              'Listen to the guide',
              'Audio guidance can be added when Hindi / Marathi voice assets are ready.',
              const Color(0xFF617B5C),
            ),
          ],
        );
    }
  }

  Widget _recyclerPage(Key key) {
    switch (_tab) {
      case 0:
        final intakes = _lots.where((l) => l.status != 'Verified').toList();
        return ListView(
          key: key,
          padding: const EdgeInsets.fromLTRB(18, 8, 18, 24),
          children: [
            _hero(
              '06',
              'lots awaiting intake',
              Icons.move_to_inbox_outlined,
              '2 pickups scheduled today',
              _ink,
              _lime,
            ),
            const SizedBox(height: 20),
            _sectionTitle(
              'Incoming material',
              'Review, schedule, then verify weight',
            ),
            const SizedBox(height: 8),
            if (intakes.isEmpty)
              _emptyState(
                'Intake cleared',
                'New collector lots will appear here.',
              ),
            ...intakes.map((lot) => _intakeCard(lot)),
            const SizedBox(height: 12),
            _offlineStrip(),
          ],
        );
      case 1:
        return ListView(
          key: key,
          padding: const EdgeInsets.all(18),
          children: [
            _pageIntro(
              'Buying rates',
              'Rates shown to nearby collectors · per kg',
            ),
            ..._rates.entries.map((entry) => _rateTile(entry.key, entry.value)),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: _editRates,
              icon: const Icon(Icons.tune),
              label: const Text('Update all rates'),
              style: FilledButton.styleFrom(
                backgroundColor: _ink,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.all(16),
              ),
            ),
            const SizedBox(height: 12),
            _softNotice(
              'Last published · 2 hours ago',
              'Offline users see the latest saved rate until they reconnect.',
            ),
          ],
        );
      case 2:
        return ListView(
          key: key,
          padding: const EdgeInsets.all(18),
          children: [
            _pageIntro(
              'Traceability',
              'Confirmed receipts close the chain of custody.',
            ),
            ..._lots.map((lot) => _traceRow(lot)),
            _softNotice(
              'Handover reference',
              'Receipt IDs are generated locally in this demo. Connect the secured backend before recording regulated transfers.',
            ),
          ],
        );
      default:
        return ListView(
          key: key,
          padding: const EdgeInsets.all(18),
          children: [
            _pageIntro(
              'Facility profile',
              'Keep your authorization details up to date.',
            ),
            _profileRow(
              Icons.verified_outlined,
              'Authorization status',
              'Verification required',
              _clay,
            ),
            _profileRow(
              Icons.tag_outlined,
              'Authorization number',
              'Add facility ID',
              _muted,
            ),
            _profileRow(
              Icons.category_outlined,
              'Accepted materials',
              'E-waste · Copper · Aluminium',
              _ink,
            ),
            _profileRow(
              Icons.location_on_outlined,
              'Collection zone',
              'Bengaluru · 25 km radius',
              _ink,
            ),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: _editFacility,
              icon: const Icon(Icons.edit_outlined),
              label: const Text('Edit facility details'),
            ),
            _softNotice(
              'Demo data',
              'Facility changes stay in this preview and are not submitted to a regulator.',
            ),
          ],
        );
    }
  }

  Widget _adminPage(Key key) {
    switch (_tab) {
      case 0:
        return ListView(
          key: key,
          padding: const EdgeInsets.fromLTRB(18, 8, 18, 24),
          children: [
            _hero(
              '1,284',
              'people in the network',
              Icons.hub_outlined,
              '37 handovers confirmed today',
              _ink,
              _lime,
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: _quickStat(
                    'NEEDS REVIEW',
                    '${_facilityStatus.values.where((s) => s == 'Needs review').length}',
                    Icons.fact_check_outlined,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _quickStat(
                    'OPEN CASES',
                    '${_disputeStatus.values.where((s) => s == 'Open').length}',
                    Icons.report_problem_outlined,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 22),
            _sectionTitle('Priority queue', 'Tap an item to take action'),
            const SizedBox(height: 8),
            _queueCard(
              Icons.verified_user_outlined,
              'Recycler verification',
              '${_facilityStatus.values.where((s) => s == 'Needs review').length} facilities need a decision',
              _clay,
              () => setState(() => _tab = 1),
            ),
            _queueCard(
              Icons.report_problem_outlined,
              'Dispute resolution',
              '${_disputeStatus.values.where((s) => s == 'Open').length} cases are still open',
              const Color(0xFFB57B16),
              () => setState(() => _tab = 2),
            ),
            _queueCard(
              Icons.price_change_outlined,
              'Stale material prices',
              '4 district price boards need a check',
              const Color(0xFF597B48),
              () => setState(() => _tab = 3),
            ),
            const SizedBox(height: 12),
            _softNotice(
              'EPR oversight',
              'Only verified recyclers should receive regulated e-waste lots.',
            ),
          ],
        );
      case 1:
        return ListView(
          key: key,
          padding: const EdgeInsets.all(18),
          children: [
            _pageIntro(
              'Recycler verification',
              'Check credentials before showing a buyer as authorized.',
            ),
            ..._facilityStatus.entries.map(
              (entry) => _reviewRow(
                Icons.factory_outlined,
                entry.key,
                'Authorization documents · Bengaluru',
                entry.value,
                () => _reviewFacility(entry.key),
              ),
            ),
          ],
        );
      case 2:
        return ListView(
          key: key,
          padding: const EdgeInsets.all(18),
          children: [
            _pageIntro('Disputes', 'Keep a clear record of the resolution.'),
            ..._disputeStatus.entries.map(
              (entry) => _reviewRow(
                Icons.report_gmailerrorred_outlined,
                entry.key,
                'Collector and recycler reports differ',
                entry.value,
                () => _reviewDispute(entry.key),
              ),
            ),
            if (_disputeStatus.isEmpty)
              _emptyState(
                'No open disputes',
                'New cases will appear in this queue.',
              ),
          ],
        );
      default:
        return ListView(
          key: key,
          padding: const EdgeInsets.all(18),
          children: [
            _pageIntro('Price board', 'District reference rates · INR per kg'),
            ..._rates.entries.map((entry) => _rateTile(entry.key, entry.value)),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: _editRates,
              icon: const Icon(Icons.publish_outlined),
              label: const Text('Review & publish rates'),
              style: FilledButton.styleFrom(
                backgroundColor: _ink,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.all(16),
              ),
            ),
            _softNotice(
              'Rate changes',
              'Publishing here updates only the demo view. Production rates need server-side review history.',
            ),
          ],
        );
    }
  }

  Widget _hero(
    String value,
    String label,
    IconData icon,
    String note,
    Color bg,
    Color accent,
  ) => Container(
    padding: const EdgeInsets.all(20),
    decoration: BoxDecoration(
      color: bg,
      borderRadius: BorderRadius.circular(24),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(icon, color: accent),
            const Spacer(),
            const _LiveTag(),
          ],
        ),
        const SizedBox(height: 18),
        Text(
          value,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 34,
            fontWeight: FontWeight.w900,
            letterSpacing: -1.2,
            height: 1,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          label,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 15,
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 14),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: .10),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Text(
            note,
            style: TextStyle(
              color: accent,
              fontSize: 11,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      ],
    ),
  );

  Widget _quickStat(String label, String value, IconData icon) => Container(
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: const Color(0xFFFFFEFA),
      borderRadius: BorderRadius.circular(18),
      border: Border.all(color: const Color(0xFFE4E2D8)),
    ),
    child: Row(
      children: [
        Icon(icon, size: 19, color: _ink),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                value,
                style: const TextStyle(
                  color: _ink,
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                ),
              ),
              Text(
                label,
                style: const TextStyle(
                  color: _muted,
                  fontSize: 9,
                  fontWeight: FontWeight.w800,
                  letterSpacing: .5,
                ),
              ),
            ],
          ),
        ),
      ],
    ),
  );

  Widget _sectionTitle(String title, String subtitle, {Widget? trailing}) =>
      Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: _ink,
                    fontSize: 19,
                    fontWeight: FontWeight.w900,
                    letterSpacing: -.4,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  subtitle,
                  style: const TextStyle(color: _muted, fontSize: 12),
                ),
              ],
            ),
          ),
          if (trailing != null) trailing,
        ],
      );
  Widget _pageIntro(String title, String subtitle) => Padding(
    padding: const EdgeInsets.only(bottom: 18),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            color: _ink,
            fontSize: 26,
            fontWeight: FontWeight.w900,
            letterSpacing: -.7,
          ),
        ),
        const SizedBox(height: 5),
        Text(subtitle, style: const TextStyle(color: _muted, fontSize: 13)),
      ],
    ),
  );

  Widget _offerCard(
    String title,
    String buyer,
    String weight,
    String price,
    String distance, {
    required VoidCallback onTap,
    required String action,
  }) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(18),
    child: Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: const Color(0xFFFFFEFA),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFE5E2D7)),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: _sage,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Icon(Icons.recycling_outlined, color: _ink),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        color: _ink,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    Text(
                      buyer,
                      style: const TextStyle(color: _muted, fontSize: 11),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.arrow_outward_rounded, color: _muted, size: 18),
            ],
          ),
          const Divider(height: 22),
          Row(
            children: [
              Text(
                '$weight  ·  $distance',
                style: const TextStyle(color: _muted, fontSize: 11),
              ),
              const Spacer(),
              Text(
                price,
                style: const TextStyle(
                  color: _ink,
                  fontWeight: FontWeight.w900,
                  fontSize: 17,
                ),
              ),
              const SizedBox(width: 8),
              Text(
                action,
                style: const TextStyle(
                  color: _clay,
                  fontSize: 10,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
        ],
      ),
    ),
  );

  Widget _lotTile(_Lot lot, {required VoidCallback onTap}) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(16),
    child: Container(
      margin: const EdgeInsets.only(bottom: 9),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFFFFEFA),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: _sage,
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(Icons.inventory_2_outlined, color: _ink),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  lot.name,
                  style: const TextStyle(
                    color: _ink,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                Text(
                  '${lot.code} · ${lot.weight.toStringAsFixed(1)} kg',
                  style: const TextStyle(color: _muted, fontSize: 11),
                ),
              ],
            ),
          ),
          _statusPill(lot.status),
        ],
      ),
    ),
  );

  Widget _intakeCard(_Lot lot) => Container(
    margin: const EdgeInsets.only(bottom: 12),
    padding: const EdgeInsets.all(15),
    decoration: BoxDecoration(
      color: const Color(0xFFFFFEFA),
      borderRadius: BorderRadius.circular(19),
      border: Border.all(color: const Color(0xFFE4E2D8)),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            _statusPill(lot.status),
            const Spacer(),
            Text(
              lot.code,
              style: const TextStyle(
                color: _muted,
                fontSize: 11,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Text(
          lot.name,
          style: const TextStyle(
            color: _ink,
            fontSize: 17,
            fontWeight: FontWeight.w900,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          '${lot.weight.toStringAsFixed(1)} kg estimated · ${lot.place}',
          style: const TextStyle(color: _muted, fontSize: 12),
        ),
        const SizedBox(height: 14),
        Row(
          children: [
            Expanded(
              child: OutlinedButton(
                onPressed: () => _showLotDetail(lot),
                child: const Text('Review lot'),
              ),
            ),
            const SizedBox(width: 9),
            Expanded(
              child: FilledButton(
                onPressed: () => _showLotDetail(lot),
                style: FilledButton.styleFrom(
                  backgroundColor: _ink,
                  foregroundColor: Colors.white,
                ),
                child: Text(
                  lot.status == 'Pickup booked'
                      ? 'Confirm receipt'
                      : 'Schedule pickup',
                ),
              ),
            ),
          ],
        ),
      ],
    ),
  );

  Widget _traceRow(_Lot lot) => InkWell(
    onTap: () => _showLotDetail(lot),
    child: Container(
      margin: const EdgeInsets.only(bottom: 9),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFFFFEFA),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          const Icon(Icons.qr_code_2, color: _ink, size: 29),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'HANDOVER · ${lot.code}',
                  style: const TextStyle(
                    color: _ink,
                    fontWeight: FontWeight.w800,
                    fontSize: 12,
                  ),
                ),
                Text(
                  '${lot.name} · ${lot.weight.toStringAsFixed(1)} kg',
                  style: const TextStyle(color: _muted, fontSize: 11),
                ),
              ],
            ),
          ),
          _statusPill(lot.status),
        ],
      ),
    ),
  );

  Widget _rateTile(String material, int rate) => Container(
    margin: const EdgeInsets.only(bottom: 8),
    padding: const EdgeInsets.all(15),
    decoration: BoxDecoration(
      color: const Color(0xFFFFFEFA),
      borderRadius: BorderRadius.circular(16),
    ),
    child: Row(
      children: [
        Container(
          width: 38,
          height: 38,
          decoration: BoxDecoration(
            color: _sage,
            borderRadius: BorderRadius.circular(11),
          ),
          child: const Icon(Icons.recycling, color: _ink, size: 20),
        ),
        const SizedBox(width: 11),
        Expanded(
          child: Text(
            material,
            style: const TextStyle(color: _ink, fontWeight: FontWeight.w800),
          ),
        ),
        Text(
          '₹$rate',
          style: const TextStyle(
            color: _ink,
            fontSize: 19,
            fontWeight: FontWeight.w900,
          ),
        ),
        const Text(' / kg', style: TextStyle(color: _muted, fontSize: 11)),
      ],
    ),
  );

  Widget _queueCard(
    IconData icon,
    String title,
    String detail,
    Color tone,
    VoidCallback onTap,
  ) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(17),
    child: Container(
      margin: const EdgeInsets.only(bottom: 9),
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: const Color(0xFFFFFEFA),
        borderRadius: BorderRadius.circular(17),
      ),
      child: Row(
        children: [
          CircleAvatar(
            backgroundColor: tone.withValues(alpha: .12),
            child: Icon(icon, color: tone),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: _ink,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                Text(
                  detail,
                  style: const TextStyle(color: _muted, fontSize: 11),
                ),
              ],
            ),
          ),
          const Icon(Icons.chevron_right, color: _muted),
        ],
      ),
    ),
  );

  Widget _reviewRow(
    IconData icon,
    String title,
    String detail,
    String status,
    VoidCallback onTap,
  ) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(17),
    child: Container(
      margin: const EdgeInsets.only(bottom: 9),
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: const Color(0xFFFFFEFA),
        borderRadius: BorderRadius.circular(17),
      ),
      child: Row(
        children: [
          Icon(icon, color: _ink),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: _ink,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                Text(
                  detail,
                  style: const TextStyle(color: _muted, fontSize: 11),
                ),
              ],
            ),
          ),
          _statusPill(status),
        ],
      ),
    ),
  );

  Widget _statusPill(String status) {
    final good = status == 'Verified' || status == 'Confirmed';
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
      decoration: BoxDecoration(
        color: good ? const Color(0xFFE2EBD8) : const Color(0xFFFFE9D8),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        status,
        style: TextStyle(
          color: good ? _ink : const Color(0xFF92502D),
          fontSize: 10,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }

  Widget _ledgerRow(String title, String detail, String amount, bool paid) =>
      Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: const Color(0xFFFFFEFA),
          borderRadius: BorderRadius.circular(15),
        ),
        child: Row(
          children: [
            Icon(
              paid ? Icons.payments_outlined : Icons.hourglass_bottom_rounded,
              color: paid ? _ink : _clay,
            ),
            const SizedBox(width: 11),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: _ink,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  Text(
                    detail,
                    style: const TextStyle(color: _muted, fontSize: 11),
                  ),
                ],
              ),
            ),
            Text(
              amount,
              style: const TextStyle(color: _ink, fontWeight: FontWeight.w900),
            ),
          ],
        ),
      );
  Widget _safetyTile(IconData icon, String title, String text, Color color) =>
      Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          color: const Color(0xFFFFFEFA),
          borderRadius: BorderRadius.circular(17),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CircleAvatar(
              backgroundColor: color.withValues(alpha: .12),
              child: Icon(icon, color: color),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: _ink,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    text,
                    style: const TextStyle(
                      color: _muted,
                      fontSize: 12,
                      height: 1.35,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
  Widget _profileRow(IconData icon, String title, String value, Color color) =>
      Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          color: const Color(0xFFFFFEFA),
          borderRadius: BorderRadius.circular(15),
        ),
        child: Row(
          children: [
            Icon(icon, color: color),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(color: _muted, fontSize: 11),
                  ),
                  Text(
                    value,
                    style: const TextStyle(
                      color: _ink,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
  Widget _offlineStrip() => Container(
    padding: const EdgeInsets.all(13),
    decoration: BoxDecoration(
      color: _sage,
      borderRadius: BorderRadius.circular(14),
    ),
    child: const Row(
      children: [
        Icon(Icons.cloud_done_outlined, color: _ink, size: 19),
        SizedBox(width: 9),
        Expanded(
          child: Text(
            'Last synced 8 min ago · Prices available offline',
            style: TextStyle(
              color: _ink,
              fontSize: 11,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      ],
    ),
  );
  Widget _softNotice(String title, String message) => Container(
    margin: const EdgeInsets.only(top: 12),
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: const Color(0xFFE9E7DA),
      borderRadius: BorderRadius.circular(15),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            color: _ink,
            fontWeight: FontWeight.w900,
            fontSize: 12,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          message,
          style: const TextStyle(color: _muted, fontSize: 11, height: 1.4),
        ),
      ],
    ),
  );
  Widget _emptyState(String title, String body) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 42),
    child: Column(
      children: [
        const Icon(Icons.inbox_outlined, size: 42, color: _muted),
        const SizedBox(height: 12),
        Text(
          title,
          style: const TextStyle(color: _ink, fontWeight: FontWeight.w900),
        ),
        const SizedBox(height: 4),
        Text(
          body,
          textAlign: TextAlign.center,
          style: const TextStyle(color: _muted, fontSize: 12),
        ),
      ],
    ),
  );

  void _addLot() async {
    final lot = await showModalBottomSheet<_Lot>(
      context: context,
      isScrollControlled: true,
      backgroundColor: _paper,
      builder: (_) => const _AddLotSheet(),
    );
    if (lot != null && mounted) {
      setState(() {
        _lots.insert(0, lot);
        _tab = 1;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Lot saved to your local queue.')),
      );
    }
  }

  void _showLotDetail(_Lot lot) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: _paper,
      builder: (sheetContext) => Padding(
        padding: EdgeInsets.fromLTRB(
          20,
          18,
          20,
          22 + MediaQuery.of(sheetContext).viewInsets.bottom,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 38,
                height: 4,
                decoration: BoxDecoration(
                  color: const Color(0xFFB8B6AA),
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
            const SizedBox(height: 20),
            Text(
              lot.name,
              style: const TextStyle(
                color: _ink,
                fontSize: 23,
                fontWeight: FontWeight.w900,
              ),
            ),
            Text(
              '${lot.code} · ${lot.place}',
              style: const TextStyle(color: _muted),
            ),
            const SizedBox(height: 16),
            _profileRow(
              Icons.scale_outlined,
              'Estimated weight',
              '${lot.weight.toStringAsFixed(1)} kg',
              _ink,
            ),
            _profileRow(
              Icons.sell_outlined,
              'Indicative value',
              '₹${(lot.weight * lot.rate).round()} · ₹${lot.rate}/kg',
              _ink,
            ),
            _profileRow(
              Icons.info_outline,
              'Current status',
              lot.status,
              _clay,
            ),
            const SizedBox(height: 10),
            if (_isRecycler)
              FilledButton.icon(
                onPressed: () {
                  setState(() {
                    lot.status = lot.status == 'Pickup booked'
                        ? 'Verified'
                        : 'Pickup booked';
                  });
                  Navigator.pop(sheetContext);
                },
                icon: Icon(
                  lot.status == 'Pickup booked'
                      ? Icons.task_alt
                      : Icons.local_shipping_outlined,
                ),
                label: Text(
                  lot.status == 'Pickup booked'
                      ? 'Confirm receipt'
                      : 'Schedule pickup',
                ),
                style: FilledButton.styleFrom(
                  minimumSize: const Size.fromHeight(50),
                  backgroundColor: _ink,
                  foregroundColor: Colors.white,
                ),
              ),
            if (_isKabadiwala)
              FilledButton.icon(
                onPressed: () {
                  setState(() => lot.status = 'Offer received');
                  Navigator.pop(sheetContext);
                },
                icon: const Icon(Icons.handshake_outlined),
                label: const Text('Accept this offer'),
                style: FilledButton.styleFrom(
                  minimumSize: const Size.fromHeight(50),
                  backgroundColor: _ink,
                  foregroundColor: Colors.white,
                ),
              ),
            if (_isAdmin)
              FilledButton.icon(
                onPressed: () {
                  Navigator.pop(sheetContext);
                  _reviewDispute(lot.code);
                },
                icon: const Icon(Icons.fact_check_outlined),
                label: const Text('Review traceability'),
                style: FilledButton.styleFrom(
                  minimumSize: const Size.fromHeight(50),
                  backgroundColor: _ink,
                  foregroundColor: Colors.white,
                ),
              ),
          ],
        ),
      ),
    );
  }

  void _reviewFacility(String name) => _showDecision(
    name,
    'Check authorization ID, service area, and material scope before marking a facility verified.',
    ['Keep pending', 'Mark verified'],
    (choice) => setState(
      () => _facilityStatus[name] = choice == 'Mark verified'
          ? 'Verified'
          : 'Needs review',
    ),
  );
  void _reviewDispute(String name) => _showDecision(
    name,
    'Compare collector and recycler weight notes before closing this case.',
    ['Leave open', 'Resolve case'],
    (choice) {
      if (choice == 'Resolve case') setState(() => _disputeStatus.remove(name));
    },
  );
  void _showDecision(
    String title,
    String text,
    List<String> actions,
    ValueChanged<String> onChoose,
  ) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: _paper,
      builder: (ctx) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(
                color: _ink,
                fontSize: 20,
                fontWeight: FontWeight.w900,
              ),
            ),
            const SizedBox(height: 8),
            Text(text, style: const TextStyle(color: _muted, height: 1.4)),
            const SizedBox(height: 18),
            for (final action in actions)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: () {
                      onChoose(action);
                      Navigator.pop(ctx);
                    },
                    style: FilledButton.styleFrom(
                      backgroundColor:
                          action.contains('Resolve') ||
                              action.contains('verified')
                          ? _ink
                          : const Color(0xFFE1E4D8),
                      foregroundColor:
                          action.contains('Resolve') ||
                              action.contains('verified')
                          ? Colors.white
                          : _ink,
                    ),
                    child: Text(action),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  void _editRates() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: _paper,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, update) => Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Update buying rates',
                style: TextStyle(
                  color: _ink,
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Adjust values locally in this demo price board.',
                style: TextStyle(color: _muted),
              ),
              const SizedBox(height: 12),
              ..._rates.entries.map(
                (e) => Row(
                  children: [
                    Expanded(
                      child: Text(
                        e.key,
                        style: const TextStyle(
                          color: _ink,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                    IconButton(
                      onPressed: () => update(
                        () =>
                            _rates[e.key] = (_rates[e.key]! - 1).clamp(1, 9999),
                      ),
                      icon: const Icon(Icons.remove_circle_outline),
                    ),
                    Text(
                      '₹${_rates[e.key]}',
                      style: const TextStyle(
                        color: _ink,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    IconButton(
                      onPressed: () =>
                          update(() => _rates[e.key] = _rates[e.key]! + 1),
                      icon: const Icon(Icons.add_circle_outline),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: () {
                    setState(() {});
                    Navigator.pop(ctx);
                  },
                  style: FilledButton.styleFrom(backgroundColor: _ink),
                  child: const Text('Save rates'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _editFacility() => showModalBottomSheet<void>(
    context: context,
    backgroundColor: _paper,
    builder: (ctx) => Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Facility details',
            style: TextStyle(
              color: _ink,
              fontSize: 20,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Contact your platform administrator to submit authorization documents. This preview does not upload credentials.',
            style: TextStyle(color: _muted),
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: () => Navigator.pop(ctx),
              style: FilledButton.styleFrom(backgroundColor: _ink),
              child: const Text('Got it'),
            ),
          ),
        ],
      ),
    ),
  );

  void _showProfile() => showModalBottomSheet<void>(
    context: context,
    backgroundColor: _paper,
    builder: (ctx) => Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Demo profile',
            style: TextStyle(
              color: _ink,
              fontSize: 20,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 7),
          Text(widget.role.displayName, style: const TextStyle(color: _muted)),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: () async {
                Navigator.pop(ctx);
                final appState = context.read<AppState>();
                try {
                  await AuthService().signOut();
                } catch (_) {
                  // A local demo may not have an initialized Firebase app.
                }
                if (!mounted) return;
                appState.logout();
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (_) => const StartScreen()),
                  (route) => false,
                );
              },
              icon: const Icon(Icons.logout),
              label: const Text('Sign out'),
            ),
          ),
        ],
      ),
    ),
  );
}

class _AddLotSheet extends StatefulWidget {
  const _AddLotSheet();
  @override
  State<_AddLotSheet> createState() => _AddLotSheetState();
}

class _AddLotSheetState extends State<_AddLotSheet> {
  String _category = 'E-waste';
  final _weight = TextEditingController();
  final _place = TextEditingController(text: 'Indiranagar, Bengaluru');
  final _prices = const {
    'E-waste': 46,
    'Copper': 610,
    'Aluminium': 128,
    'Cardboard': 14,
  };
  @override
  void dispose() {
    _weight.dispose();
    _place.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final kg = double.tryParse(_weight.text) ?? 0;
    return Padding(
      padding: EdgeInsets.fromLTRB(
        20,
        18,
        20,
        22 + MediaQuery.of(context).viewInsets.bottom,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Container(
              width: 38,
              height: 4,
              decoration: BoxDecoration(
                color: const Color(0xFFB8B6AA),
                borderRadius: BorderRadius.circular(8),
              ),
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            'Add a material lot',
            style: TextStyle(
              color: _ink,
              fontSize: 23,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 5),
          const Text(
            'Quick estimate · save offline and sync later',
            style: TextStyle(color: _muted, fontSize: 12),
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            initialValue: _category,
            decoration: const InputDecoration(
              labelText: 'Material',
              filled: true,
              border: OutlineInputBorder(),
            ),
            items: _prices.keys
                .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                .toList(),
            onChanged: (v) => setState(() => _category = v ?? _category),
          ),
          const SizedBox(height: 11),
          TextField(
            controller: _weight,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(
              labelText: 'Approximate weight (kg)',
              suffixText: 'kg',
              filled: true,
              border: OutlineInputBorder(),
            ),
            onChanged: (_) => setState(() {}),
          ),
          const SizedBox(height: 11),
          TextField(
            controller: _place,
            decoration: const InputDecoration(
              labelText: 'General location',
              prefixIcon: Icon(Icons.location_on_outlined),
              filled: true,
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 14),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: _sage,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Text(
              'Estimated value   ₹${(kg * _prices[_category]!).round()}  ·  indicative rate ₹${_prices[_category]}/kg',
              style: const TextStyle(color: _ink, fontWeight: FontWeight.w800),
            ),
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: kg <= 0
                  ? null
                  : () {
                      final now = DateTime.now().millisecondsSinceEpoch;
                      Navigator.pop(
                        context,
                        _Lot(
                          'KC-${now.toString().substring(now.toString().length - 4)}',
                          _category,
                          _category,
                          kg,
                          _prices[_category]!,
                          _place.text.trim().isEmpty
                              ? 'Location not set'
                              : _place.text.trim(),
                          'Saved offline',
                        ),
                      );
                    },
              icon: const Icon(Icons.save_outlined),
              label: const Text('Save lot'),
              style: FilledButton.styleFrom(
                backgroundColor: _ink,
                foregroundColor: Colors.white,
                minimumSize: const Size.fromHeight(50),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Lot {
  _Lot(
    this.code,
    this.name,
    this.category,
    this.weight,
    this.rate,
    this.place,
    this.status,
  );
  final String code;
  final String name;
  final String category;
  final double weight;
  final int rate;
  final String place;
  String status;
}

class _LiveTag extends StatelessWidget {
  const _LiveTag();
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
    decoration: BoxDecoration(
      color: _lime,
      borderRadius: BorderRadius.circular(20),
    ),
    child: const Text(
      'FIELD MODE',
      style: TextStyle(
        color: _ink,
        fontSize: 9,
        fontWeight: FontWeight.w900,
        letterSpacing: .5,
      ),
    ),
  );
}
