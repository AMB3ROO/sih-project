import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../data/scrap_repository.dart';
import '../services/app_state.dart';
import '../widget/category_list_widget.dart';
import '../widget/search_box_widget.dart';
import 'bottom_nav_bar.dart';
import 'product_screen.dart';

class CategoryScreen extends StatelessWidget {
  final VoidCallback? onBackToHome;

  const CategoryScreen({super.key, this.onBackToHome});

  void _navigateToHome(BuildContext context) {
    if (onBackToHome != null) {
      onBackToHome!();
    } else {
      final appState = Provider.of<AppState>(context, listen: false);
      if (!appState.isLoggedIn) {
        appState.login();
      }
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (_) => const BottomNavBar(initialIndex: 0)),
        (route) => false,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);
    final products = ScrapRepository.getProducts(
      categoryType: appState.selectedCategoryType,
      searchQuery: appState.searchQuery,
    );

    final screenWidth = MediaQuery.of(context).size.width;

    // Adaptive grid column count and ratios for Phone, Tablet, Foldable & Web displays
    final crossAxisCount = screenWidth > 1100 ? 4 : (screenWidth > 700 ? 3 : 2);
    final childAspectRatio = screenWidth > 900 ? 0.88 : (screenWidth > 600 ? 0.82 : 0.74);

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
        _navigateToHome(context);
      },
      child: Scaffold(
        backgroundColor: const Color(0xFFF8FAFC),
        appBar: AppBar(
          elevation: 0,
          backgroundColor: Colors.white,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_rounded, color: Color(0xFF0F172A)),
            onPressed: () => _navigateToHome(context),
            tooltip: 'Back to Home Page',
          ),
          title: const Text(
            'Scrap Rates & Categories',
            style: TextStyle(color: Color(0xFF0F172A), fontWeight: FontWeight.bold, fontSize: 18),
          ),
        ),
        body: Align(
          alignment: Alignment.topCenter,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 1100),
            child: Column(
              children: [
                const SearchBoxWidget(),
                const CategoryListWidget(),
                const SizedBox(height: 8),
                Expanded(
                  child: products.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: const [
                              Icon(Icons.search_off_rounded, size: 64, color: Colors.grey),
                              SizedBox(height: 12),
                              Text('No scrap items matched your filter.', style: TextStyle(color: Colors.grey, fontWeight: FontWeight.bold)),
                            ],
                          ),
                        )
                      : GridView.builder(
                          padding: const EdgeInsets.all(16),
                          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: crossAxisCount,
                            childAspectRatio: childAspectRatio,
                            crossAxisSpacing: 12,
                            mainAxisSpacing: 12,
                          ),
                          itemCount: products.length,
                          itemBuilder: (context, index) {
                            final product = products[index];
                            final isFav = appState.isFavorite(product.id);

                            return Card(
                              elevation: 1.5,
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                              color: Colors.white,
                              clipBehavior: Clip.antiAlias,
                              child: InkWell(
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(builder: (_) => ProductScreen(product: product)),
                                  );
                                },
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Stack(
                                      children: [
                                        Image.network(
                                          product.imageUrl,
                                          height: 110,
                                          width: double.infinity,
                                          fit: BoxFit.cover,
                                          errorBuilder: (_, __, ___) => Container(
                                            height: 110,
                                            color: const Color(0xFFE2E8F0),
                                            child: Icon(product.category.icon, size: 40, color: product.category.color),
                                          ),
                                        ),
                                        Positioned(
                                          top: 6,
                                          right: 6,
                                          child: CircleAvatar(
                                            radius: 14,
                                            backgroundColor: Colors.white.withValues(alpha: 0.9),
                                            child: IconButton(
                                              padding: EdgeInsets.zero,
                                              icon: Icon(
                                                isFav ? Icons.favorite_rounded : Icons.favorite_outline_rounded,
                                                color: isFav ? Colors.red : Colors.grey,
                                                size: 16,
                                              ),
                                              onPressed: () => appState.toggleFavorite(product.id),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    Expanded(
                                      child: Padding(
                                        padding: const EdgeInsets.all(10.0),
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  product.title,
                                                  maxLines: 1,
                                                  overflow: TextOverflow.ellipsis,
                                                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                                                ),
                                                const SizedBox(height: 2),
                                                Text(
                                                  '₹${product.pricePerKg.toStringAsFixed(0)} / kg',
                                                  style: const TextStyle(
                                                    color: Color(0xFF0B1F3A),
                                                    fontWeight: FontWeight.bold,
                                                    fontSize: 14,
                                                  ),
                                                ),
                                              ],
                                            ),
                                            SizedBox(
                                              width: double.infinity,
                                              child: OutlinedButton(
                                                style: OutlinedButton.styleFrom(
                                                  padding: const EdgeInsets.symmetric(vertical: 6),
                                                  side: const BorderSide(color: Color(0xFF155EEF)),
                                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                                                ),
                                                onPressed: () {
                                                  appState.addToCart(product);
                                                  ScaffoldMessenger.of(context).showSnackBar(
                                                    SnackBar(
                                                      content: Text('Added ${product.title} to Pickup Request'),
                                                      backgroundColor: const Color(0xFF155EEF),
                                                      duration: const Duration(seconds: 2),
                                                    ),
                                                  );
                                                },
                                                child: const Text('Add to Pickup', style: TextStyle(color: Color(0xFF155EEF), fontSize: 11, fontWeight: FontWeight.bold)),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
