import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../data/scrap_repository.dart';
import '../services/app_state.dart';
import '../widget/app_bar_widget.dart';
import '../widget/search_box_widget.dart';
import '../widget/category_list_widget.dart';
import '../widget/popular_list_widget.dart';
import '../widget/newest_list_widget.dart';
import '../widget/my_drawer_widget.dart';
import '../widget/app_svg_icons.dart';
import '../widget/responsive.dart';
import '../features/customer/create_lot_screen.dart';
import 'ai_scanner_screen.dart';
import 'price_board_screen.dart';
import 'product_screen.dart';
import 'negotiation_chat_screen.dart';

class HomeScreen extends StatefulWidget {
  final bool showDeniedPopup;

  const HomeScreen({super.key, this.showDeniedPopup = false});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    if (widget.showDeniedPopup) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _showAccessDeniedDialog(context);
      });
    }
  }

  void _showAccessDeniedDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: Row(
            children: const [
              Icon(Icons.no_photography_rounded, color: Colors.amber, size: 28),
              SizedBox(width: 8),
              Expanded(
                child: Text(
                  'Camera & Storage Access Denied',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF0F172A)),
                ),
              ),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: const [
              Text(
                'AI Scrap Vision requires camera and photo gallery access to auto-detect scrap materials, measure weights, and calculate real-time payout quotes.',
                style: TextStyle(fontSize: 13, color: Color(0xFF475569), height: 1.4),
              ),
              SizedBox(height: 12),
              Text(
                'You can grant permission anytime by tapping the AI Vision Scanner tab or from your device settings.',
                style: TextStyle(fontSize: 12, color: Color(0xFF64748B), fontStyle: FontStyle.italic),
              ),
            ],
          ),
          actions: [
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF155EEF),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Understood', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);
    final isSearching = appState.searchQuery.trim().isNotEmpty;
    final searchProductResults = ScrapRepository.getProducts(searchQuery: appState.searchQuery);
    final searchListingResults = ScrapRepository.getListings(searchQuery: appState.searchQuery);

    return Scaffold(
      backgroundColor: const Color(0xFFF7FAFF),
      appBar: const AppBarWidget(showLocation: true),
      drawer: const MyDrawerWidget(),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SearchBoxWidget(),
            if (isSearching)
              _buildSearchResultsView(context, appState, searchProductResults, searchListingResults)
            else ...[
              _buildAiScanBanner(context),
              SizedBox(height: Responsive.height(context, 1.5)),
              const CategoryListWidget(),
              SizedBox(height: Responsive.height(context, 1.5)),
              const PopularListWidget(),
              SizedBox(height: Responsive.height(context, 1.5)),
              _buildGreenImpactCard(context, appState),
              SizedBox(height: Responsive.height(context, 1.5)),
              const NewestListWidget(),
              SizedBox(height: Responsive.height(context, 8.0)), // Padding for thumb-zone FAB
            ],
          ],
        ),
      ),
      // Ergonomic Thumb Zone Placement: High-frequency CTA button placed at the bottom right thumb zone
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const CreateLotScreen()),
          );
        },
        backgroundColor: const Color(0xFF155EEF),
        foregroundColor: Colors.white,
        elevation: 6,
        icon: const Icon(Icons.add_circle_outline_rounded),
        label: const Text('Sell Scrap Now', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
    );
  }

  Widget _buildSearchResultsView(
    BuildContext context,
    AppState appState,
    List searchProductResults,
    List searchListingResults,
  ) {
    final totalMatches = searchProductResults.length + searchListingResults.length;

    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: Responsive.width(context, 4),
        vertical: Responsive.height(context, 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Text(
                  'Found $totalMatches Matches for "${appState.searchQuery}"',
                  style: TextStyle(fontSize: Responsive.sp(context, 16), fontWeight: FontWeight.bold, color: const Color(0xFF0B1F3A)),
                ),
              ),
              InkWell(
                onTap: () => appState.setSearchQuery(''),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFEF2F2),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: const Color(0xFFFECACA)),
                  ),
                  child: Text('Clear Search', style: TextStyle(color: const Color(0xFFEF4444), fontSize: Responsive.sp(context, 12), fontWeight: FontWeight.bold)),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),

          if (totalMatches == 0)
            Container(
              padding: const EdgeInsets.all(36),
              alignment: Alignment.center,
              child: Column(
                children: [
                  Icon(Icons.search_off_rounded, size: Responsive.sp(context, 56), color: Colors.grey),
                  const SizedBox(height: 14),
                  Text('No scrap items or marketplace batches found.', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey, fontSize: Responsive.sp(context, 15))),
                  const SizedBox(height: 6),
                  Text('Try searching for "paper", "copper", "bottle", or "cardboard"', style: TextStyle(color: const Color(0xFF94A3B8), fontSize: Responsive.sp(context, 13))),
                ],
              ),
            )
          else ...[
            // Section 1: Available Scrap Catalog Rates
            if (searchProductResults.isNotEmpty) ...[
              Row(
                children: [
                  const AppSvgIconWidget(svgData: AppSvgIcons.paperIcon, size: 20, color: Color(0xFF155EEF)),
                  const SizedBox(width: 6),
                  Text(
                    'Available Scrap Rate Catalog (${searchProductResults.length})',
                    style: TextStyle(fontSize: Responsive.sp(context, 14), fontWeight: FontWeight.bold, color: const Color(0xFF0B1F3A)),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: searchProductResults.length,
                itemBuilder: (context, index) {
                  final product = searchProductResults[index];
                  return Card(
                    margin: const EdgeInsets.only(bottom: 10),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    color: Colors.white,
                    child: ListTile(
                      contentPadding: const EdgeInsets.all(10),
                      leading: ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: Image.network(
                          product.imageUrl,
                          width: Responsive.width(context, 15),
                          height: Responsive.width(context, 15),
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => Container(width: 60, height: 60, color: const Color(0xFFE2E8F0)),
                        ),
                      ),
                      title: Text(product.title, style: TextStyle(fontWeight: FontWeight.bold, fontSize: Responsive.sp(context, 14))),
                      subtitle: Text('₹${product.pricePerKg.toStringAsFixed(0)} / kg • ${product.category.name}', style: TextStyle(color: const Color(0xFF155EEF), fontWeight: FontWeight.bold, fontSize: Responsive.sp(context, 12))),
                      trailing: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF155EEF),
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                        ),
                        onPressed: () {
                          appState.addToCart(product);
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text('Added ${product.title} to Pickup Request!'), backgroundColor: const Color(0xFF155EEF)),
                          );
                        },
                        child: Text('Add to Pickup', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: Responsive.sp(context, 11))),
                      ),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => ProductScreen(product: product)),
                        );
                      },
                    ),
                  );
                },
              ),
              const SizedBox(height: 16),
            ],

            // Section 2: Available Marketplace Requests & Batches
            if (searchListingResults.isNotEmpty) ...[
              Row(
                children: [
                  const AppSvgIconWidget(svgData: AppSvgIcons.cardboardIcon, size: 20, color: Color(0xFF3B82F6)),
                  const SizedBox(width: 6),
                  Text(
                    'Available Marketplace Requests & Batches (${searchListingResults.length})',
                    style: TextStyle(fontSize: Responsive.sp(context, 14), fontWeight: FontWeight.bold, color: const Color(0xFF0B1F3A)),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: searchListingResults.length,
                itemBuilder: (context, index) {
                  final listing = searchListingResults[index];
                  return Card(
                    margin: const EdgeInsets.only(bottom: 12),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    color: Colors.white,
                    child: Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              ClipRRect(
                                borderRadius: BorderRadius.circular(12),
                                child: Image.network(
                                  listing.imageUrl,
                                  width: Responsive.width(context, 16),
                                  height: Responsive.width(context, 16),
                                  fit: BoxFit.cover,
                                  errorBuilder: (_, __, ___) => Container(width: 65, height: 65, color: const Color(0xFFE2E8F0)),
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(listing.title, style: TextStyle(fontWeight: FontWeight.bold, fontSize: Responsive.sp(context, 14))),
                                    const SizedBox(height: 4),
                                    Text(listing.location, style: TextStyle(fontSize: Responsive.sp(context, 12), color: const Color(0xFF64748B))),
                                    const SizedBox(height: 6),
                                    Row(
                                      children: [
                                        Container(
                                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                          decoration: BoxDecoration(color: const Color(0xFFEFF6FF), borderRadius: BorderRadius.circular(6)),
                                          child: Text('Est. ₹${listing.totalEstimatedValue.toStringAsFixed(0)}', style: TextStyle(fontSize: Responsive.sp(context, 11), fontWeight: FontWeight.bold, color: const Color(0xFF1D4ED8))),
                                        ),
                                        const SizedBox(width: 6),
                                        Text('${listing.totalWeightKg.toStringAsFixed(0)} kg', style: TextStyle(fontSize: Responsive.sp(context, 11), fontWeight: FontWeight.bold, color: const Color(0xFF475569))),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          const Divider(height: 16),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text('Seller: ${listing.sellerName}', style: TextStyle(fontSize: Responsive.sp(context, 12), fontWeight: FontWeight.w600, color: const Color(0xFF64748B))),
                              ElevatedButton.icon(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: const Color(0xFF3B82F6),
                                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                                ),
                                onPressed: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(builder: (_) => NegotiationChatScreen(listing: listing)),
                                  );
                                },
                                icon: const Icon(Icons.chat_bubble_outline_rounded, size: 14, color: Colors.white),
                                label: Text('Negotiate / Offer', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: Responsive.sp(context, 11))),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ],
          ],
        ],
      ),
    );
  }

  Widget _buildAiScanBanner(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(
        horizontal: Responsive.width(context, 4),
        vertical: Responsive.height(context, 1),
      ),
      padding: EdgeInsets.all(Responsive.width(context, 4.5)),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF0B1F3A), Color(0xFF155EEF)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: const [
          BoxShadow(
            color: Color(0x33155EEF),
            blurRadius: 12,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    'AI Scrap Vision',
                    style: TextStyle(color: Colors.white, fontSize: Responsive.sp(context, 11), fontWeight: FontWeight.bold),
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Scan Scrap & Get Instant Payout Quote',
                  style: TextStyle(color: Colors.white, fontSize: Responsive.sp(context, 18), fontWeight: FontWeight.bold, height: 1.2),
                ),
                const SizedBox(height: 6),
                Text(
                  'Auto-detect paper, plastics, copper & e-waste purity with camera.',
                  style: TextStyle(color: const Color(0xFFD9E7FF), fontSize: Responsive.sp(context, 12)),
                ),
                const SizedBox(height: 14),
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: const Color(0xFF0B1F3A),
                    elevation: 0,
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const AIScannerScreen()),
                    );
                  },
                  icon: const AppSvgIconWidget(svgData: AppSvgIcons.navAiVision, size: 18, color: Color(0xFF0B1F3A)),
                  label: Text('Open AI Scanner', style: TextStyle(fontWeight: FontWeight.bold, fontSize: Responsive.sp(context, 13))),
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Container(
            padding: EdgeInsets.all(Responsive.width(context, 3.5)),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.15),
              shape: BoxShape.circle,
            ),
            child: const AppSvgIconWidget(svgData: AppSvgIcons.cameraIcon, size: 42, color: Colors.white),
          ),
        ],
      ),
    );
  }

  Widget _buildGreenImpactCard(BuildContext context, AppState appState) {
    return Container(
      margin: EdgeInsets.symmetric(
        horizontal: Responsive.width(context, 4),
        vertical: Responsive.height(context, 1),
      ),
      padding: EdgeInsets.all(Responsive.width(context, 4)),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFE2E8F0)),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0A000000),
            blurRadius: 10,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  const AppSvgIconWidget(svgData: AppSvgIcons.recyclingLogo, size: 20, color: Color(0xFF155EEF)),
                  const SizedBox(width: 8),
                  Text(
                    'Your Green Impact',
                    style: TextStyle(fontSize: Responsive.sp(context, 15), fontWeight: FontWeight.bold, color: const Color(0xFF0B1F3A)),
                  ),
                ],
              ),
              InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const PriceBoardScreen()),
                  );
                },
                child: Text('Price Board >', style: TextStyle(color: const Color(0xFF155EEF), fontWeight: FontWeight.bold, fontSize: Responsive.sp(context, 12))),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              _buildImpactMetricSvg(context, 'CO₂ Reduced', '${appState.totalCo2SavedKg.toStringAsFixed(0)} kg', AppSvgIcons.co2Icon, const Color(0xFF06B6D4)),
              _buildImpactMetricSvg(context, 'Trees Saved', appState.totalTreesSaved.toStringAsFixed(0), AppSvgIcons.treeIcon, const Color(0xFF155EEF)),
              _buildImpactMetricSvg(context, 'Water Saved', '${appState.totalWaterSavedLiters.toStringAsFixed(0)}L', AppSvgIcons.waterIcon, const Color(0xFF3B82F6)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildImpactMetricSvg(BuildContext context, String label, String value, String svgData, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(10),
        margin: const EdgeInsets.symmetric(horizontal: 4),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.08),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          children: [
            AppSvgIconWidget(svgData: svgData, size: 22, color: color),
            const SizedBox(height: 4),
            Text(value, style: TextStyle(fontWeight: FontWeight.bold, fontSize: Responsive.sp(context, 14), color: color)),
            const SizedBox(height: 2),
            Text(label, style: TextStyle(fontSize: Responsive.sp(context, 10), color: const Color(0xFF64748B))),
          ],
        ),
      ),
    );
  }
}
