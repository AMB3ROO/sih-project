import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../entity/scrap_category.dart';
import '../services/app_state.dart';
import 'bottom_nav_bar.dart';
import 'negotiation_chat_screen.dart';

class PriceBoardScreen extends StatefulWidget {
  final VoidCallback? onBackToHome;

  const PriceBoardScreen({super.key, this.onBackToHome});

  @override
  State<PriceBoardScreen> createState() => _PriceBoardScreenState();
}

class _PriceBoardScreenState extends State<PriceBoardScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _navigateToHome(BuildContext context) {
    if (widget.onBackToHome != null) {
      widget.onBackToHome!();
    } else {
      final appState = Provider.of<AppState>(context, listen: false);
      if (!appState.isLoggedIn) {
        appState.login();
      }
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (_) => const BottomNavBar(initialIndex: 0)),
        (route) => false,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);
    final categories = ScrapCategory.allCategories;

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
        _navigateToHome(context);
      },
      child: Scaffold(
        backgroundColor: const Color(0xFFF8FAFC),
        appBar: AppBar(
          elevation: 0,
          backgroundColor: Colors.white,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_rounded, color: Color(0xFF0F172A)),
            onPressed: () => _navigateToHome(context),
            tooltip: 'Back to Home Page',
          ),
          title: const Text('Scrap Price Board & Bids', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: Color(0xFF0F172A))),
          bottom: TabBar(
            controller: _tabController,
            indicatorColor: const Color(0xFF155EEF),
            labelColor: const Color(0xFF155EEF),
            unselectedLabelColor: Colors.grey,
            labelStyle: const TextStyle(fontWeight: FontWeight.bold),
            tabs: const [
              Tab(text: 'Daily Market Rates'),
              Tab(text: 'Recycler Bids'),
            ],
          ),
        ),
        body: TabBarView(
          controller: _tabController,
          children: [
            // Tab 1: Rate Card
            ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: categories.length,
              itemBuilder: (context, index) {
                final cat = categories[index];
                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  color: Colors.white,
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: cat.color.withValues(alpha: 0.12),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Icon(cat.icon, color: cat.color, size: 28),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(cat.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                              const SizedBox(height: 4),
                              Text(cat.description, style: const TextStyle(fontSize: 12, color: Color(0xFF64748B))),
                            ],
                          ),
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text('₹${cat.ratePerKg.toStringAsFixed(0)}/kg', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16, color: Color(0xFF0B1F3A))),
                            const SizedBox(height: 4),
                            Row(
                              children: const [
                                Icon(Icons.trending_up_rounded, color: Color(0xFF155EEF), size: 14),
                                SizedBox(width: 2),
                                Text('+2.4%', style: TextStyle(color: Color(0xFF155EEF), fontSize: 11, fontWeight: FontWeight.bold)),
                              ],
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),

            // Tab 2: Recycler Offers
            ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: appState.offers.length,
              itemBuilder: (context, index) {
                final offer = appState.offers[index];

                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  color: Colors.white,
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(offer.buyerName, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: const Color(0xFFEFF6FF),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text(offer.status, style: const TextStyle(color: Color(0xFF1D4ED8), fontWeight: FontWeight.bold, fontSize: 11)),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Text('Offered Amount: ₹${offer.offeredAmount.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18, color: Color(0xFF0B1F3A))),
                        const SizedBox(height: 4),
                        Text('Note: ${offer.note}', style: const TextStyle(color: Color(0xFF64748B), fontSize: 13)),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            Expanded(
                              child: OutlinedButton(
                                onPressed: () {
                                  final listing = appState.listings.firstWhere((l) => l.id == offer.listingId, orElse: () => appState.listings.first);
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(builder: (_) => NegotiationChatScreen(listing: listing)),
                                  );
                                },
                                child: const Text('Counter / Chat', style: TextStyle(fontWeight: FontWeight.bold)),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: ElevatedButton(
                                style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF155EEF)),
                                onPressed: () {
                                  appState.acceptOffer(offer);
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(content: Text('Offer accepted from ${offer.buyerName}!')),
                                  );
                                },
                                child: const Text('Accept Bid', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
