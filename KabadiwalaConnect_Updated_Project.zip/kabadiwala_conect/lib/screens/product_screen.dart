import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../entity/scrap_product.dart';
import '../services/app_state.dart';

class ProductScreen extends StatefulWidget {
  final ScrapProduct product;

  const ProductScreen({super.key, required this.product});

  @override
  State<ProductScreen> createState() => _ProductScreenState();
}

class _ProductScreenState extends State<ProductScreen> {
  late double _selectedWeightKg;

  @override
  void initState() {
    super.initState();
    _selectedWeightKg = widget.product.defaultWeightKg;
  }

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);
    final product = widget.product;
    final isFav = appState.isFavorite(product.id);
    final estimatedPayout = product.pricePerKg * _selectedWeightKg;
    final co2Saved = _selectedWeightKg * product.category.co2Factor;

    final screenHeight = MediaQuery.of(context).size.height;
    final imageHeight = (screenHeight * 0.28).clamp(180.0, 320.0);

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        title: Text(product.title, style: const TextStyle(color: Color(0xFF0F172A), fontWeight: FontWeight.bold, fontSize: 16)),
        actions: [
          IconButton(
            icon: Icon(
              isFav ? Icons.favorite_rounded : Icons.favorite_outline_rounded,
              color: isFav ? Colors.red : Colors.grey,
            ),
            onPressed: () => appState.toggleFavorite(product.id),
          ),
        ],
      ),
      body: Align(
        alignment: Alignment.topCenter,
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 800),
          child: Column(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(20),
                        child: Image.network(
                          product.imageUrl,
                          height: imageHeight,
                          width: double.infinity,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => Container(
                            height: imageHeight,
                            color: const Color(0xFFE2E8F0),
                            child: Icon(product.category.icon, size: 64, color: product.category.color),
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: product.category.color.withValues(alpha: 0.15),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Row(
                              children: [
                                Icon(product.category.icon, color: product.category.color, size: 16),
                                const SizedBox(width: 6),
                                Text(
                                  product.category.name,
                                  style: TextStyle(color: product.category.color, fontWeight: FontWeight.bold, fontSize: 12),
                                ),
                              ],
                            ),
                          ),
                          Text(
                            '₹${product.pricePerKg.toStringAsFixed(0)} / kg',
                            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: Color(0xFF0B1F3A)),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Text(
                        product.description,
                        style: const TextStyle(color: Color(0xFF475569), fontSize: 14, height: 1.5),
                      ),
                      const SizedBox(height: 20),
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF8FAFC),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: const Color(0xFFE2E8F0)),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                const Text('Estimated Weight:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                                Text(
                                  '${_selectedWeightKg.toStringAsFixed(0)} kg',
                                  style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18, color: Color(0xFF155EEF)),
                                ),
                              ],
                            ),
                            Slider(
                              value: _selectedWeightKg,
                              min: 2,
                              max: 100,
                              divisions: 49,
                              activeColor: const Color(0xFF155EEF),
                              label: '${_selectedWeightKg.toStringAsFixed(0)} kg',
                              onChanged: (val) {
                                setState(() {
                                  _selectedWeightKg = val;
                                });
                              },
                            ),
                            const SizedBox(height: 8),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                const Text('Estimated Payout:', style: TextStyle(fontWeight: FontWeight.w600, color: Color(0xFF64748B))),
                                Text(
                                  '₹${estimatedPayout.toStringAsFixed(0)}',
                                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Color(0xFF1D4ED8)),
                                ),
                              ],
                            ),
                            const Divider(height: 16),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                const Text('Est. CO₂ Carbon Offset:', style: TextStyle(fontWeight: FontWeight.w600, color: Color(0xFF64748B))),
                                Text(
                                  '${co2Saved.toStringAsFixed(1)} kg CO₂',
                                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: Color(0xFF06B6D4)),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: const BoxDecoration(
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(color: Color(0x14000000), blurRadius: 10, offset: Offset(0, -4)),
                  ],
                ),
                child: SafeArea(
                  top: false,
                  child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF155EEF),
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                      onPressed: () {
                        appState.addToCart(product, customWeight: _selectedWeightKg);
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text('Added ${_selectedWeightKg.toStringAsFixed(0)}kg of ${product.title} to Pickup Request'),
                            backgroundColor: const Color(0xFF155EEF),
                          ),
                        );
                        Navigator.pop(context);
                      },
                      icon: const Icon(Icons.add_shopping_cart_rounded, color: Colors.white),
                      label: const Text('Add to Doorstep Pickup Cart', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
