import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/app_state.dart';
import 'bottom_nav_bar.dart';
import 'role_workspaces.dart';

/// Sends each signed-in profile to the workspace designed for its role.
class RoleHomeScreen extends StatelessWidget {
  const RoleHomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final role = context.watch<AppState>().currentRole;
    if (role == UserRole.householdSeller) return const BottomNavBar();
    return RoleWorkspaceScreen(role: role);
  }
}
