import 'package:flutter/material.dart';

class DigitalHandoverScreen extends StatelessWidget {
  const DigitalHandoverScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text('Digital Handover QR', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18)),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(24),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.qr_code_2_rounded, size: 160, color: Color(0xFF0F172A)),
                const SizedBox(height: 16),
                const Text('Handover Token: KC-HO-89102', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Color(0xFF0B1F3A))),
                const SizedBox(height: 8),
                const Text('Scan this QR code at Recycler Factory Weighbridge to confirm weight & release instant UPI payout.', textAlign: TextAlign.center, style: TextStyle(color: Color(0xFF64748B), fontSize: 13)),
                const SizedBox(height: 20),
                const Divider(),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: const [
                    Text('Verified Weight:', style: TextStyle(color: Colors.grey)),
                    Text('75.0 kg', style: TextStyle(fontWeight: FontWeight.bold)),
                  ],
                ),
                const SizedBox(height: 6),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: const [
                    Text('Approved Payout:', style: TextStyle(color: Colors.grey)),
                    Text('₹1,220.00', style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF0B1F3A))),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
