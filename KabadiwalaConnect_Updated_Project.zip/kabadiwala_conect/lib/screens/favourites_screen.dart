import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../data/scrap_repository.dart';
import '../services/app_state.dart';
import '../widget/empty_cart_widget.dart';
import 'product_screen.dart';

class FavouritesScreen extends StatelessWidget {
  const FavouritesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);
    final allProducts = ScrapRepository.getProducts();
    final favProducts = allProducts.where((p) => appState.isFavorite(p.id)).toList();

    if (favProducts.isEmpty) {
      return Scaffold(
        backgroundColor: const Color(0xFFF8FAFC),
        appBar: AppBar(
          elevation: 0,
          backgroundColor: Colors.white,
          title: const Text('Saved Scrap Items', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: Color(0xFF0F172A))),
        ),
        body: EmptyCartWidget(
          title: 'No Bookmarked Scrap Items',
          description: 'Save high-payout scrap materials to track price spikes and quickly add to doorstep pickup.',
          buttonText: 'Browse Scrap Rates',
          icon: Icons.favorite_outline_rounded,
          onActionPressed: () {},
        ),
      );
    }

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        title: Text('Saved Scrap Items (${favProducts.length})', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: Color(0xFF0F172A))),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: favProducts.length,
        itemBuilder: (context, index) {
          final product = favProducts[index];

          return Card(
            margin: const EdgeInsets.only(bottom: 12),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            color: Colors.white,
            child: ListTile(
              contentPadding: const EdgeInsets.all(8),
              leading: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.network(
                  product.imageUrl,
                  width: 60,
                  height: 60,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(width: 60, height: 60, color: const Color(0xFFE2E8F0)),
                ),
              ),
              title: Text(product.title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
              subtitle: Text('₹${product.pricePerKg.toStringAsFixed(0)} / kg • ${product.category.name}', style: const TextStyle(color: Color(0xFF0B1F3A), fontWeight: FontWeight.bold, fontSize: 12)),
              trailing: IconButton(
                icon: const Icon(Icons.favorite_rounded, color: Colors.red),
                onPressed: () => appState.toggleFavorite(product.id),
              ),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => ProductScreen(product: product)),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
