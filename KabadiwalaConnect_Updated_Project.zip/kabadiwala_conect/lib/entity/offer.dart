class Offer {
  final String id;
  final String listingId;
  final String buyerName;
  final double offeredAmount;
  final String note;
  final DateTime timestamp;
  String status; // 'Pending', 'Accepted', 'Countered', 'Rejected'

  Offer({
    required this.id,
    required this.listingId,
    required this.buyerName,
    required this.offeredAmount,
    required this.note,
    required this.timestamp,
    this.status = 'Pending',
  });
}

class ChatMessage {
  final String id;
  final String senderName;
  final String text;
  final bool isMe;
  final DateTime timestamp;

  ChatMessage({
    required this.id,
    required this.senderName,
    required this.text,
    required this.isMe,
    required this.timestamp,
  });
}
