class LedgerTransaction {
  final String id;
  final String title;
  final String categoryName;
  final double amount;
  final bool isCredit;
  final DateTime date;
  final String status;
  final String referenceNumber;

  LedgerTransaction({
    required this.id,
    required this.title,
    required this.categoryName,
    required this.amount,
    required this.isCredit,
    required this.date,
    required this.status,
    required this.referenceNumber,
  });
}
