import 'package:flutter/material.dart';

enum ScrapCategoryType {
  paper,
  plastic,
  metal,
  eWaste,
  glass,
  cardboard,
  mixed,
}

class ScrapCategory {
  final ScrapCategoryType type;
  final String id;
  final String name;
  final IconData icon;
  final Color color;
  final double ratePerKg;
  final double co2Factor; // kg CO2 saved per kg recycled
  final String description;

  const ScrapCategory({
    required this.type,
    required this.id,
    required this.name,
    required this.icon,
    required this.color,
    required this.ratePerKg,
    required this.co2Factor,
    required this.description,
  });

  static List<ScrapCategory> get allCategories => const [
        ScrapCategory(
          type: ScrapCategoryType.paper,
          id: 'cat_paper',
          name: 'Paper & Books',
          icon: Icons.menu_book_rounded,
          color: Color(0xFF3B82F6),
          ratePerKg: 14.0,
          co2Factor: 1.8,
          description: 'Newspapers, office paper, notebooks & magazines',
        ),
        ScrapCategory(
          type: ScrapCategoryType.plastic,
          id: 'cat_plastic',
          name: 'PET & Rigid Plastic',
          icon: Icons.local_drink_rounded,
          color: Color(0xFF06B6D4),
          ratePerKg: 22.0,
          co2Factor: 2.5,
          description: 'PET water bottles, milk jugs, buckets & containers',
        ),
        ScrapCategory(
          type: ScrapCategoryType.metal,
          id: 'cat_metal',
          name: 'Metals & Alloys',
          icon: Icons.build_rounded,
          color: Color(0xFF64748B),
          ratePerKg: 105.0,
          co2Factor: 4.2,
          description: 'Copper wire, aluminum cans, brass fittings & iron scraps',
        ),
        ScrapCategory(
          type: ScrapCategoryType.eWaste,
          id: 'cat_ewaste',
          name: 'E-Waste & Gadgets',
          icon: Icons.devices_rounded,
          color: Color(0xFFA855F7),
          ratePerKg: 180.0,
          co2Factor: 6.8,
          description: 'Old smartphones, motherboards, wires, batteries & appliances',
        ),
        ScrapCategory(
          type: ScrapCategoryType.glass,
          id: 'cat_glass',
          name: 'Glass Containers',
          icon: Icons.wine_bar_rounded,
          color: Color(0xFF155EEF),
          ratePerKg: 4.0,
          co2Factor: 0.9,
          description: 'Soft drink bottles, glass jars & intact glass containers',
        ),
        ScrapCategory(
          type: ScrapCategoryType.cardboard,
          id: 'cat_cardboard',
          name: 'Cardboard Boxes',
          icon: Icons.inventory_2_rounded,
          color: Color(0xFFF59E0B),
          ratePerKg: 16.0,
          co2Factor: 1.5,
          description: 'Corrugated packing boxes, carton packaging & brown sheets',
        ),
        ScrapCategory(
          type: ScrapCategoryType.mixed,
          id: 'cat_mixed',
          name: 'Mixed Recyclables',
          icon: Icons.recycling_rounded,
          color: Color(0xFFEC4899),
          ratePerKg: 18.0,
          co2Factor: 2.0,
          description: 'Unsorted household recyclables & mixed junk lots',
        ),
      ];

  static ScrapCategory getByType(ScrapCategoryType type) {
    return allCategories.firstWhere((c) => c.type == type, orElse: () => allCategories.last);
  }
}
