import 'scrap_product.dart';

class PickupCartItem {
  final ScrapProduct product;
  double weightKg;
  String conditionNotes;

  PickupCartItem({
    required this.product,
    required this.weightKg,
    this.conditionNotes = 'Clean & Dry',
  });

  double get totalPayout => product.pricePerKg * weightKg;

  double get co2Saved => weightKg * product.category.co2Factor;
}
