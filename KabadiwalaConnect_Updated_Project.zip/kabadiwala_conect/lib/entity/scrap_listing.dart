import 'scrap_category.dart';

class SegregatedItem {
  final String itemName;
  final ScrapCategoryType categoryType;
  final double confidenceScore; // e.g. 0.95 = 95%
  final double estimatedWeightKg;
  final double ratePerKg;
  final String conditionNote;

  SegregatedItem({
    required this.itemName,
    required this.categoryType,
    required this.confidenceScore,
    required this.estimatedWeightKg,
    required this.ratePerKg,
    required this.conditionNote,
  });

  ScrapCategory get category => ScrapCategory.getByType(categoryType);

  double get totalPrice => estimatedWeightKg * ratePerKg;
}

class ScrapListing {
  final String id;
  final String title;
  final List<SegregatedItem> items;
  final String location;
  final String imageUrl;
  final DateTime createdAt;
  final String sellerName;
  final String sellerPhone;
  String status; // 'Active', 'Under Negotiation', 'Accepted', 'In Transit', 'Completed'
  String? assignedBuyerName;
  double? highestOfferAmount;

  ScrapListing({
    required this.id,
    required this.title,
    required this.items,
    required this.location,
    required this.imageUrl,
    required this.createdAt,
    required this.sellerName,
    required this.sellerPhone,
    this.status = 'Active',
    this.assignedBuyerName,
    this.highestOfferAmount,
  });

  double get totalWeightKg => items.fold(0.0, (sum, item) => sum + item.estimatedWeightKg);

  double get totalEstimatedValue => items.fold(0.0, (sum, item) => sum + item.totalPrice);

  double get co2SavedKg => items.fold(0.0, (sum, item) => sum + (item.estimatedWeightKg * item.category.co2Factor));
}
