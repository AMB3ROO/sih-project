import 'scrap_category.dart';

class ScrapProduct {
  final String id;
  final String title;
  final double pricePerKg;
  final String description;
  final ScrapCategoryType categoryType;
  final String imageUrl;
  final double rating;
  final int ratingCount;
  final double defaultWeightKg;
  final bool isPopular;
  final bool isNewest;

  ScrapProduct({
    required this.id,
    required this.title,
    required this.pricePerKg,
    required this.description,
    required this.categoryType,
    required this.imageUrl,
    this.rating = 4.8,
    this.ratingCount = 120,
    this.defaultWeightKg = 10.0,
    this.isPopular = false,
    this.isNewest = false,
  });

  ScrapCategory get category => ScrapCategory.getByType(categoryType);

  double get estimatedTotalPayout => pricePerKg * defaultWeightKg;

  double get co2Saved => defaultWeightKg * category.co2Factor;

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'pricePerKg': pricePerKg,
        'description': description,
        'categoryType': categoryType.name,
        'imageUrl': imageUrl,
        'rating': rating,
        'ratingCount': ratingCount,
        'defaultWeightKg': defaultWeightKg,
        'isPopular': isPopular,
        'isNewest': isNewest,
      };
}
