# Kabadiwala Connect

## Firebase setup

The app uses Firebase Core and Cloud Firestore. The generated configuration is
intentionally environment-specific and must be created from the Firebase
project rather than copied from source control.

1. Install and authenticate the Firebase CLI:

   ```powershell
   npm install -g firebase-tools
   firebase login
   ```

2. Install FlutterFire CLI and configure the existing project:

   ```powershell
   dart pub global activate flutterfire_cli
   flutterfire configure --project=kabadiwalaconnectdb
   ```

   Select Android and iOS when prompted. Android must use the application ID
   `com.example.kabadiwala_conect` from `android/app/build.gradle.kts`.

3. In Firebase Console, create the Firestore database and enable the required
   Authentication provider before using protected collections.

4. Deploy the checked-in rules and indexes:

   ```powershell
   firebase deploy --only firestore:rules,firestore:indexes --project kabadiwalaconnectdb
   ```

5. Run the app:

   ```powershell
   flutter pub get
   flutter run
   ```

`main.dart` initializes Firebase before the app starts, and
`FirestoreService` reads and writes the collections defined in `firestore.rules`.
The phone OTP flow is still a mock and must be replaced with
`FirebaseAuth.verifyPhoneNumber` before production authentication is enabled.

For help getting started with Flutter development, view the
[online documentation](https://docs.flutter.dev/), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
