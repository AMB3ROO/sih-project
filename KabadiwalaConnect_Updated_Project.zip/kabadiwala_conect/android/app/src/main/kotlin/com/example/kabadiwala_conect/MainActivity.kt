package com.example.kabadiwala_conect

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
